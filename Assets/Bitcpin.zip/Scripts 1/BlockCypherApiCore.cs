using System.Threading.Tasks;
using System.Net.Http;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Linq;

public class BlockCypherApiCore
{
    private static DateTime lastApiCall = DateTime.MinValue;
    private const int MinApiDelayMs = 1500; // 1.5s between calls to safely avoid rate limit (BlockCypher free tier)
    
    /// <summary>
    /// Get all transaction history (both deposits and withdrawals)
    /// </summary>
    public async Task<List<TransactionDisplayData>> GetAllTransactions(string address, bool isTestNet = false)
    {
        await RateLimitDelay();
        
        string network = isTestNet ? "test3" : "main";
        // Use limit of 50 to prevent heavy payloads
        string url = $"https://api.blockcypher.com/v1/btc/{network}/addrs/{address}/full?limit=50";
        
        using (var client = new HttpClient())
        {
            client.Timeout = TimeSpan.FromSeconds(10);
            try
            {
                var response = await client.GetAsync(url);
                var json = await response.Content.ReadAsStringAsync();
                
                if (!response.IsSuccessStatusCode)
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.TooManyRequests)
                    {
                        throw new Exception("⚠️ You are sending too many requests. Please wait a few minutes. This limit is for server security.");
                    }
                    Debug.LogError($"API Error: {response.StatusCode} - {json}");
                    return new List<TransactionDisplayData>();
                }
                
                if (string.IsNullOrEmpty(json))
                {
                    Debug.LogWarning("Empty API response");
                    return new List<TransactionDisplayData>();
                }
                
                var data = Newtonsoft.Json.JsonConvert.DeserializeObject<AddressFullData>(json);
                List<TransactionDisplayData> history = new List<TransactionDisplayData>();
                
                if (data.txs != null)
                {
                    foreach (var tx in data.txs)
                    {
                        var txData = ParseTxDataToDisplay(tx, address);
                        if (txData != null) history.Add(txData);
                    }
                }
                
                return history;
            }
            catch (Exception ex)
            {
                Debug.LogError($"History Error: {ex.Message}");
                return new List<TransactionDisplayData>();
            }
        }
    }

    public async Task<decimal> GetBalance(string address, bool isTestNet = false)
    {
        await RateLimitDelay();
        
        string network = isTestNet ? "test3" : "main";
        string url = $"https://api.blockcypher.com/v1/btc/{network}/addrs/{address}/balance";
        
        using (var client = new HttpClient())
        {
            client.Timeout = TimeSpan.FromSeconds(10);
            try
            {
                var response = await client.GetAsync(url);
                if (!response.IsSuccessStatusCode)
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.TooManyRequests)
                    {
                        throw new Exception("⚠️ You are sending too many requests. Please wait a few minutes. This limit is for server security.");
                    }
                    Debug.LogWarning($"Balance API returned: {response.StatusCode}");
                    return 0;
                }
                var json = await response.Content.ReadAsStringAsync();
                if (string.IsNullOrEmpty(json)) return 0;
                
                var data = Newtonsoft.Json.JsonConvert.DeserializeObject<BalanceData>(json);
                return data != null ? data.final_balance / 100000000m : 0;
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"Balance fetch error: {ex.Message}");
                return 0;
            }
        }
    }

    // --- BATCH API SUPPORT ---

    /// <summary>
    /// Fetch balances for multiple addresses in a single API call (up to 100 addresses)
    /// </summary>
    public async Task<Dictionary<string, decimal>> GetBatchBalances(List<string> addresses, bool isTestNet = false)
    {
        if (addresses == null || addresses.Count == 0) return new Dictionary<string, decimal>();
        
        await RateLimitDelay();
        
        string network = isTestNet ? "test3" : "main";
        string batchStr = string.Join(";", addresses);
        string url = $"https://api.blockcypher.com/v1/btc/{network}/addrs/{batchStr}/balance";
        
        using (var client = new HttpClient())
        {
            client.Timeout = TimeSpan.FromSeconds(15); // Longer timeout for batch
            try
            {
                var response = await client.GetAsync(url);
                var json = await response.Content.ReadAsStringAsync();
                
                if (!response.IsSuccessStatusCode)
                {
                    Debug.LogError($"Batch Balance Error: {response.StatusCode} - {json}");
                    return new Dictionary<string, decimal>();
                }

                // Batch returns an array of balance objects
                var dataList = Newtonsoft.Json.JsonConvert.DeserializeObject<List<BalanceData>>(json);
                var result = new Dictionary<string, decimal>();
                
                if (dataList != null)
                {
                    foreach (var data in dataList)
                    {
                        if (!string.IsNullOrEmpty(data.address))
                        {
                            result[data.address] = data.final_balance / 100000000m;
                        }
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                Debug.LogError($"Batch Balance Exception: {ex.Message}");
                return new Dictionary<string, decimal>();
            }
        }
    }

    /// <summary>
    /// Fetch full transaction data and UTXOs for multiple addresses in a single API call
    /// </summary>
    public async Task<Dictionary<string, AddressFullData>> GetBatchFullData(List<string> addresses, bool isTestNet = false)
    {
        if (addresses == null || addresses.Count == 0) return new Dictionary<string, AddressFullData>();

        await RateLimitDelay();

        string network = isTestNet ? "test3" : "main";
        string batchStr = string.Join(";", addresses);
        // limit=50 to prevent huge payloads in batch
        string url = $"https://api.blockcypher.com/v1/btc/{network}/addrs/{batchStr}/full?limit=50";

        using (var client = new HttpClient())
        {
            client.Timeout = TimeSpan.FromSeconds(25); // Large batches need more time
            try
            {
                var response = await client.GetAsync(url);
                var json = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    Debug.LogError($"Batch Full Data Error: {response.StatusCode}");
                    return new Dictionary<string, AddressFullData>();
                }

                var dataList = Newtonsoft.Json.JsonConvert.DeserializeObject<List<AddressFullData>>(json);
                var result = new Dictionary<string, AddressFullData>();

                if (dataList != null)
                {
                    foreach (var data in dataList)
                    {
                        if (!string.IsNullOrEmpty(data.address))
                        {
                            result[data.address] = data;
                        }
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                Debug.LogError($"Batch Full Data Exception: {ex.Message}");
                return new Dictionary<string, AddressFullData>();
            }
        }
    }

    /// <summary>
    /// دریافت تمام تراکنش‌های چند آدرس به صورت یکجا
    /// </summary>
    public async Task<List<TransactionDisplayData>> GetBatchTransactions(List<string> addresses, bool isTestNet = false)
    {
        if (addresses == null || addresses.Count == 0) return new List<TransactionDisplayData>();

        var batchData = await GetBatchFullData(addresses, isTestNet);
        var allTransactions = new List<TransactionDisplayData>();
        var seenTxHashes = new HashSet<string>();

        foreach (var kvp in batchData)
        {
            string address = kvp.Key;
            var data = kvp.Value;

            if (data.txs != null)
            {
                foreach (var tx in data.txs)
                {
                    if (!seenTxHashes.Contains(tx.hash))
                    {
                        var txData = ParseTxDataToDisplay(tx, address);
                        if (txData != null)
                        {
                            allTransactions.Add(txData);
                            seenTxHashes.Add(tx.hash);
                        }
                    }
                }
            }
        }

        // مرتب‌سازی بر اساس تاریخ (جدیدترین اول)
        allTransactions.Sort((a, b) => string.Compare(b.date, a.date));
        return allTransactions;
    }
    
    // --- NEW: Real Transaction Support ---

    // 1. Get UTXOs (Unspent Transaction Outputs)
    public async Task<List<UTXO>> GetUnspentOutputs(string address, bool isTestNet = false)
    {
        await RateLimitDelay();
        string network = isTestNet ? "test3" : "main";
        // BlockCypher specific endpoint for unspent outputs
        string url = $"https://api.blockcypher.com/v1/btc/{network}/addrs/{address}?unspentOnly=true";

        using (var client = new HttpClient())
        {
            try
            {
                var response = await client.GetAsync(url);
                if (!response.IsSuccessStatusCode) return new List<UTXO>();
                
                var json = await response.Content.ReadAsStringAsync();
                var data = Newtonsoft.Json.JsonConvert.DeserializeObject<AddressData>(json);
                
                List<UTXO> utxos = new List<UTXO>();
                if(data.txrefs != null)
                {
                    foreach(var r in data.txrefs)
                    {
                        utxos.Add(new UTXO {
                            txHash = r.tx_hash,
                            outputIndex = r.tx_output_n,
                            value = r.value,
                            scriptHex = r.script // BlockCypher rarely returns script here, usually need to reconstruct or fetch tx
                        });
                    }
                }
                // Also check unconfirmed
                if(data.unconfirmed_txrefs != null)
                {
                    foreach(var r in data.unconfirmed_txrefs)
                    {
                        utxos.Add(new UTXO {
                            txHash = r.tx_hash,
                            outputIndex = r.tx_output_n,
                            value = r.value,
                            scriptHex = r.script
                        });
                    }
                }
                
                return utxos;
            }
            catch (Exception ex)
            {
                Debug.LogError($"UTXO Error: {ex.Message}");
                return new List<UTXO>();
            }
        }
    }

    // 2. Broadcast Signed Transaction
    public async Task<string> BroadcastTransaction(string hex, bool isTestNet = false)
    {
        await RateLimitDelay();
        string network = isTestNet ? "test3" : "main";
        string url = $"https://api.blockcypher.com/v1/btc/{network}/txs/push";

        var txWrapper = new { tx = hex };
        var jsonContent = Newtonsoft.Json.JsonConvert.SerializeObject(txWrapper);
        var content = new StringContent(jsonContent, System.Text.Encoding.UTF8, "application/json");

        using (var client = new HttpClient())
        {
            try
            {
                var response = await client.PostAsync(url, content);
                var respJson = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    // Parse error
                    throw new Exception($"Broadcast Failed ({response.StatusCode}): {respJson}");
                }

                // Success return full tx object, we just need hash
                var txObj = Newtonsoft.Json.JsonConvert.DeserializeObject<TxData>(respJson);
                return txObj.hash;
            }
            catch (Exception ex)
            {
                Debug.LogError($"Broadcast Error: {ex.Message}");
                throw;
            }
        }
    }

    private async Task RateLimitDelay()
    {
        var timeSinceLastCall = (DateTime.Now - lastApiCall).TotalMilliseconds;
        if (timeSinceLastCall < MinApiDelayMs)
        {
            await Task.Delay((int)(MinApiDelayMs - timeSinceLastCall));
        }
        lastApiCall = DateTime.Now;
    }

    /// <summary>
    /// Parse TxData to TransactionDisplayData for UI display
    /// </summary>
    private TransactionDisplayData ParseTxDataToDisplay(TxData tx, string address)
    {
        if (tx == null) return null;

        // Calculate net change amount for this address
        decimal inputSum = 0;
        decimal outputSum = 0;

        // Sum inputs that belong to us (money we spent)
        if (tx.inputs != null)
        {
            foreach (var inp in tx.inputs)
            {
                if (inp.addresses != null && inp.addresses.Contains(address))
                {
                    inputSum += inp.output_value;
                }
            }
        }

        // Sum outputs that belong to us (money received or change returned)
        if (tx.outputs != null)
        {
            foreach (var outp in tx.outputs)
            {
                if (outp.addresses != null && outp.addresses.Contains(address))
                {
                    outputSum += outp.value;
                }
            }
        }

        decimal difference = outputSum - inputSum;
        
        // If difference is zero (e.g., internal transfer), ignore it
        if (difference == 0) return null;

        TransactionDisplayData txData = new TransactionDisplayData();
        txData.txHash = tx.hash;
        txData.date = tx.confirmed.HasValue ? tx.confirmed.Value.ToString("yyyy-MM-dd HH:mm") : "Unconfirmed";
        
        // Convert satoshi to BTC
        decimal amountBTC = Math.Abs(difference) / 100000000m;
        txData.amount = amountBTC.ToString("F8");

        if (difference > 0)
        {
            txData.type = "Receive";
            // Find sender address (first input)
            if (tx.inputs != null && tx.inputs.Count > 0 && tx.inputs[0].addresses != null)
                txData.otherAddress = tx.inputs[0].addresses[0];
            else
                txData.otherAddress = "Unknown";
        }
        else
        {
            txData.type = "Send";
            // Find recipient address (first output that's not ours)
            txData.otherAddress = "Multiple/Unknown";
            if (tx.outputs != null)
            {
                foreach(var outp in tx.outputs)
                {
                    if (outp.addresses != null && !outp.addresses.Contains(address))
                    {
                        txData.otherAddress = outp.addresses[0];
                        break;
                    }
                }
            }
        }

        return txData;
    }

    // --- Data Classes ---

    public class TransactionDisplayData
    {
        public string type;
        public string amount;
        public string date;
        public string otherAddress;
        public string txHash;
    }

    [Serializable]
    public class BalanceData
    {
        public string address;
        public long final_balance;
        public List<TxRef> txrefs;
    }

    [Serializable]
    public class AddressFullData
    {
        public string address;
        public List<TxData> txs;
        public List<TxRef> txrefs;
    }

    [Serializable]
    public class TxRef
    {
        public string tx_hash;
        public int block_height;
        public int tx_input_n;
        public int tx_output_n;
        public long value;
        public bool spent;
        public string confirmed;
        public string script;
    }

    [Serializable]
    public class TxData
    {
        public string hash;
        public DateTime? confirmed;
        public DateTime? received;
        public List<TxInput> inputs;
        public List<TxOutput> outputs;
    }

    [Serializable]
    public class TxInput
    {
        public long output_value;
        public List<string> addresses;
    }

    [Serializable]
    public class TxOutput
    {
        public long value;
        public List<string> addresses;
    }

    // New UTXO Classes
    public class UTXO 
    {
        public string txHash;
        public int outputIndex;
        public long value; // satoshis
        public string scriptHex;
    }

    public class AddressData
    {
        public string address;
        public long final_balance;
        public List<TxRef> txrefs;
        public List<TxRef> unconfirmed_txrefs;
    }


}