using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;
using System.Collections;
using System.IO;
using NBitcoin;

public class RecoverWalletUI : MonoBehaviour
{
    private BitcoinWalletCore wallet;
    private InputField[] seedInputs = new InputField[12];
    private InputField hexKeyInput;
    private InputField wifKeyInput;
    private bool isTestNet = false; // Force MainNet
    
    // Recovery mode: 0 = Seed Phrase, 1 = Private Key (Hex), 2 = WIF Key
    private int recoverMode = 0;
    
    private Button seedPhraseBtn;
    private Button hexKeyBtn;
    private Button wifKeyBtn;
    private Text statusText;
    private GameObject seedPhraseContainer;
    private GameObject hexKeyContainer;
    private GameObject wifKeyContainer;

    void Start()
    {
        if (FindObjectOfType<EventSystem>() == null)
        {
            GameObject es = new GameObject("EventSystem");
            es.AddComponent<EventSystem>();
            es.AddComponent<StandaloneInputModule>();
        }
        
        BuildUI();
    }

    void BuildUI()
    {
        GameObject canvasObj = new GameObject("Canvas");
        canvasObj.layer = 5;
        Canvas canvas = canvasObj.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        
        CanvasScaler scaler = canvasObj.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1080, 1920);
        scaler.matchWidthOrHeight = 0.5f;
        
        canvasObj.AddComponent<GraphicRaycaster>();

        GameObject bg = new GameObject("BG");
        bg.layer = 5;
        bg.transform.SetParent(canvas.transform, false);
        RectTransform bgRT = bg.AddComponent<RectTransform>();
        bgRT.anchorMin = Vector2.zero;
        bgRT.anchorMax = Vector2.one;
        bgRT.sizeDelta = Vector2.zero;
        bg.AddComponent<Image>().color = ThemeManager.Instance.GetBackgroundColor();

        float y = 700;

        // Title
        MakeText(canvas.transform, LocalizationManager.Instance.Get("REC_TITLE"), 0, y, 70, ThemeManager.Instance.GetTextColor());
        y -= 160;

        y -= 20; // Slight adjustment

        // Mode Selection Buttons (3 tabs: Seed Phrase / Hex Key / WIF Key)
        float tabWidth = 300;
        float tabSpacing = 20;
        float totalWidth = tabWidth * 3 + tabSpacing * 2;
        float startX = -totalWidth / 2 + tabWidth / 2;
        
        seedPhraseBtn = MakeButtonReturn(canvas.transform, LocalizationManager.Instance.Get("REC_TAB_SEED"), startX, y, tabWidth, 100,
            recoverMode == 0 ? new Color(0.3f, 0.7f, 0.9f) : ThemeManager.Instance.GetCardColor(),
            () => { recoverMode = 0; UpdateModeButtons(); });
        
        hexKeyBtn = MakeButtonReturn(canvas.transform, LocalizationManager.Instance.Get("REC_TAB_HEX"), startX + tabWidth + tabSpacing, y, tabWidth, 100,
            recoverMode == 1 ? new Color(0.3f, 0.7f, 0.9f) : ThemeManager.Instance.GetCardColor(),
            () => { recoverMode = 1; UpdateModeButtons(); });
            
        wifKeyBtn = MakeButtonReturn(canvas.transform, LocalizationManager.Instance.Get("REC_TAB_WIF"), startX + (tabWidth + tabSpacing) * 2, y, tabWidth, 100,
            recoverMode == 2 ? new Color(0.3f, 0.7f, 0.9f) : ThemeManager.Instance.GetCardColor(),
            () => { recoverMode = 2; UpdateModeButtons(); });
        y -= 180;

        // ===== Seed Phrase Container =====
        seedPhraseContainer = new GameObject("SeedPhraseContainer");
        seedPhraseContainer.layer = 5;
        seedPhraseContainer.transform.SetParent(canvas.transform, false);
        
        MakeLabel(seedPhraseContainer.transform, LocalizationManager.Instance.Get("REC_LBL_SEED"), 0, y, 40);
        float seedY = y - 100;

        for (int i = 0; i < 12; i++)
        {
            int col = i % 2;
            int row = i / 2;
            float x = col == 0 ? -230 : 270;
            float yPos = seedY - (row * 110);
            
            GameObject numLabel = new GameObject($"Num{i}");
            numLabel.layer = 5;
            numLabel.transform.SetParent(canvas.transform, false);
            RectTransform numRT = numLabel.AddComponent<RectTransform>();
            numRT.anchoredPosition = new Vector2(x - 230, yPos);
            numRT.sizeDelta = new Vector2(60, 80);
            numLabel.transform.SetParent(seedPhraseContainer.transform, false);
            Text numText = numLabel.AddComponent<Text>();
            numText.text = $"{i + 1:00}";
            numText.fontSize = 38;
            numText.color = ThemeManager.Instance.GetAccentColor();
            numText.font = GetFont();
            numText.alignment = TextAnchor.MiddleCenter;
            numText.fontStyle = FontStyle.Bold;
            
            seedInputs[i] = MakeInput(seedPhraseContainer.transform, x, yPos, 380, 80);
        }
        
        // ===== Hex Key Container =====
        hexKeyContainer = new GameObject("HexKeyContainer");
        hexKeyContainer.layer = 5;
        hexKeyContainer.transform.SetParent(canvas.transform, false);
        
        MakeLabel(hexKeyContainer.transform, LocalizationManager.Instance.Get("REC_LBL_HEX"), 0, y, 40);
        float pkY = y - 80;
        MakeLabel(hexKeyContainer.transform, LocalizationManager.Instance.Get("REC_HINT_HEX"), 0, pkY, 28);
        pkY -= 80;
        
        hexKeyInput = MakeInput(hexKeyContainer.transform, 0, pkY, 900, 100);
        hexKeyInput.lineType = InputField.LineType.MultiLineNewline;
        
        // ===== WIF Key Container =====
        wifKeyContainer = new GameObject("WifKeyContainer");
        wifKeyContainer.layer = 5;
        wifKeyContainer.transform.SetParent(canvas.transform, false);
        
        MakeLabel(wifKeyContainer.transform, LocalizationManager.Instance.Get("REC_LBL_WIF"), 0, y, 40);
        float wifY = y - 80;
        MakeLabel(wifKeyContainer.transform, LocalizationManager.Instance.Get("REC_HINT_WIF"), 0, wifY, 28);
        wifY -= 80;
        
        wifKeyInput = MakeInput(wifKeyContainer.transform, 0, wifY, 900, 100);
        wifKeyInput.lineType = InputField.LineType.MultiLineNewline;
        
        y -= 850;
        
        UpdateModeButtons();

        // Recover Button
        MakeButton(canvas.transform, LocalizationManager.Instance.Get("REC_BTN_RECOVER"), 0, y, 900, 120, RecoverWallet)
            .GetComponent<Image>().color = new Color(0.2f, 0.6f, 0.3f);
        y -= 180;
        
        statusText = MakeText(canvas.transform, "", 0, y, 35, Color.yellow);
        
        // Back Button
        MakeButton(canvas.transform, LocalizationManager.Instance.Get("GEN_BACK"), -400, 850, 280, 100, () => {
            AudioManager.Instance.PlayClick();
            SceneManager.LoadScene("MainWallet");
        }).GetComponent<Image>().color = ThemeManager.Instance.GetAccentColor();
    }

    // --- HELPER METHODS ---

    Font GetFont()
    {
        Font f = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        if (f == null) f = Resources.GetBuiltinResource<Font>("Arial.ttf");
        return f;
    }

    Text MakeText(Transform parent, string txt, float x, float y, int size, Color col)
    {
        GameObject obj = new GameObject("Text");
        obj.layer = 5; obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchoredPosition = new Vector2(x, y);
        rt.sizeDelta = new Vector2(1000, 80);
        Text text = obj.AddComponent<Text>();
        text.text = txt; text.fontSize = size; text.color = col;
        text.font = GetFont();
        text.alignment = TextAnchor.MiddleCenter;
        return text;
    }

    void MakeLabel(Transform parent, string txt, float x, float y, int size)
    {
        GameObject obj = new GameObject("Label");
        obj.layer = 5; obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchoredPosition = new Vector2(x, y);
        rt.sizeDelta = new Vector2(1000, 60);
        Text text = obj.AddComponent<Text>();
        text.text = txt; text.fontSize = size;
        text.color = ThemeManager.Instance.GetSecondaryTextColor();
        text.font = GetFont();
        text.alignment = TextAnchor.MiddleCenter;
        text.fontStyle = FontStyle.Bold;
    }

    InputField MakeInput(Transform parent, float x, float y, float w, float h)
    {
        GameObject obj = new GameObject("Input");
        obj.layer = 5; obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchoredPosition = new Vector2(x, y);
        rt.sizeDelta = new Vector2(w, h);
        
        Image img = obj.AddComponent<Image>();
        img.color = ThemeManager.Instance.GetCardColor();
        
        InputField input = obj.AddComponent<InputField>();
        
        GameObject txtObj = new GameObject("Text");
        txtObj.layer = 5; txtObj.transform.SetParent(obj.transform, false);
        RectTransform txtRT = txtObj.AddComponent<RectTransform>();
        txtRT.anchorMin = Vector2.zero; txtRT.anchorMax = Vector2.one;
        txtRT.offsetMin = new Vector2(15, 5); txtRT.offsetMax = new Vector2(-15, -5);
        
        Text txt = txtObj.AddComponent<Text>();
        txt.font = GetFont();
        txt.fontSize = 32;
        txt.color = ThemeManager.Instance.GetTextColor();
        txt.alignment = TextAnchor.MiddleCenter;
        
        input.textComponent = txt;
        return input;
    }

    Button MakeButton(Transform parent, string txt, float x, float y, float w, float h, UnityEngine.Events.UnityAction action)
    {
        GameObject obj = new GameObject("Btn");
        obj.layer = 5; obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchoredPosition = new Vector2(x, y);
        rt.sizeDelta = new Vector2(w, h);
        Image img = obj.AddComponent<Image>();
        img.color = ThemeManager.Instance.GetAccentColor();
        Button btn = obj.AddComponent<Button>();
        btn.onClick.AddListener(() => AudioManager.Instance.PlayClick());
        btn.onClick.AddListener(action);
        
        GameObject txtObj = new GameObject("Text");
        txtObj.layer = 5; txtObj.transform.SetParent(obj.transform, false);
        RectTransform txtRT = txtObj.AddComponent<RectTransform>();
        txtRT.anchorMin = Vector2.zero; txtRT.anchorMax = Vector2.one;
        txtRT.sizeDelta = Vector2.zero;
        Text text = txtObj.AddComponent<Text>();
        text.text = txt; text.fontSize = 45; text.color = Color.white;
        text.font = GetFont();
        text.alignment = TextAnchor.MiddleCenter;
        text.fontStyle = FontStyle.Bold;
        
        return btn;
    }
    
    Button MakeButtonReturn(Transform parent, string txt, float x, float y, float w, float h, Color color, UnityEngine.Events.UnityAction action)
    {
        GameObject obj = new GameObject("Btn");
        obj.layer = 5; obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchoredPosition = new Vector2(x, y);
        rt.sizeDelta = new Vector2(w, h);
        Image img = obj.AddComponent<Image>();
        img.color = color;
        Button btn = obj.AddComponent<Button>();
        btn.onClick.AddListener(() => AudioManager.Instance.PlayClick());
        btn.onClick.AddListener(action);
        
        GameObject txtObj = new GameObject("Text");
        txtObj.layer = 5; txtObj.transform.SetParent(obj.transform, false);
        RectTransform txtRT = txtObj.AddComponent<RectTransform>();
        txtRT.anchorMin = Vector2.zero; txtRT.anchorMax = Vector2.one;
        txtRT.sizeDelta = Vector2.zero;
        Text text = txtObj.AddComponent<Text>();
        text.text = txt; text.fontSize = 38; text.color = Color.white;
        text.font = GetFont();
        text.alignment = TextAnchor.MiddleCenter;
        text.fontStyle = FontStyle.Bold;
        
        return btn;
    }
    
    void UpdateModeButtons()
    {
        Color activeCol = new Color(0.3f, 0.7f, 0.9f);
        Color inactiveCol = ThemeManager.Instance.GetCardColor();
        
        if (seedPhraseBtn != null)
            seedPhraseBtn.GetComponent<Image>().color = recoverMode == 0 ? activeCol : inactiveCol;
        if (hexKeyBtn != null)
            hexKeyBtn.GetComponent<Image>().color = recoverMode == 1 ? activeCol : inactiveCol;
        if (wifKeyBtn != null)
            wifKeyBtn.GetComponent<Image>().color = recoverMode == 2 ? activeCol : inactiveCol;
            
        // Toggle visibility of containers
        if (seedPhraseContainer != null)
            seedPhraseContainer.SetActive(recoverMode == 0);
        if (hexKeyContainer != null)
            hexKeyContainer.SetActive(recoverMode == 1);
        if (wifKeyContainer != null)
            wifKeyContainer.SetActive(recoverMode == 2);
    }

    void RecoverWallet()
    {
        statusText.text = LocalizationManager.Instance.Get("GEN_CHECKING");
        statusText.color = Color.yellow;
        
        try
        {
            NBitcoin.Network network = NBitcoin.Network.Main;
            string address = "";
            string privateKey = "";
            string seedPhrase = "";
            
            if (recoverMode == 0)
            {
                // === Seed Phrase Recovery Mode ===
                bool hasEmpty = false;
                
                for (int i = 0; i < 12; i++)
                {
                    string word = seedInputs[i].text.Trim().ToLower();
                    if (string.IsNullOrEmpty(word))
                    {
                        hasEmpty = true;
                        seedInputs[i].GetComponent<Image>().color = new Color(1f, 0.5f, 0.5f);
                    }
                    else
                    {
                        seedInputs[i].GetComponent<Image>().color = ThemeManager.Instance.GetCardColor();
                    }
                    seedPhrase += word + " ";
                }
                
                if (hasEmpty)
                {
                    statusText.text = LocalizationManager.Instance.Get("REC_ERR_SEED_EMPTY");
                    statusText.color = Color.red;
                    return;
                }
                
                seedPhrase = seedPhrase.Trim();
                wallet = new BitcoinWalletCore(seedPhrase, network);
                
                address = wallet.GetSegWitAddress(0);
                privateKey = wallet.GetSegWitPrivateKey(0);
            }
            else if (recoverMode == 1)
            {
                // === Private Key (Hex) Recovery Mode ===
                string privateKeyHex = hexKeyInput.text.Trim();
                
                if (string.IsNullOrEmpty(privateKeyHex))
                {
                    statusText.text = LocalizationManager.Instance.Get("REC_ERR_PK_EMPTY");
                    statusText.color = Color.red;
                    hexKeyInput.GetComponent<Image>().color = new Color(1f, 0.5f, 0.5f);
                    return;
                }
                
                // Remove spaces, newlines
                privateKeyHex = privateKeyHex.Replace(" ", "").Replace("\n", "").Replace("\r", "");
                
                // Validate: must be exactly 64 hex characters
                if (privateKeyHex.Length != 64)
                {
                    statusText.text = LocalizationManager.Instance.Get("REC_ERR_HEX_LEN");
                    statusText.color = Color.red;
                    hexKeyInput.GetComponent<Image>().color = new Color(1f, 0.5f, 0.5f);
                    return;
                }
                
                if (!System.Text.RegularExpressions.Regex.IsMatch(privateKeyHex, "^[0-9a-fA-F]+$"))
                {
                    statusText.text = LocalizationManager.Instance.Get("REC_ERR_HEX_FMT");
                    statusText.color = Color.red;
                    hexKeyInput.GetComponent<Image>().color = new Color(1f, 0.5f, 0.5f);
                    return;
                }
                
                hexKeyInput.GetComponent<Image>().color = ThemeManager.Instance.GetCardColor();
                
                // Create wallet from hex private key
                wallet = new BitcoinWalletCore(privateKeyHex, network, true);
                
                address = wallet.GetSegWitAddress(0);
                privateKey = wallet.GetSegWitPrivateKey(0);
                seedPhrase = ""; // No seed phrase for private key import
            }
            else if (recoverMode == 2)
            {
                // === WIF Key Recovery Mode ===
                string wifKey = wifKeyInput.text.Trim();
                
                if (string.IsNullOrEmpty(wifKey))
                {
                    statusText.text = LocalizationManager.Instance.Get("REC_ERR_WIF_EMPTY");
                    statusText.color = Color.red;
                    wifKeyInput.GetComponent<Image>().color = new Color(1f, 0.5f, 0.5f);
                    return;
                }
                
                // Remove spaces, newlines
                wifKey = wifKey.Replace(" ", "").Replace("\n", "").Replace("\r", "");
                
                // Validate WIF format: 51-52 characters, starts with K, L, or 5
                // Base58 character set: 123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz
                if (wifKey.Length < 51 || wifKey.Length > 52)
                {
                    statusText.text = LocalizationManager.Instance.Get("REC_ERR_WIF_LEN");
                    statusText.color = Color.red;
                    wifKeyInput.GetComponent<Image>().color = new Color(1f, 0.5f, 0.5f);
                    return;
                }
                
                if (wifKey[0] != 'K' && wifKey[0] != 'L' && wifKey[0] != '5')
                {
                    statusText.text = LocalizationManager.Instance.Get("REC_ERR_WIF_START");
                    statusText.color = Color.red;
                    wifKeyInput.GetComponent<Image>().color = new Color(1f, 0.5f, 0.5f);
                    return;
                }
                
                // Validate Base58 characters
                string base58Chars = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
                foreach (char c in wifKey)
                {
                    if (base58Chars.IndexOf(c) < 0)
                    {
                        statusText.text = LocalizationManager.Instance.Get("REC_ERR_WIF_FMT");
                        statusText.color = Color.red;
                        wifKeyInput.GetComponent<Image>().color = new Color(1f, 0.5f, 0.5f);
                        return;
                    }
                }
                
                wifKeyInput.GetComponent<Image>().color = ThemeManager.Instance.GetCardColor();
                
                // Create wallet from WIF key (isHex = false means WIF format)
                wallet = new BitcoinWalletCore(wifKey, network, false);
                
                address = wallet.GetSegWitAddress(0);
                privateKey = wallet.GetSegWitPrivateKey(0);
                seedPhrase = ""; // No seed phrase for WIF import
            }
            
            // Save wallet (seedPhrase will be empty string for private key/WIF imports)
            WalletManager2.Instance.SaveWallet(seedPhrase, isTestNet, address, privateKey);
            
            statusText.text = LocalizationManager.Instance.Get("REC_SUCCESS");
            statusText.color = Color.green;
            
            Debug.Log("✅ Wallet Recovered and Saved!");
            Invoke("GoToMain", 1.5f);
        }
        catch (System.Exception ex)
        {
            statusText.color = Color.red;
            if (ex.Message.Contains("not in the wordlist")) statusText.text = "❌ Invalid word! Check spelling";
            else if (ex.Message.Contains("entropy")) statusText.text = LocalizationManager.Instance.Get("REC_ERR_SEED_EMPTY"); // Use general seed error or specific
            else if (ex.Message.Contains("private key")) statusText.text = LocalizationManager.Instance.Get("REC_ERR_PK_EMPTY"); // Generic
            else if (ex.Message.Contains("checksum")) statusText.text = LocalizationManager.Instance.Get("REC_ERR_WIF_FMT"); // Checksum similar to format
            else statusText.text = $"❌ {LocalizationManager.Instance.Get("GEN_ERROR")}: {ex.Message.Substring(0, System.Math.Min(50, ex.Message.Length))}";
            Debug.LogError($"❌ Recovery Error: {ex.Message}");
        }
    }
    
    void GoToMain()
    {
        SceneManager.LoadScene("MainWallet");
    }
}
