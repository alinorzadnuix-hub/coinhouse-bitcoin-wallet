using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Threading;
using ZXing;
using ZXing.QrCode;
using ZXing.Common;
using NBitcoin;
using UnityEngine.Networking;
#if UNITY_ANDROID
using UnityEngine.Android;
#endif

public class SendReceiveUI : MonoBehaviour
{
    private InputField sendAddressInput;
    private InputField sendAmountInput;
    private InputField feeInput;
    private Text statusText;
    private Text balanceText;
    private Text usdValueText;
    private Text networkText;
    private GameObject receivePanel;
    private GameObject scanPanel;
    private RawImage cameraDisplay;
    private GameObject addressBookContainer;
    
    // UI Layout Configuration
    private const float REFERENCE_WIDTH = 1080f;
    private const float REFERENCE_HEIGHT = 1920f;
    
    private WebCamTexture webCamTexture;
    private bool isScanPanelVisible = false;
    private BitcoinTransactionService transactionService;
    private CancellationTokenSource cts;
    
    // Transaction loading panel
    private GameObject loadingPanel;
    private Text loadingText;
    private Button cancelButton;
    private bool transactionCancelled = false;
    
    private const string COINGECKO_API = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd";
    private const string COINPAPRIKA_API = "https://api.coinpaprika.com/v1/tickers/btc-bitcoin";
    
    private double lastBtcPrice = 0;
    private GameObject addressBookOverlay;
    
    // ✅ Auto-refresh timer
    private const float AUTO_REFRESH_INTERVAL = 180f; // 3 minutes
    private Text balanceUsdText;
    
    // PIN verification for transaction
    private static bool pendingPINVerification = false;
    private static string pendingAddress = "";
    private static decimal pendingAmount = 0;
    private static decimal pendingFee = 0;

    void Start()
    {
        try {
            if (FindObjectOfType<EventSystem>() == null)
            {
                var esObj = new GameObject("EventSystem");
                esObj.AddComponent<EventSystem>();
                esObj.AddComponent<StandaloneInputModule>();
            }
            BuildUI();
        }
        catch (System.Exception ex) { Debug.LogError($"SendReceiveUI: UI Build Failed: {ex.Message}"); }

        try {
            transactionService = new BitcoinTransactionService();
            
            // ✅ Show cached balance IMMEDIATELY (no loading text)
            ShowCachedBalance();
            
            // ✅ Refresh balance in background (silently)
            RefreshWalletStatus();
            
            // ✅ Auto-refresh every 3 minutes
            InvokeRepeating("AutoRefreshBalance", AUTO_REFRESH_INTERVAL, AUTO_REFRESH_INTERVAL);
        }
        catch (System.Exception ex) { if (statusText != null) statusText.text = "Init Error: " + ex.Message; }
        
        // Check if returning from PIN verification
        if (PlayerPrefs.GetInt("PendingTxPIN", 0) == 1 && AuthManager.Instance != null && AuthManager.Instance.IsAuthenticated)
        {
            PlayerPrefs.SetInt("PendingTxPIN", 0);
            PlayerPrefs.Save();
            pendingPINVerification = false;
            ExecutePendingTransaction();
        }
    }

    void OnDestroy()
    {
        if (cts != null) cts.Cancel();
        StopCamera();
    }

    // ✅ NEW: Block Android back button during transaction
    void Update()
    {
        if (loadingPanel != null && loadingPanel.activeSelf)
        {
            // Block Android/Escape back button
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                Debug.Log("[SendReceiveUI] Back button blocked during transaction");
                // Don't process the back button
                return;
            }
        }
    }

    void BuildUI()
    {
        GameObject canvasObj = new GameObject("Canvas");
        canvasObj.layer = 5;
        Canvas canvas = canvasObj.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        CanvasScaler scaler = canvasObj.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(REFERENCE_WIDTH, REFERENCE_HEIGHT);
        scaler.matchWidthOrHeight = 0.5f;
        canvasObj.AddComponent<GraphicRaycaster>(); 

        // THEME: BG
        GameObject bg = new GameObject("BG");
        bg.layer = 5;
        bg.transform.SetParent(canvas.transform, false);
        RectTransform bgRT = bg.AddComponent<RectTransform>();
        // FULL STRETCH
        bgRT.anchorMin = Vector2.zero; bgRT.anchorMax = Vector2.one;
        bgRT.offsetMin = Vector2.zero; bgRT.offsetMax = Vector2.zero;
        Image bgImg = bg.AddComponent<Image>();
        bgImg.color = ThemeManager.Instance.GetBackgroundColor(); 

        // --- TOP BAR (Taller to show balance) ---
        GameObject topBar = MakePanel(canvas.transform, "TopBar", 0, 0, REFERENCE_WIDTH, 300, ThemeManager.Instance.GetCardColor());
        RectTransform topBarRT = topBar.GetComponent<RectTransform>();
        topBarRT.anchorMin = new Vector2(0, 1);
        topBarRT.anchorMax = new Vector2(1, 1);
        topBarRT.pivot = new Vector2(0.5f, 1);
        topBarRT.anchoredPosition = Vector2.zero;
        topBarRT.sizeDelta = new Vector2(0, 300); 
        topBarRT.offsetMin = new Vector2(0, topBarRT.offsetMin.y);
        topBarRT.offsetMax = new Vector2(0, topBarRT.offsetMax.y);

        // Back Button
        MakeButton(topBar.transform, LocalizationManager.Instance.Get("GEN_BACK"), -400, 60, 200, 80, () => SceneManager.LoadScene("MainWallet"))
            .GetComponent<Image>().color = ThemeManager.Instance.GetAccentColor();

        // Title
        MakeText(topBar.transform, LocalizationManager.Instance.Get("TX_TITLE"), 0, 80, 40, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);
        
        // ✅ Balance Display - Always visible, shows cached balance
        Color balColor = ThemeManager.Instance.IsDarkMode ? new Color(0.3f, 1f, 0.4f) : new Color(1f, 0.5f, 0f); // Green in dark, Orange in light
        balanceText = MakeText(topBar.transform, "0.00000000 BTC", 0, 10, 42, balColor, FontStyle.Bold);
        balanceText.gameObject.SetActive(true);
        
        // ✅ USD equivalent below balance
        balanceUsdText = MakeText(topBar.transform, "", 0, -35, 28, new Color(1f, 0.84f, 0f), FontStyle.Normal);
        balanceUsdText.gameObject.SetActive(true);
        
        // Network label
        networkText = MakeText(topBar.transform, "MainNet", 0, -75, 24, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Normal);
        networkText.gameObject.SetActive(true);

        // --- CONTENT ---
        float startY = 100; 

        // Send Card - Taller and better positioned
        GameObject sendCard = MakeCard(canvas.transform, 0, startY, 1000, 1100);
        float cardY = 480;

        MakeText(sendCard.transform, LocalizationManager.Instance.Get("TX_SEND_CARD"), 0, cardY, 40, ThemeManager.Instance.GetAccentColor(), FontStyle.Bold);
        cardY -= 90;

        // 1. To Address
        // Input starts at x=-60, w=750 -> Left Edge = -435
        // Label Width 500, Center Pivot -> Postion = LeftEdge + 250 = -185
        MakeLabel(sendCard.transform, LocalizationManager.Instance.Get("TX_TO_ADDR"), -185, cardY);
        cardY -= 80; // Increased spacing to prevent overlap
        // Reduced width to fit Paste button
        sendAddressInput = MakeInput(sendCard.transform, -120, cardY, 630, 90, LocalizationManager.Instance.Get("INPUT_PASTE_ADDR"));
        
        // Paste Button (Clipboard)
        MakeButton(sendCard.transform, LocalizationManager.Instance.Get("BTN_PASTE"), 270, cardY, 100, 90, () => {
            sendAddressInput.text = GUIUtility.systemCopyBuffer;
        });
        
        // Scan Button with Camera Icon
        MakeButtonWithIcon(sendCard.transform, "camera", 390, cardY, 100, 90, OnScanQR);
        cardY -= 140;

        // 2. Amount
        // Input starts at x=0, w=900 -> Left Edge = -450
        // Label Position = -450 + 250 = -200
        MakeLabel(sendCard.transform, LocalizationManager.Instance.Get("TX_AMOUNT"), -200, cardY);
        cardY -= 80; // Increased spacing to prevent overlap
        sendAmountInput = MakeInput(sendCard.transform, 0, cardY, 900, 90, "0.00000000");
        sendAmountInput.contentType = InputField.ContentType.DecimalNumber;
        sendAmountInput.onValueChanged.AddListener(OnAmountChanged);
        cardY -= 70;
        
        usdValueText = MakeText(sendCard.transform, "≈ $0.00 USD", 300, cardY, 28, new Color(1f, 0.84f, 0f), FontStyle.Italic);
        usdValueText.alignment = TextAnchor.MiddleRight; 
        usdValueText.rectTransform.sizeDelta = new Vector2(400, 50);
        cardY -= 80;

        // 3. Percentage Buttons
        float btnW = 200;
        float btnGap = 25;
        float startX = -((btnW * 4) + (btnGap * 3)) / 2 + btnW / 2;
        
        MakeButtonOutline(sendCard.transform, "25%", startX, cardY, btnW, 70, () => OnPercentageClick(0.25f));
        MakeButtonOutline(sendCard.transform, "50%", startX + btnW + btnGap, cardY, btnW, 70, () => OnPercentageClick(0.50f));
        MakeButtonOutline(sendCard.transform, "75%", startX + (btnW + btnGap) * 2, cardY, btnW, 70, () => OnPercentageClick(0.75f));
        MakeButtonOutline(sendCard.transform, "MAX", startX + (btnW + btnGap) * 3, cardY, btnW, 70, () => OnPercentageClick(1.0f));
        cardY -= 120;

        // 4. Fee
        MakeLabel(sendCard.transform, LocalizationManager.Instance.Get("TX_FEE"), -200, cardY);
        cardY -= 80; // Increased spacing to prevent overlap
        feeInput = MakeInput(sendCard.transform, 0, cardY, 900, 90, "0.00000250");
        feeInput.text = "0.0000025"; 
        feeInput.contentType = InputField.ContentType.DecimalNumber;
        cardY -= 150;

        // 5. Send Action
        MakeButton(sendCard.transform, LocalizationManager.Instance.Get("TX_BTN_SEND"), 0, cardY, 500, 110, OnSendPressed).GetComponent<Image>().color = new Color(0.2f, 0.6f, 0.3f); 
        
        // Address Book Button (Brown)
        MakeButton(canvas.transform, LocalizationManager.Instance.Get("ADDR_BOOK_BTN"), 0, -500, 900, 120, ShowAddressBookOverlay)
            .GetComponent<Image>().color = new Color(0.55f, 0.35f, 0.15f);
        
        // "Show My QR" Button
        MakeButton(canvas.transform, LocalizationManager.Instance.Get("TX_BTN_SHOW_QR"), 0, -650, 900, 120, OnShowReceive);

        // Recent Addresses Card
        GameObject abCard = MakeCard(canvas.transform, 0, -950, 1000, 350);
        
        // Header for Address Book
        MakeText(abCard.transform, LocalizationManager.Instance.Get("RECENT_ADDR_TITLE"), 0, 120, 35, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);
        
        addressBookContainer = abCard;
        UpdateAddressBookUI();
        
        statusText = MakeText(canvas.transform, LocalizationManager.Instance.Get("STATUS_READY"), 0, 160, 32, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Normal);
        RectTransform statusRT = statusText.rectTransform;
        statusRT.anchorMin = new Vector2(0.5f, 1); statusRT.anchorMax = new Vector2(0.5f, 1);
        statusRT.anchoredPosition = new Vector2(0, -310); // Below TopBar (300px tall)

        CreateReceivePanel(canvas.transform);
        CreateScanPanel(canvas.transform);
    }
    
    // --- HELPERS ---

    Font GetFont()
    {
        Font f = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        if (f == null) f = Resources.GetBuiltinResource<Font>("Arial.ttf");
        if (f == null) f = Font.CreateDynamicFontFromOSFont("Arial", 16);
        return f;
    }
    
    GameObject MakePanel(Transform parent, string name, float x, float y, float w, float h, Color color)
    {
        GameObject obj = new GameObject(name);
        obj.layer = 5; 
        obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchorMin = new Vector2(0.5f, 0.5f); rt.anchorMax = new Vector2(0.5f, 0.5f); rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition3D = new Vector3(x, y, 0); // Z=0
        rt.sizeDelta = new Vector2(w, h);
        obj.AddComponent<Image>().color = color;
        return obj;
    }

    GameObject MakeCard(Transform parent, float x, float y, float w, float h)
    {
        return MakePanel(parent, "Card", x, y, w, h, ThemeManager.Instance.GetCardColor());
    }

    Text MakeText(Transform parent, string txt, float x, float y, int size, Color col, FontStyle style)
    {
        GameObject obj = new GameObject("Text");
        obj.layer = 5;
        obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchoredPosition3D = new Vector3(x, y, 0);
        rt.sizeDelta = new Vector2(950, 80);
        Text text = obj.AddComponent<Text>();
        text.text = txt; text.fontSize = size; text.color = col; text.fontStyle = style; text.font = GetFont();
        text.alignment = TextAnchor.MiddleCenter;
        text.raycastTarget = false; // Fix: No block clicks
        return text;
    }

    void MakeLabel(Transform parent, string txt, float x, float y)
    {
        GameObject obj = new GameObject("Label");
        obj.layer = 5;
        obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchoredPosition3D = new Vector3(x, y, 0);
        rt.sizeDelta = new Vector2(500, 50);
        Text text = obj.AddComponent<Text>();
        text.text = txt; text.fontSize = 28; text.color = ThemeManager.Instance.GetSecondaryTextColor();
        text.font = GetFont(); text.alignment = TextAnchor.MiddleLeft;
        text.raycastTarget = false;
    }

    InputField MakeInput(Transform parent, float x, float y, float w, float h, string placeholder)
    {
        GameObject obj = new GameObject("Input");
        obj.layer = 5;
        obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchoredPosition3D = new Vector3(x, y, 0);
        rt.sizeDelta = new Vector2(w, h);
        obj.AddComponent<Image>().color = ThemeManager.Instance.IsDarkMode ? new Color(0.1f, 0.1f, 0.15f) : new Color(0.9f, 0.9f, 0.9f);
        InputField input = obj.AddComponent<InputField>();
        
        GameObject textObj = new GameObject("Text");
        textObj.layer = 5; textObj.transform.SetParent(obj.transform, false);
        RectTransform textRT = textObj.AddComponent<RectTransform>();
        textRT.anchorMin = Vector2.zero; textRT.anchorMax = Vector2.one;
        textRT.offsetMin = new Vector2(10, 0); textRT.offsetMax = new Vector2(-10, 0);
        Text text = textObj.AddComponent<Text>();
        text.font = GetFont(); text.fontSize = 32; text.color = ThemeManager.Instance.GetTextColor(); text.alignment = TextAnchor.MiddleLeft;
        text.raycastTarget = false;
        input.textComponent = text;
        
        GameObject phObj = new GameObject("Placeholder");
        phObj.layer = 5; phObj.transform.SetParent(obj.transform, false);
        RectTransform phRT = phObj.AddComponent<RectTransform>();
        phRT.anchorMin = Vector2.zero; phRT.anchorMax = Vector2.one;
        phRT.offsetMin = new Vector2(10, 0); phRT.offsetMax = new Vector2(-10, 0);
        Text ph = phObj.AddComponent<Text>();
        ph.text = placeholder; ph.font = GetFont(); ph.fontSize = 32; ph.color = new Color(0.5f, 0.5f, 0.5f);
        ph.fontStyle = FontStyle.Italic; ph.alignment = TextAnchor.MiddleLeft;
        ph.raycastTarget = false;
        input.placeholder = ph;
        return input;
    }

    Button MakeButton(Transform parent, string txt, float x, float y, float w, float h, System.Action onClick)
    {
        GameObject obj = new GameObject("Button");
        obj.layer = 5;
        obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchoredPosition3D = new Vector3(x, y, 0);
        rt.sizeDelta = new Vector2(w, h);
        Image img = obj.AddComponent<Image>();
        img.color = ThemeManager.Instance.GetAccentColor();
        Button btn = obj.AddComponent<Button>();
        btn.onClick.AddListener(() => AudioManager.Instance.PlayClick());
        btn.onClick.AddListener(()=>onClick());
        
        if (!string.IsNullOrEmpty(txt)) {
            GameObject tObj = new GameObject("Text");
            tObj.layer = 5; tObj.transform.SetParent(obj.transform, false);
            RectTransform tRT = tObj.AddComponent<RectTransform>();
            tRT.anchorMin = Vector2.zero; tRT.anchorMax = Vector2.one;
            Text t = tObj.AddComponent<Text>();
            t.text = txt; t.font = GetFont(); t.fontSize = 32; t.color = Color.white;
            t.alignment = TextAnchor.MiddleCenter; t.fontStyle = FontStyle.Bold;
            t.raycastTarget = false;
        }
        return btn;
    }

    Button MakeButtonOutline(Transform parent, string txt, float x, float y, float w, float h, System.Action onClick)
    {
        GameObject obj = new GameObject("ButtonOutline");
        obj.layer = 5;
        obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchoredPosition3D = new Vector3(x, y, 0);
        rt.sizeDelta = new Vector2(w, h);
        obj.AddComponent<Image>().color = ThemeManager.Instance.IsDarkMode ? new Color(0.2f, 0.2f, 0.3f) : new Color(0.9f, 0.9f, 0.95f);
        Button btn = obj.AddComponent<Button>();
        btn.onClick.AddListener(() => AudioManager.Instance.PlayClick());
        btn.onClick.AddListener(()=>onClick());
        
        GameObject tObj = new GameObject("Text");
        tObj.layer = 5; tObj.transform.SetParent(obj.transform, false);
        RectTransform tRT = tObj.AddComponent<RectTransform>();
        tRT.anchorMin = Vector2.zero; tRT.anchorMax = Vector2.one;
        Text t = tObj.AddComponent<Text>();
        t.text = txt; t.font = GetFont(); t.fontSize = 28; 
        t.color = ThemeManager.Instance.GetAccentColor();
        t.alignment = TextAnchor.MiddleCenter;
        t.raycastTarget = false;
        return btn;
    }

    Button MakeButtonWithIcon(Transform parent, string iconName, float x, float y, float w, float h, System.Action onClick)
    {
        GameObject obj = new GameObject("ButtonWithIcon");
        obj.layer = 5;
        obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchoredPosition3D = new Vector3(x, y, 0);
        rt.sizeDelta = new Vector2(w, h);
        Image bgImg = obj.AddComponent<Image>();
        bgImg.color = ThemeManager.Instance.GetAccentColor();
        Button btn = obj.AddComponent<Button>();
        btn.onClick.AddListener(() => AudioManager.Instance.PlayClick());
        btn.onClick.AddListener(()=>onClick());
        
        // Load icon from Resources
        Sprite iconSprite = Resources.Load<Sprite>(iconName);
        if (iconSprite != null)
        {
            GameObject iconObj = new GameObject("Icon");
            iconObj.layer = 5;
            iconObj.transform.SetParent(obj.transform, false);
            RectTransform iconRT = iconObj.AddComponent<RectTransform>();
            iconRT.anchorMin = Vector2.zero;
            iconRT.anchorMax = Vector2.one;
            iconRT.offsetMin = new Vector2(10, 10); // Padding
            iconRT.offsetMax = new Vector2(-10, -10); // Padding
            Image iconImg = iconObj.AddComponent<Image>();
            iconImg.sprite = iconSprite;
            iconImg.color = Color.white;
            iconImg.raycastTarget = false;
            iconImg.preserveAspect = true; // Maintain aspect ratio
        }
        else
        {
            Debug.LogWarning($"Icon '{iconName}' not found in Resources folder!");
        }
        
        return btn;
    }

    // --- LOGIC ---

    // ✅ Show cached balance from wallet data immediately (no "Loading...")
    void ShowCachedBalance()
    {
        WalletData wallet = WalletManager2.Instance.GetCurrentWallet();
        if (wallet == null) return;
        
        string currency = "BTC";
        double cached = wallet.cachedBalance;
        
        if (balanceText)
        {
            balanceText.text = $"{cached:F8} {currency}";
            balanceText.gameObject.SetActive(true);
        }
        
        if (networkText)
        {
            networkText.text = "MainNet";
            networkText.gameObject.SetActive(true);
        }
        
        // Show cached USD value if we have a price
        if (cached > 0)
        {
            StartCoroutine(UpdateUSDValue((float)cached, false));
        }
    }
    
    // ✅ Auto-refresh called by InvokeRepeating
    void AutoRefreshBalance()
    {
        if (WalletManager2.Instance.HasWallet())
        {
            RefreshWalletStatus();
        }
    }

    async void RefreshWalletStatus()
    {
        WalletData wallet = WalletManager2.Instance.GetCurrentWallet();
        if (wallet == null) return;
        string currency = "BTC";

        // ✅ Keep showing old balance during refresh (no status change visible to user)
        Debug.Log("[SendReceiveUI] Background balance refresh started...");
        
        try {
            decimal total = 0;
            
            if (wallet.isPrivateKeyImport || string.IsNullOrEmpty(wallet.seedPhrase))
            {
                // Private key import: scan single address
                BlockCypherApiCore api = new BlockCypherApiCore();
                total = await api.GetBalance(wallet.address, false);
            }
            else
            {
                // Seed phrase wallet: scan all derived addresses
                var result = await transactionService.ScanAllAddresses(
                    wallet.seedPhrase, 
                    null, // ✅ No progress callback (silent refresh)
                    wallet.generatedAddresses,
                    wallet.privateKey
                );
                total = result.confirmedBalance + result.unconfirmedBalance;
            }
            
            // ✅ Save new balance
            wallet.balance = (double)total;
            wallet.cachedBalance = (double)total;
            wallet.lastBalanceUpdate = System.DateTime.Now.ToString("HH:mm:ss");
            
            WalletManager2.Instance.UpdateBalance(wallet.balance);
            WalletManager2.Instance.SyncTransactionHistory();
            
            // ✅ Update display with new balance
            if(balanceText) balanceText.text = $"{total:F8} {currency}";
            StartCoroutine(UpdateUSDValue((float)total, false));
            
            Debug.Log($"[SendReceiveUI] Balance refreshed: {total:F8} BTC");
        } catch (System.Exception ex) { 
            // ✅ On error, keep showing old balance (don't show error to user)
            Debug.LogWarning($"[SendReceiveUI] Background refresh error: {ex.Message}");
        }
    }

    void OnPercentageClick(float percent)
    {
        Debug.Log($"[SendReceiveUI] Percentage Click: {percent}");
        WalletData wallet = WalletManager2.Instance.GetCurrentWallet();
        
        if(wallet == null) {
            Debug.LogError("Wallet is null");
            return;
        }
        
        double bal = wallet.balance;
        Debug.Log($"[SendReceiveUI] Balance: {bal}");
        
        double fee = 0.0000025; 
        if(decimal.TryParse(feeInput.text, out decimal f)) fee = (double)f;
        
        // Logic: Calculate percent, subtract fee only if MAX (approx 1.0)
        double amt = (bal * percent);
        if(percent > 0.99f) amt -= fee;
        
        if(amt < 0) amt = 0;
        
        // Update Input
        // Using 0.######## to avoid "0.00000000" if 0, but keep precision
        sendAmountInput.text = amt.ToString("0.########"); 
        
        Debug.Log($"[SendReceiveUI] New Amount set: {sendAmountInput.text}");
        
        // Trigger generic update (USD value etc)
        OnAmountChanged(sendAmountInput.text);
    }

    void OnAmountChanged(string val) {
        if(float.TryParse(val,out float a)) StartCoroutine(UpdateUSDValue(a,true));
    }

    IEnumerator UpdateUSDValue(float btc, bool isAmt) {
        string currencyCode = PlayerPrefs.GetString("SelectedCurrency", "USD").ToLower();
        string symbol = CurrencyHelper.GetSymbol(currencyCode.ToUpper());
        string url = $"https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies={currencyCode}";

        using(UnityWebRequest req=UnityWebRequest.Get(url)) {
            yield return req.SendWebRequest();
            if(req.result==UnityWebRequest.Result.Success) {
                try {
                    double p = ParsePriceSimple(req.downloadHandler.text, currencyCode);
                    if(p>0) {
                        lastBtcPrice = p;
                        if(usdValueText) usdValueText.text = $"≈ {symbol}{(p*btc):F2} {currencyCode.ToUpper()}";
                        
                        // ✅ Update top bar USD balance too
                        if(!isAmt && balanceUsdText) balanceUsdText.text = $"≈ {symbol}{(p*btc):F2} {currencyCode.ToUpper()}";
                    }
                } catch {}
            }
            else
            {
                // Fallback to Coinpaprika
                yield return StartCoroutine(FetchPriceFallback(btc, isAmt, currencyCode, symbol));
            }
        }
    }

    IEnumerator FetchPriceFallback(float btc, bool isAmt, string currencyCode, string symbol)
    {
        string fallbackUrl = "https://api.coinpaprika.com/v1/tickers/btc-bitcoin";
        using(UnityWebRequest req = UnityWebRequest.Get(fallbackUrl))
        {
            yield return req.SendWebRequest();
            if(req.result == UnityWebRequest.Result.Success)
            {
                try {
                    string json = req.downloadHandler.text;
                    string search = "\"price\":";
                    int idx = json.IndexOf(search);
                    if(idx != -1)
                    {
                        int start = idx + search.Length;
                        int end = json.IndexOf(",", start);
                        if(end == -1) end = json.IndexOf("}", start);
                        if(end != -1)
                        {
                            string numStr = json.Substring(start, end - start);
                            if(double.TryParse(numStr, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out double p))
                            {
                                lastBtcPrice = p;
                                if(usdValueText) usdValueText.text = $"≈ {symbol}{(p*btc):F2} {currencyCode.ToUpper()}";
                                
                                // ✅ Update top bar USD balance too
                                if(!isAmt && balanceUsdText) balanceUsdText.text = $"≈ {symbol}{(p*btc):F2} {currencyCode.ToUpper()}";
                            }
                        }
                    }
                } catch {}
            }
        }
    }

    double ParsePriceSimple(string json, string currency)
    {
        try {
            string search = $"\"{currency}\":";
            int idx = json.IndexOf(search);
            if(idx != -1)
            {
                int start = idx + search.Length;
                int end = json.IndexOf("}", start);
                if(end == -1) end = json.IndexOf(",", start);
                
                if(end != -1)
                {
                    string numStr = json.Substring(start, end - start);
                    if(double.TryParse(numStr, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out double res))
                        return res;
                }
            }
        } catch {}
        return 0;
    }

    // --- IMPROVED SEND FLOW ---
    
    private GameObject confirmationPanel;
    private GameObject resultPanel;
    private Text resultText;
    private Text resultHashText;
    private Text resultIcon;

    void OnSendPressed()
    {
        if(!decimal.TryParse(sendAmountInput.text, out decimal amt)) { ShowStatus(LocalizationManager.Instance.Get("ERR_INVALID_AMT"), Color.red); return; }
        if(string.IsNullOrEmpty(sendAddressInput.text)) { ShowStatus(LocalizationManager.Instance.Get("ERR_INVALID_ADDR"), Color.red); return; }
        
        // Get fee from input field
        decimal fee = 0.0000025m; // Default
        if(decimal.TryParse(feeInput.text, out decimal userFee) && userFee > 0)
        {
            fee = userFee;
        }
        
        // Open Confirmation Panel
        if(confirmationPanel == null) BuildConfirmationPanel();
        
        // Update Confirmation Data with user's fee and USD price
        UpdateConfirmationData(sendAddressInput.text, amt, fee);
        confirmationPanel.SetActive(true);
        confirmationPanel.transform.SetAsLastSibling();
    }
    
    void BuildConfirmationPanel()
    {
        GameObject canvas = GameObject.Find("Canvas");
        confirmationPanel = MakePanel(canvas.transform, "ConfirmPanel", 0, 0, REFERENCE_WIDTH, REFERENCE_HEIGHT, new Color(0,0,0,0.85f));
        
        // Card - Clean dark card matching screenshot
        GameObject card = MakePanel(confirmationPanel.transform, "Card", 0, 50, 950, 900, new Color(0.08f, 0.08f, 0.14f));
        
        // Title: CONFIRM TRANSACTION
        MakeText(card.transform, LocalizationManager.Instance.Get("TX_CONFIRM_TITLE"), 0, 380, 44, Color.white, FontStyle.Bold);
        
        // Divider line below title
        GameObject divider1 = MakePanel(card.transform, "Divider1", 0, 330, 880, 2, new Color(0.3f, 0.3f, 0.4f));
        
        // Destination Address (full, white, left-aligned)
        GameObject addrObj = MakeText(card.transform, "...", 0, 260, 28, Color.white, FontStyle.Normal).gameObject;
        addrObj.name = "addr_val";
        Text addrText = addrObj.GetComponent<Text>();
        addrText.alignment = TextAnchor.MiddleLeft;
        addrText.rectTransform.sizeDelta = new Vector2(860, 80);
        addrText.horizontalOverflow = HorizontalWrapMode.Wrap;
        
        // Divider line below address
        GameObject divider2 = MakePanel(card.transform, "Divider2", 0, 200, 880, 2, new Color(0.3f, 0.3f, 0.4f));
        
        // --- Amount Row ---
        float rowY = 130;
        // BTC amount (left)
        GameObject amtBtcObj = MakeText(card.transform, "0.00000000 BTC", -220, rowY, 32, Color.white, FontStyle.Normal).gameObject;
        amtBtcObj.name = "amt_btc_val";
        amtBtcObj.GetComponent<Text>().alignment = TextAnchor.MiddleLeft;
        amtBtcObj.GetComponent<RectTransform>().sizeDelta = new Vector2(450, 50);
        // ~ USD (right)
        GameObject amtUsdObj = MakeText(card.transform, "~ $0.00 USD", 220, rowY, 36, Color.white, FontStyle.Bold).gameObject;
        amtUsdObj.name = "amt_usd_val";
        amtUsdObj.GetComponent<Text>().alignment = TextAnchor.MiddleRight;
        amtUsdObj.GetComponent<RectTransform>().sizeDelta = new Vector2(400, 50);
        
        // Divider
        GameObject divider3 = MakePanel(card.transform, "Divider3", 0, 85, 880, 1, new Color(0.25f, 0.25f, 0.35f));
        
        // --- Fee Row ---
        float feeY = 40;
        GameObject feeBtcObj = MakeText(card.transform, "0.00000000 BTC", -220, feeY, 32, Color.white, FontStyle.Normal).gameObject;
        feeBtcObj.name = "fee_btc_val";
        feeBtcObj.GetComponent<Text>().alignment = TextAnchor.MiddleLeft;
        feeBtcObj.GetComponent<RectTransform>().sizeDelta = new Vector2(450, 50);
        
        GameObject feeUsdObj = MakeText(card.transform, "~ $0.00 USD", 220, feeY, 36, Color.white, FontStyle.Normal).gameObject;
        feeUsdObj.name = "fee_usd_val";
        feeUsdObj.GetComponent<Text>().alignment = TextAnchor.MiddleRight;
        feeUsdObj.GetComponent<RectTransform>().sizeDelta = new Vector2(400, 50);
        
        // Divider
        GameObject divider4 = MakePanel(card.transform, "Divider4", 0, -5, 880, 1, new Color(0.25f, 0.25f, 0.35f));
        
        // --- Total Row (prominent) ---
        float totalY = -60;
        GameObject totalBtcObj = MakeText(card.transform, "0.00000000 BTC", -220, totalY, 32, Color.white, FontStyle.Bold).gameObject;
        totalBtcObj.name = "total_btc_val";
        totalBtcObj.GetComponent<Text>().alignment = TextAnchor.MiddleLeft;
        totalBtcObj.GetComponent<RectTransform>().sizeDelta = new Vector2(450, 50);
        
        GameObject totalUsdObj = MakeText(card.transform, "~ $0.00 USD", 220, totalY, 38, new Color(0.2f, 1f, 0.2f), FontStyle.Bold).gameObject;
        totalUsdObj.name = "total_usd_val";
        totalUsdObj.GetComponent<Text>().alignment = TextAnchor.MiddleRight;
        totalUsdObj.GetComponent<RectTransform>().sizeDelta = new Vector2(400, 50);
        
        // Divider
        GameObject divider5 = MakePanel(card.transform, "Divider5", 0, -110, 880, 2, new Color(0.3f, 0.3f, 0.4f));
        
        // --- CONFIRM SEND Button (Green) ---
        MakeButton(card.transform, LocalizationManager.Instance.Get("TX_BTN_CONFIRM"), 0, -200, 500, 100, ProcessSend)
            .GetComponent<Image>().color = new Color(0.15f, 0.55f, 0.25f);
        
        // --- Cancel Button (Blue, smaller) ---
        MakeButton(card.transform, LocalizationManager.Instance.Get("TX_BTN_CANCEL"), 0, -320, 300, 70, () => confirmationPanel.SetActive(false))
            .GetComponent<Image>().color = new Color(0.15f, 0.4f, 0.85f);
    }
    
    void UpdateConfirmationData(string addr, decimal amt, decimal fee)
    {
        string currency = PlayerPrefs.GetString("SelectedCurrency", "USD");
        string sym = CurrencyHelper.GetSymbol(currency);
        
        // Set address (full address, no truncation)
        SetText(confirmationPanel, "addr_val", addr);
        
        // Amount row
        SetText(confirmationPanel, "amt_btc_val", $"{amt:F8} BTC");
        // Fee row
        SetText(confirmationPanel, "fee_btc_val", $"{fee:F8} BTC");
        // Total row
        SetText(confirmationPanel, "total_btc_val", $"{amt+fee:F8} BTC");
        
        // USD equivalents
        if (lastBtcPrice > 0)
        {
            SetText(confirmationPanel, "amt_usd_val", $"~ {sym}{((double)amt * lastBtcPrice):F2} {currency}");
            SetText(confirmationPanel, "fee_usd_val", $"~ {sym}{((double)fee * lastBtcPrice):F2} {currency}");
            SetText(confirmationPanel, "total_usd_val", $"~ {sym}{((double)(amt+fee) * lastBtcPrice):F2} {currency}");
        }
        else
        {
            SetText(confirmationPanel, "amt_usd_val", "");
            SetText(confirmationPanel, "fee_usd_val", "");
            SetText(confirmationPanel, "total_usd_val", "");
        }
    }
    
    void SetText(GameObject panel, string name, string val) {
        Transform t = panel.transform.Find("Card")?.Find(name);
        if(t) t.GetComponent<Text>().text = val;
    }

    async void ProcessSend()
    {
        // PIN verification gate - require PIN before broadcasting
        pendingAddress = sendAddressInput.text;
        if(!decimal.TryParse(sendAmountInput.text, out decimal parsedAmt)) return;
        pendingAmount = parsedAmt;
        pendingFee = 0.0000025m;
        if(decimal.TryParse(feeInput.text, out decimal parsedFee) && parsedFee > 0)
            pendingFee = parsedFee;
        
        // Save pending state and require PIN
        pendingPINVerification = true;
        PlayerPrefs.SetInt("PendingTxPIN", 1);
        PlayerPrefs.Save();
        if (confirmationPanel != null) confirmationPanel.SetActive(false);
        SceneManager.LoadScene("AppLock");
    }
    
    async void ExecutePendingTransaction()
    {
        if (confirmationPanel != null) confirmationPanel.SetActive(false);
        
        // Reset cancellation flag
        transactionCancelled = false;
        
        // Show Blocking Loader
        if(loadingPanel == null) BuildLoadingPanel();
        loadingPanel.SetActive(true);
        loadingPanel.transform.SetAsLastSibling();
        
        // Show cancel button
        if (cancelButton != null)
        {
            cancelButton.gameObject.SetActive(true);
        }
        
        if (loadingText != null)
        {
            loadingText.text = LocalizationManager.Instance.Get("TX_PROCESSING_BG");
        }
        
        // Wait 3 seconds with cancel option
        float elapsed = 0f;
        while (elapsed < 3f)
        {
            if (transactionCancelled)
            {
                Debug.Log("❌ [SendReceiveUI] Transaction cancelled by user");
                loadingPanel.SetActive(false);
                ShowResult(false, "", LocalizationManager.Instance.Get("TX_CANCELLED"));
                return;
            }
            
            await System.Threading.Tasks.Task.Delay(100);
            elapsed += 0.1f;
        }
        
        // Hide cancel button after 3 seconds
        if (cancelButton != null)
        {
            cancelButton.gameObject.SetActive(false);
        }
        
        decimal amt = pendingAmount;
        decimal fee = pendingFee;
        
        WalletData w = WalletManager2.Instance.GetCurrentWallet();
        string txAddress = pendingAddress;
        
        // Use BackgroundTransactionService
        BackgroundTransactionService.Instance.QueueTransaction(
            w.seedPhrase,
            false, // Force MainNet
            txAddress,
            amt,
            fee,
            (success, result) => {
                loadingPanel.SetActive(false);
                
                if (success)
                {
                    WalletManager2.Instance.AddTransaction("Send", txAddress, amt.ToString(), result);
                    UpdateAddressBookUI();
                    ShowResult(true, result, "");
                    Debug.Log($"✅ [SendReceiveUI] Transaction completed: {result}");

                    if(NotificationManager.Instance != null)
                    {
                        NotificationManager.Instance.SendNotification("Transaction Sent!", $"Sent {amt} BTC to {txAddress.Substring(0, 6)}...");
                    }
                    
                    StartCoroutine(RefreshBalanceAfterDelay(3f));
                }
                else
                {
                    ShowResult(false, "", result);
                    Debug.LogError($"❌ [SendReceiveUI] Transaction failed: {result}");
                }
            },
            w.privateKey
        );
    }
    
    // ✅ NEW: Helper method to refresh balance after transaction
    IEnumerator RefreshBalanceAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        
        Debug.Log("🔄 Auto-refreshing balance after transaction...");
        RefreshWalletStatus(); // Existing method
    }
    
    void BuildLoadingPanel()
    {
        GameObject canvas = GameObject.Find("Canvas");
        loadingPanel = MakePanel(canvas.transform, "Loader", 0, 0, REFERENCE_WIDTH, REFERENCE_HEIGHT, new Color(0,0,0,0.92f)); 
        
        // Block all interaction on background
        Image blocker = loadingPanel.GetComponent<Image>();
        if (blocker == null) blocker = loadingPanel.AddComponent<Image>();
        blocker.color = new Color(0, 0, 0, 0.92f);
        blocker.raycastTarget = true;
        
        // --- MODAL CARD ---
        GameObject modalCard = MakePanel(loadingPanel.transform, "ModalCard", 0, 0, 850, 450, new Color(0.12f, 0.12f, 0.18f));
        
        // Spinner/hourglass icon
        MakeText(modalCard.transform, "⌛", 0, 150, 80, Color.yellow, FontStyle.Normal);
        
        // Processing text
        loadingText = MakeText(modalCard.transform, LocalizationManager.Instance.Get("TX_PROCESSING_LONG"), 0, 30, 32, Color.white, FontStyle.Bold);
        loadingText.alignment = TextAnchor.MiddleCenter;
        loadingText.rectTransform.sizeDelta = new Vector2(750, 120);
        
        // Cancel button
        GameObject cancelBtnObj = new GameObject("CancelButton");
        cancelBtnObj.transform.SetParent(modalCard.transform, false);
        RectTransform cancelRect = cancelBtnObj.AddComponent<RectTransform>();
        cancelRect.sizeDelta = new Vector2(350, 90);
        cancelRect.anchoredPosition = new Vector2(0, -120);
        
        Image cancelBg = cancelBtnObj.AddComponent<Image>();
        cancelBg.color = new Color(0.8f, 0.2f, 0.2f);
        
        cancelButton = cancelBtnObj.AddComponent<Button>();
        cancelButton.onClick.AddListener(() => {
            transactionCancelled = true;
            Debug.Log("[SendReceiveUI] User clicked cancel button");
        });
        
        Text cancelText = MakeText(cancelBtnObj.transform, LocalizationManager.Instance.Get("TX_CANCEL_BTN"), 0, 0, 32, Color.white, FontStyle.Bold);
        cancelText.alignment = TextAnchor.MiddleCenter;
        
        // Start hidden (shown during 3-second window)
        cancelButton.gameObject.SetActive(false);
    }
    
    void ShowResult(bool success, string hash, string error)
    {
        if(resultPanel == null) BuildResultPanel();
        resultPanel.SetActive(true);
        resultPanel.transform.SetAsLastSibling();
        
        if(success) {
            resultText.text = LocalizationManager.Instance.Get("TX_SUCCESS");
            resultText.color = Color.green;
            resultIcon.color = Color.green;
            resultHashText.text = LocalizationManager.Instance.Get("TX_HASH_PREFIX") + hash;
        } else {
            resultText.text = LocalizationManager.Instance.Get("TX_FAILED");
            resultText.color = Color.red;
            resultIcon.color = Color.red;
            resultHashText.text = error;
        }
    }
    
    void BuildResultPanel()
    {
        GameObject canvas = GameObject.Find("Canvas");
        resultPanel = MakePanel(canvas.transform, "Result", 0, 0, REFERENCE_WIDTH, REFERENCE_HEIGHT, new Color(0,0,0,0.9f));
        
        GameObject card = MakePanel(resultPanel.transform, "Card", 0, 0, 900, 700, ThemeManager.Instance.GetCardColor());
        
        GameObject iconObj = MakeText(card.transform, "✔", 0, 200, 80, Color.green, FontStyle.Bold).gameObject;
        resultIcon = iconObj.GetComponent<Text>();
        
        GameObject tObj = MakeText(card.transform, LocalizationManager.Instance.Get("TX_SUCCESS_TITLE"), 0, 100, 40, Color.green, FontStyle.Bold).gameObject;
        resultText = tObj.GetComponent<Text>();
        
        GameObject hObj = MakeText(card.transform, "Hash...", 0, -50, 24, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Normal).gameObject;
        resultHashText = hObj.GetComponent<Text>();
        
        MakeButton(card.transform, LocalizationManager.Instance.Get("TX_DONE"), 0, -200, 400, 100, () => resultPanel.SetActive(false));
    }

    void ShowStatus(string m, Color c) { if(statusText){ statusText.text=m; statusText.color=c; CancelInvoke("ClearStatus"); Invoke("ClearStatus",5f); }}
    void ClearStatus(){ if(statusText) statusText.text=""; }
    
    // --- RECEIVE & SCAN logic kept similar but condensed ---
    void OnShowReceive(){ receivePanel.SetActive(true); WalletData w=WalletManager2.Instance.GetCurrentWallet(); if(w!=null) GenerateQRCode(w.address); }
    void CreateReceivePanel(Transform p){ 
        // Force Dark BG for QR Code clarity
        receivePanel = MakePanel(p,"Rec",0,0,REFERENCE_WIDTH,REFERENCE_HEIGHT,new Color(0,0,0,0.95f));
        receivePanel.SetActive(false);
        GameObject c=MakePanel(receivePanel.transform,"Card",0,0,900,800, ThemeManager.Instance.GetCardColor());
        MakeText(c.transform, LocalizationManager.Instance.Get("RECEIVE_TITLE"), 0, 350, 40, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);
        WalletData w=WalletManager2.Instance.GetCurrentWallet();
        MakeText(c.transform,w!=null?w.address:"...",0,250,24,ThemeManager.Instance.GetAccentColor(),FontStyle.Normal);
        MakeButton(c.transform, LocalizationManager.Instance.Get("BTN_COPY_ADDRESS"),0,150,300,80,()=>{GUIUtility.systemCopyBuffer=(w!=null?w.address:"");});
        GameObject q=new GameObject("QR"); q.transform.SetParent(c.transform,false); q.AddComponent<RectTransform>().anchoredPosition3D=new Vector3(0,-100,0);
        q.GetComponent<RectTransform>().sizeDelta=new Vector2(400,400); q.AddComponent<Image>();
        MakeButton(c.transform, LocalizationManager.Instance.Get("GEN_CLOSE"),0,-350,300,80,()=>receivePanel.SetActive(false));
    }
    void GenerateQRCode(string t){ 
        try{ 
            var w=new QRCodeWriter(); var m=w.encode(t,BarcodeFormat.QR_CODE,256,256);
            int W=m.Width, H=m.Height; var T=new Texture2D(W,H); 
            var P=new Color32[W*H]; for(int y=0;y<H;y++)for(int x=0;x<W;x++)P[y*W+x]=m[x,y]?Color.black:Color.white;
            T.SetPixels32(P); T.Apply();
            receivePanel.transform.Find("Card").Find("QR").GetComponent<Image>().sprite=Sprite.Create(T,new Rect(0,0,W,H),new Vector2(0.5f,0.5f));
        }catch{}
    }
    
    void StopCamera() 
    { 
        if(webCamTexture != null) webCamTexture.Stop(); 
    }

    void OnScanQR()
    {
        #if UNITY_ANDROID
        if (!Permission.HasUserAuthorizedPermission(Permission.Camera))
        {
            Permission.RequestUserPermission(Permission.Camera);
            ShowStatus("Please allow Camera access and try again", Color.yellow);
            return;
        }
        #endif

        if (WebCamTexture.devices.Length == 0)
        {
            ShowStatus("No Camera Found", Color.red);
            return;
        }

        scanPanel.SetActive(true);
        isScanPanelVisible = true;
        
        webCamTexture = new WebCamTexture();
        cameraDisplay.texture = webCamTexture;
        webCamTexture.Play();
        
        // Wait briefly for camera to initialize properties
        StartCoroutine(ScanRoutine());
    }

    void CreateScanPanel(Transform p){
        scanPanel = MakePanel(p,"Scan",0,0,REFERENCE_WIDTH,REFERENCE_HEIGHT,Color.black); scanPanel.SetActive(false);
        GameObject c=MakePanel(scanPanel.transform,"Card",0,0,900,800, ThemeManager.Instance.GetCardColor());
        GameObject cam=new GameObject("Cam"); cam.transform.SetParent(c.transform,false); 
        cameraDisplay=cam.AddComponent<RawImage>(); cam.GetComponent<RectTransform>().sizeDelta=new Vector2(500,500);
        MakeButton(c.transform, LocalizationManager.Instance.Get("TX_CANCEL_BTN"),0,-350,300,80,()=>{isScanPanelVisible=false; scanPanel.SetActive(false); StopCamera();});
    }
    
    IEnumerator ScanRoutine(){
        var r=new ZXing.QrCode.QRCodeReader();
        
        // --- ROTATION FIX START ---
        // Wait until we have valid dimensions
        while(isScanPanelVisible && webCamTexture.isPlaying && webCamTexture.width < 100) 
            yield return null;

        if(isScanPanelVisible && webCamTexture.isPlaying)
        {
            int angle = webCamTexture.videoRotationAngle;
            bool mirrored = webCamTexture.videoVerticallyMirrored;
            
            RectTransform rt = cameraDisplay.rectTransform;
            
            // Allow rotation
            rt.localEulerAngles = new Vector3(0, 0, -angle);
            
            // Handle mirroring and aspect ratio
            float scaleY = mirrored ? -1f : 1f;
            rt.localScale = new Vector3(1f, scaleY, 1f);
            
            // Adjust size to fit container if rotated 90/270
            // (Optional refinement, but basic rotation is key request)
        }
        // --- ROTATION FIX END ---

        while(isScanPanelVisible&&webCamTexture.isPlaying){
            try{ var res=r.decode(new BinaryBitmap(new HybridBinarizer(new Color32LuminanceSource(webCamTexture.GetPixels32(),webCamTexture.width,webCamTexture.height))));
                 if(res!=null){ sendAddressInput.text=res.Text; isScanPanelVisible=false; scanPanel.SetActive(false); StopCamera(); }
            }catch{} yield return new WaitForSeconds(0.5f);
        }
    }
    
    void ShowAddressBookOverlay()
    {
        if (addressBookOverlay != null) { Destroy(addressBookOverlay); }
        
        GameObject canvas = GameObject.Find("Canvas");
        addressBookOverlay = MakePanel(canvas.transform, "AddrBookOverlay", 0, 0, REFERENCE_WIDTH, REFERENCE_HEIGHT, new Color(0, 0, 0, 0.9f));
        
        GameObject card = MakePanel(addressBookOverlay.transform, "Card", 0, 50, 950, 1400, ThemeManager.Instance.GetCardColor());
        
        MakeText(card.transform, LocalizationManager.Instance.Get("ADDR_BOOK_TITLE"), 0, 600, 42, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);
        
        // List saved addresses
        var entries = AddressBookManager.Instance.GetEntries();
        float y = 450;
        
        if (entries.Count == 0)
        {
            MakeText(card.transform, LocalizationManager.Instance.Get("ADDR_BOOK_EMPTY"), 0, y, 28, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Italic);
        }
        else
        {
            for (int i = 0; i < entries.Count && i < 6; i++)
            {
                var entry = entries[i];
                string displayAddr = entry.address.Length > 18 ? entry.address.Substring(0, 18) + "..." : entry.address;
                string displayName = string.IsNullOrEmpty(entry.name) ? "Unnamed" : entry.name;
                
                // Name
                MakeText(card.transform, displayName, -250, y, 28, ThemeManager.Instance.GetTextColor(), FontStyle.Bold).GetComponent<RectTransform>().sizeDelta = new Vector2(400, 40);
                // Address
                MakeText(card.transform, displayAddr, -250, y - 30, 22, ThemeManager.Instance.GetAccentColor(), FontStyle.Normal).GetComponent<RectTransform>().sizeDelta = new Vector2(400, 30);
                
                // Use button
                string capturedAddr = entry.address;
                MakeButton(card.transform, LocalizationManager.Instance.Get("BTN_USE"), 280, y - 10, 120, 60, () => {
                    sendAddressInput.text = capturedAddr;
                    Destroy(addressBookOverlay);
                }).GetComponent<Image>().color = ThemeManager.Instance.GetAccentColor();
                
                // Delete button
                MakeButton(card.transform, "✕", 380, y - 10, 60, 60, () => {
                    AddressBookManager.Instance.DeleteEntry(capturedAddr);
                    Destroy(addressBookOverlay);
                    ShowAddressBookOverlay(); // Refresh
                }).GetComponent<Image>().color = ThemeManager.Instance.GetErrorColor();
                
                y -= 100;
            }
        }
        
        // --- Add New Section ---
        y -= 40;
        MakeText(card.transform, LocalizationManager.Instance.Get("ADDR_BOOK_ADD"), 0, y, 32, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);
        y -= 70;
        
        InputField nameInput = MakeInput(card.transform, 0, y, 850, 80, LocalizationManager.Instance.Get("ADDR_BOOK_NAME"));
        y -= 100;
        InputField addrInput = MakeInput(card.transform, 0, y, 850, 80, LocalizationManager.Instance.Get("ADDR_BOOK_ADDR"));
        
        // Pre-fill with current send address if available
        if (!string.IsNullOrEmpty(sendAddressInput.text))
        {
            addrInput.text = sendAddressInput.text;
        }
        
        y -= 100;
        MakeButton(card.transform, LocalizationManager.Instance.Get("ADDR_BOOK_ADD"), 0, y, 400, 90, () => {
            if (!string.IsNullOrEmpty(addrInput.text))
            {
                AddressBookManager.Instance.AddEntry(nameInput.text, addrInput.text);
                ShowStatus(LocalizationManager.Instance.Get("ADDR_BOOK_SAVED"), Color.green);
                Destroy(addressBookOverlay);
                ShowAddressBookOverlay(); // Refresh
            }
        }).GetComponent<Image>().color = ThemeManager.Instance.GetSuccessColor();
        
        // Close
        MakeButton(card.transform, LocalizationManager.Instance.Get("GEN_CLOSE"), 0, -620, 400, 90, () => {
            Destroy(addressBookOverlay);
        }).GetComponent<Image>().color = new Color(0.3f, 0.3f, 0.4f);
        
        addressBookOverlay.transform.SetAsLastSibling();
    }

    void UpdateAddressBookUI(){
        foreach(Transform t in addressBookContainer.transform) if(t.name.Contains("Row")) Destroy(t.gameObject);
        WalletData w=WalletManager2.Instance.GetCurrentWallet(); if(w==null||w.transactions==null)return;
        HashSet<string> seen=new HashSet<string>(); float y=70; int c=0;
        for(int i=w.transactions.Count-1;i>=0;i--){
            var tx=w.transactions[i];
            if(tx.type=="Send"&&!seen.Contains(tx.address)){
                seen.Add(tx.address);
                GameObject r=new GameObject("Row"); r.layer=5; r.transform.SetParent(addressBookContainer.transform,false);
                r.AddComponent<RectTransform>().anchoredPosition3D=new Vector3(0,y,0);
                MakeText(r.transform,tx.address.Length>20?tx.address.Substring(0,20):tx.address,-100,0,26,ThemeManager.Instance.GetAccentColor(),FontStyle.Normal).GetComponent<RectTransform>().sizeDelta=new Vector2(600,60);
                MakeButton(r.transform, LocalizationManager.Instance.Get("BTN_USE"),350,0,120,50,()=>sendAddressInput.text=tx.address);
                y-=60; c++; if(c>=3)break;
            }
        }
    }
}
