using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class OptionsUI : MonoBehaviour
{
    // UI
    private const float REFERENCE_WIDTH = 1080f;
    private const float REFERENCE_HEIGHT = 1920f;
    
    private Text feedbackText;

    void Start()
    {
        BuildUI();
    }

    void BuildUI()
    {
        GameObject canvasObj = new GameObject("Canvas");
        canvasObj.layer = 5;
        Canvas canvas = canvasObj.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        CanvasScaler scaler = canvasObj.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(REFERENCE_WIDTH, REFERENCE_HEIGHT);
        scaler.matchWidthOrHeight = 0.5f;
        canvasObj.AddComponent<GraphicRaycaster>();

        // THEME: BG
        MakePanel(canvas.transform, "BG", 0, 0, REFERENCE_WIDTH, REFERENCE_HEIGHT, ThemeManager.Instance.GetBackgroundColor());

        // Top Bar
        GameObject topBar = MakePanel(canvas.transform, "TopBar", 0, 0, REFERENCE_WIDTH, 200, ThemeManager.Instance.GetCardColor());
        RectTransform topBarRT = topBar.GetComponent<RectTransform>();
        topBarRT.anchorMin = new Vector2(0, 1);
        topBarRT.anchorMax = new Vector2(1, 1);
        topBarRT.pivot = new Vector2(0.5f, 1);
        topBarRT.anchoredPosition = Vector2.zero;

        MakeButton(topBar.transform, LocalizationManager.Instance.Get("GEN_BACK"), -400, 0, 200, 80, () => SceneManager.LoadScene("MainWallet"))
            .GetComponent<Image>().color = ThemeManager.Instance.GetAccentColor();
        MakeText(topBar.transform, LocalizationManager.Instance.Get("MENU_TITLE"), 0, 0, 40, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);

        // Content
        float y = 450;
        float spacing = 140; // Reduced spacing to fit more items

        // 0. Address Log (New)
        MakeButton(canvas.transform, LocalizationManager.Instance.Get("MENU_ADDR_LOG"), 0, y, 800, 120, () => SceneManager.LoadScene("Address Log"))
             .GetComponent<Image>().color = new Color(1f, 0.8f, 0.2f); // Gold/Yellowish
        y -= spacing;

        // 1. Change Theme
        string themeBtnText = ThemeManager.Instance.IsDarkMode ? LocalizationManager.Instance.Get("MENU_THEME_LIGHT") : LocalizationManager.Instance.Get("MENU_THEME_DARK");
        MakeButton(canvas.transform, themeBtnText, 0, y, 800, 120, OnToggleTheme);
        y -= spacing;

        // 2. Change Password
        MakeButton(canvas.transform, LocalizationManager.Instance.Get("MENU_PIN"), 0, y, 800, 120, OnResetPin)
            .GetComponent<Image>().color = new Color(0.3f, 0.4f, 0.5f);
        y -= spacing;

        // 3. Create New Wallet
        MakeButton(canvas.transform, LocalizationManager.Instance.Get("MENU_CREATE"), 0, y, 800, 120, OnCreateNewWallet)
             .GetComponent<Image>().color = new Color(0.2f, 0.6f, 0.3f);
        y -= spacing;
        
        y -= 250;
        feedbackText = MakeText(canvas.transform, "", 0, y, 32, ThemeManager.Instance.GetAccentColor(), FontStyle.Italic);
    }
    
    void OnToggleTheme()
    {
        ThemeManager.Instance.ToggleTheme();
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex); // Reload to apply
    }
    
    void OnCreateNewWallet()
    {
        SceneManager.LoadScene(2);
    }
    
    // Kept for compatibility if referenced, but unused in new UI
    void OnExport()
    {
        WalletFileService.ExportWallet();
        feedbackText.text = LocalizationManager.Instance.Get("GEN_EXPORTED");
        feedbackText.color = Color.green;
        Invoke("ClearFeedback", 3f);
    }
    
    void OnResetPin()
    {
        AuthManager.Instance.ResetAuth();
        SceneManager.LoadScene("MainWallet");
    }
    
    void ClearFeedback() { feedbackText.text =""; }

    // --- HELPERS ---

    Font GetFont() {
        Font f = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        if (f == null) f = Resources.GetBuiltinResource<Font>("Arial.ttf");
        return f;
    }

    GameObject MakePanel(Transform parent, string name, float x, float y, float w, float h, Color color) {
        GameObject obj = new GameObject(name);
        obj.layer = 5;
        obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchoredPosition3D = new Vector3(x, y, 0);
        rt.sizeDelta = new Vector2(w, h);
        obj.AddComponent<Image>().color = color;
        return obj;
    }

    Text MakeText(Transform parent, string txt, float x, float y, int size, Color col, FontStyle style) {
        GameObject obj = new GameObject("Text");
        obj.layer = 5;
        obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchoredPosition3D = new Vector3(x, y, 0);
        rt.sizeDelta = new Vector2(950, 80);
        Text text = obj.AddComponent<Text>();
        text.text = txt; text.fontSize = size; text.color = col; text.fontStyle = style; text.font = GetFont();
        text.alignment = TextAnchor.MiddleCenter;
        text.raycastTarget = false; 
        return text;
    }

    Button MakeButton(Transform parent, string txt, float x, float y, float w, float h, System.Action onClick) {
        GameObject obj = new GameObject("Button");
        obj.layer = 5;
        obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchoredPosition3D = new Vector3(x, y, 0);
        rt.sizeDelta = new Vector2(w, h);
        Image img = obj.AddComponent<Image>();
        img.color = ThemeManager.Instance.GetAccentColor();
        Button btn = obj.AddComponent<Button>();
        btn.onClick.AddListener(()=>onClick());
        if(!string.IsNullOrEmpty(txt)){
            GameObject tObj = new GameObject("Text");
            tObj.layer = 5; tObj.transform.SetParent(obj.transform, false);
            RectTransform tRT = tObj.AddComponent<RectTransform>();
            tRT.anchorMin = Vector2.zero; tRT.anchorMax = Vector2.one;
            Text t = tObj.AddComponent<Text>();
            t.text = txt; t.fontSize = 32; t.color = Color.white; t.font = GetFont();
            t.alignment = TextAnchor.MiddleCenter; t.fontStyle = FontStyle.Bold;
            t.raycastTarget = false;
        }
        return btn;
    }
}
