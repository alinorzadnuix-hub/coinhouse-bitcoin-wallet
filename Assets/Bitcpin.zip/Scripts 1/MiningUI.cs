using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Diagnostics;
using Debug = UnityEngine.Debug;

public class MiningUI : MonoBehaviour
{
    // UI References
    private Text hashrateText;
    private Text sharesText;
    private Text timeText;
    private Text hashDisplayText;

    private Text logText;
    private Text statusText;
    private Text cpuPercentText;
    private InputField addressInput;
    private Slider threadSlider;
    private Text threadCountText;
    private Slider cpuSlider;
    private Button toggleButton;
    private Text toggleButtonText;


    // Mining State
    private bool isMining = false;
    private int threadCount = 1;
    private int cpuPercent = 50; // Default 50% CPU usage
    private long totalHashes = 0;
    private long sessionHashes = 0;

    private double hashrate = 0;
    private volatile string lastHashHex = "";
    private Stopwatch sessionTimer;
    private List<Task> miningTasks = new List<Task>();
    private CancellationTokenSource cts;
    
    // Config
    private const float REFERENCE_WIDTH = 1080f;
    private const float REFERENCE_HEIGHT = 1920f;
    private string walletAddress = "";

    void Start()
    {
        // Default to 1 thread
        threadCount = 1;
        cpuPercent = 50;
        
        // Load Wallet Address
        if(WalletManager2.Instance.HasWallet())
        {
            walletAddress = WalletManager2.Instance.GetCurrentWallet().address;
        }

        // Ensure EventSystem exists
        if (UnityEngine.EventSystems.EventSystem.current == null)
        {
            GameObject es = new GameObject("EventSystem");
            es.AddComponent<UnityEngine.EventSystems.EventSystem>();
            es.AddComponent<UnityEngine.EventSystems.StandaloneInputModule>();
        }

        BuildUI();
        
        // Start stats updater
        InvokeRepeating("UpdateStats", 1f, 1f);
    }

    void OnDestroy()
    {
        StopMining();
    }

    // --- MINING LOGIC ---

    void ToggleMining()
    {
        if (isMining) StopMining();
        else StartMining();
        
        UpdateUIState();
    }

    void StartMining()
    {
        if (isMining) return;
        
        isMining = true;
        sessionHashes = 0;
        sessionTimer = Stopwatch.StartNew();
        cts = new CancellationTokenSource();
        
        // Update UI immediately
        statusText.text = LocalizationManager.Instance.GetFormat("MINE_STATUS_MINING", threadCount);
        statusText.color = ThemeManager.Instance.GetSuccessColor();
        sharesText.text = LocalizationManager.Instance.Get("MINE_STATUS_MINING_SHORT");
        sharesText.color = ThemeManager.Instance.GetSuccessColor();

        
        Log($"Starting Miner on {threadCount} threads @ {cpuPercent}% CPU...");
        Log($"Target: {addressInput.text}");
        
        // Notify
        if(NotificationManager.Instance) NotificationManager.Instance.SendNotification("Bitcoin Miner", "Miner Started - Background Mining Active");

        // Start Threads
        for (int i = 0; i < threadCount; i++)
        {
            int threadId = i;
            int cpuPct = cpuPercent; // Capture value
            Task.Run(() => MiningLoop(cts.Token, threadId, cpuPct), cts.Token);
        }
    }

    void StopMining()
    {
        if (!isMining) return;
        
        isMining = false;
        if(cts != null) cts.Cancel();
        if(sessionTimer != null) sessionTimer.Stop();
        
        // Notify
        if(NotificationManager.Instance) NotificationManager.Instance.SendNotification("Bitcoin Miner", "Miner Stopped");
        
        Log("🛑 Miner Stopped.");
    }

    // The "Real" Work - with CPU usage control
    void MiningLoop(CancellationToken token, int id, int cpuUsagePercent)
    {
        using (SHA256 sha256 = SHA256.Create())
        {
            byte[] buffer = new byte[80]; // Mock Block Header (80 bytes)
            new System.Random(id).NextBytes(buffer); // Randomize start
            
            // Calculate sleep interval based on CPU usage percentage
            // At 100%: no sleep (full CPU stress, will cause lag)
            // At 50%: sleep 1ms every iteration
            // At 10%: sleep 9ms every iteration
            int batchSize = 100; // Process in batches for efficiency
            int sleepMs = 0;
            if (cpuUsagePercent < 100)
            {
                // Calculate how much time to sleep per batch
                // At 0%: almost all sleep. At 99%: almost no sleep.
                sleepMs = (int)((100 - cpuUsagePercent) * 0.1f); // 0-10ms range
                if (sleepMs < 1 && cpuUsagePercent < 100) sleepMs = 1;
            }
            
            int counter = 0;
            
            while (!token.IsCancellationRequested)
            {
                // Double SHA256 (Hash256) - Bitcoin Standard
                byte[] hash1 = sha256.ComputeHash(buffer);
                byte[] hash2 = sha256.ComputeHash(hash1); // Proof of Work
                
                // Increment Nonce
                buffer[79]++;
                if (buffer[79] == 0) buffer[78]++;
                if (buffer[78] == 0) buffer[77]++;
                
                // Count work
                long currentCount = Interlocked.Increment(ref totalHashes);
                Interlocked.Increment(ref sessionHashes);
                
                // Store current hash hex (update every 1000 hashes for performance)
                if (currentCount % 1000 == 0)
                {
                    System.Text.StringBuilder sb = new System.Text.StringBuilder(64);
                    for (int i = 0; i < hash2.Length; i++)
                        sb.Append(hash2[i].ToString("x2"));
                    lastHashHex = sb.ToString();
                }
                
                // Difficulty Check (Simulation for "Share Found")
                if (hash2[0] == 0 && hash2[1] == 0 && hash2[2] < 10) 
                {
                    // Found a share!
                }
                
                // CPU Usage Control: sleep periodically to reduce CPU pressure
                counter++;
                if (sleepMs > 0 && counter >= batchSize)
                {
                    counter = 0;
                    Thread.Sleep(sleepMs);
                }
                
                // At 100% CPU: intentionally don't yield at all
                // This causes maximum CPU stress and visible lag (user requested)
            }
        }
    }

    void UpdateStats()
    {
        if(!isMining || sessionTimer == null) return;
        
        double elapsed = sessionTimer.Elapsed.TotalSeconds;
        if (elapsed > 0)
        {
            double hps = sessionHashes / elapsed;
            hashrate = hps;
            
            // Format hashrate with proper units
            string rate;
            if (hps >= 1000000000) rate = $"{hps/1000000000.0:F2} GH/s";
            else if (hps >= 1000000) rate = $"{hps/1000000.0:F2} MH/s";
            else if (hps >= 1000) rate = $"{hps/1000.0:F2} kH/s";
            else rate = $"{hps:F0} H/s";
            
            hashrateText.text = rate;
            
            // Hash Display
            if(hashDisplayText != null && !string.IsNullOrEmpty(lastHashHex))
            {
                hashDisplayText.text = lastHashHex;
            }
            
            // Time
            System.TimeSpan t = sessionTimer.Elapsed;
            timeText.text = string.Format("{0:D2}:{1:D2}:{2:D2}", t.Hours, t.Minutes, t.Seconds);
        }
    }
    
    void Log(string msg)
    {
        if(logText) logText.text = $"> {msg}\n" + logText.text;
        if(logText.text.Length > 500) logText.text = logText.text.Substring(0, 500);
    }
    
    // --- UI CONSTRUCTION ---

    void BuildUI()
    {
        GameObject canvasObj = new GameObject("Canvas");
        Canvas canvas = canvasObj.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        CanvasScaler scaler = canvasObj.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(REFERENCE_WIDTH, REFERENCE_HEIGHT);
        scaler.matchWidthOrHeight = 0.5f;
        canvasObj.AddComponent<GraphicRaycaster>();
        
        // BG
        MakePanel(canvas.transform, "BG", 0, 0, REFERENCE_WIDTH, REFERENCE_HEIGHT, ThemeManager.Instance.GetBackgroundColor());

        // Header
        GameObject topBar = MakePanel(canvas.transform, "TopBar", 0, 0, REFERENCE_WIDTH, 200, ThemeManager.Instance.GetCardColor());
        RectTransform rt = topBar.GetComponent<RectTransform>();
        rt.anchorMin = new Vector2(0.5f, 1); rt.anchorMax = new Vector2(0.5f, 1); rt.anchoredPosition = new Vector2(0, -100);
        
        MakeButton(topBar.transform, "←", -450, 0, 120, 100, GoBack);
        MakeText(topBar.transform, LocalizationManager.Instance.Get("MINE_TITLE"), 0, 0, 48, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);
        
        // 1. Status Card (Hashrate Visualization)
        GameObject statusCard = MakeCard(canvas.transform, 0, 550, 950, 400);
        
        // Title
        MakeText(statusCard.transform, LocalizationManager.Instance.Get("MINE_CARD_TITLE"), 0, 180, 56, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);
        MakeText(statusCard.transform, LocalizationManager.Instance.Get("MINE_ALGO"), 0, 120, 28, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Normal);

        // Stats Container
        GameObject statsObj = MakePanel(statusCard.transform, "Stats", 0, -20, 850, 250, ThemeManager.Instance.GetCardColor());
        
        // Hashrate (Big) - wider text area for large numbers
        hashrateText = MakeText(statsObj.transform, "0 H/s", 0, 50, 72, ThemeManager.Instance.GetAccentColor(), FontStyle.Bold);
        hashrateText.rectTransform.sizeDelta = new Vector2(800, 90); // Wider for large hashrate values
        hashrateText.resizeTextForBestFit = true;
        hashrateText.resizeTextMinSize = 36;
        hashrateText.resizeTextMaxSize = 72;
        
        // Status
        statusText = MakeText(statsObj.transform, LocalizationManager.Instance.Get("MINE_STATUS_READY"), 0, 0, 32, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Normal);
        
        // Time
        timeText = MakeText(statsObj.transform, "00:00:00", 0, -40, 28, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Normal);
        
        // Shares
        sharesText = MakeText(statsObj.transform, LocalizationManager.Instance.Get("MINE_STATUS_READY_SHORT"), 0, -80, 28, ThemeManager.Instance.GetAccentColor(), FontStyle.Bold);
        
        // Difficulty info
        MakeText(statsObj.transform, LocalizationManager.Instance.Get("MINE_DIFFICULTY_SIMULATED"), 0, -115, 24, new Color(0.5f, 0.5f, 0.5f), FontStyle.Italic);
        
        // Current Hash Display
        MakeText(statusCard.transform, LocalizationManager.Instance.Get("MINE_CURRENT_HASH"), 0, -180, 24, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Bold);
        hashDisplayText = MakeText(statusCard.transform, "---", 0, -210, 18, ThemeManager.Instance.GetAccentColor(), FontStyle.Normal);
        hashDisplayText.rectTransform.sizeDelta = new Vector2(900, 40);
        hashDisplayText.alignment = TextAnchor.MiddleCenter;

        // 2. Config Card
        GameObject configCard = MakeCard(canvas.transform, 0, 20, 950, 600);
        
        MakeText(configCard.transform, LocalizationManager.Instance.Get("MINE_CONFIG"), 0, 260, 36, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);
        
        // Address
        MakeText(configCard.transform, LocalizationManager.Instance.Get("MINE_ADDR"), -200, 180, 28, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Normal);
        addressInput = MakeInput(configCard.transform, 0, 110, 850, 80, walletAddress);
        
        // Threads
        MakeText(configCard.transform, LocalizationManager.Instance.Get("MINE_THREADS"), -200, 20, 28, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Normal);
        threadCountText = MakeText(configCard.transform, threadCount.ToString(), 350, 20, 36, ThemeManager.Instance.GetAccentColor(), FontStyle.Bold);
        
        threadSlider = MakeSlider(configCard.transform, 0, -50, 850, 60);
        threadSlider.minValue = 1;
        threadSlider.maxValue = System.Math.Max(System.Environment.ProcessorCount, 2);
        threadSlider.value = threadCount;
        threadSlider.onValueChanged.AddListener((v) => {
            threadCount = (int)v;
            threadCountText.text = threadCount.ToString();
            if(isMining) { StopMining(); StartMining(); }
        });

        // CPU Usage Percentage
        MakeText(configCard.transform, LocalizationManager.Instance.Get("MINE_CPU_USAGE"), -200, -120, 28, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Normal);
        cpuPercentText = MakeText(configCard.transform, $"{cpuPercent}%", 350, -120, 36, ThemeManager.Instance.GetAccentColor(), FontStyle.Bold);
        
        cpuSlider = MakeSlider(configCard.transform, 0, -190, 850, 60);
        cpuSlider.minValue = 10;
        cpuSlider.maxValue = 100;
        cpuSlider.value = cpuPercent;
        cpuSlider.wholeNumbers = true;
        cpuSlider.onValueChanged.AddListener((v) => {
            cpuPercent = (int)v;
            cpuPercentText.text = $"{cpuPercent}%";
            
            // Change color based on percentage (green to red)
            if (cpuPercent >= 90) cpuPercentText.color = new Color(1f, 0.2f, 0.2f); // Red - danger
            else if (cpuPercent >= 70) cpuPercentText.color = new Color(1f, 0.5f, 0f); // Orange - warning 
            else cpuPercentText.color = ThemeManager.Instance.GetAccentColor(); // Normal
            
            if(isMining) { StopMining(); StartMining(); }
        });
        
        // Warning text for high CPU usage
        Text warnText = MakeText(configCard.transform, "⚠️ 100% = Maximum stress (app will lag)", 0, -240, 22, new Color(0.7f, 0.4f, 0.1f), FontStyle.Italic);
        warnText.rectTransform.sizeDelta = new Vector2(850, 30);

        // 3. Action
        toggleButton = MakeButton(canvas.transform, LocalizationManager.Instance.Get("MINE_BTN_START"), 0, -430, 800, 140, ToggleMining);
        toggleButton.GetComponent<Image>().color = new Color(1f, 0.5f, 0f); // Orange
        toggleButtonText = toggleButton.GetComponentInChildren<Text>();

        // 4. Log
        GameObject logCard = MakeCard(canvas.transform, 0, -750, 950, 350);
        MakeText(logCard.transform, LocalizationManager.Instance.Get("MINE_LOG"), -350, 140, 28, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Bold);
        logText = MakeText(logCard.transform, LocalizationManager.Instance.Get("MINE_LOG_READY"), 0, -30, 24, new Color(0.6f, 0.3f, 0.9f), FontStyle.Normal);
        logText.alignment = TextAnchor.UpperLeft;
        logText.rectTransform.sizeDelta = new Vector2(850, 280);
        logText.rectTransform.pivot = new Vector2(0.5f, 0.5f); 
    }
    
    void UpdateUIState()
    {
        if (isMining)
        {
            double elapsed = sessionTimer.Elapsed.TotalSeconds;
            if (elapsed > 0)
            {
                hashrate = sessionHashes / elapsed;
            }
            
            // Format Hashrate properly
            string hrStr;
            if (hashrate >= 1000000000) hrStr = $"{hashrate / 1000000000.0:F2} GH/s";
            else if (hashrate >= 1000000) hrStr = $"{hashrate / 1000000.0:F2} MH/s";
            else if (hashrate >= 1000) hrStr = $"{hashrate / 1000.0:F2} kH/s";
            else hrStr = $"{hashrate:F0} H/s";
            
            hashrateText.text = hrStr;
            statusText.text = LocalizationManager.Instance.GetFormat("MINE_STATUS_MINING", threadCount);
            statusText.color = ThemeManager.Instance.GetSuccessColor();
            sharesText.text = LocalizationManager.Instance.Get("MINE_STATUS_MINING_SHORT");
            sharesText.color = ThemeManager.Instance.GetSuccessColor();
            
            System.TimeSpan t = sessionTimer.Elapsed;
            timeText.text = string.Format("{0:D2}:{1:D2}:{2:D2}", t.Hours, t.Minutes, t.Seconds);

            toggleButtonText.text = LocalizationManager.Instance.Get("MINE_BTN_STOP");
            toggleButton.GetComponent<Image>().color = new Color(0.8f, 0.2f, 0.2f);

            addressInput.interactable = false;
        }
        else
        {
            hashrate = 0;
            hashrateText.text = "0 H/s";
            statusText.text = LocalizationManager.Instance.Get("MINE_STATUS_STOPPED");
            statusText.color = ThemeManager.Instance.GetSecondaryTextColor();
            timeText.text = "00:00:00";
            if(hashDisplayText != null) hashDisplayText.text = "---";
            lastHashHex = "";

            toggleButtonText.text = LocalizationManager.Instance.Get("MINE_BTN_START");
            toggleButton.GetComponent<Image>().color = new Color(1f, 0.5f, 0f);

            sharesText.text = LocalizationManager.Instance.Get("MINE_STATUS_STOPPED_SHORT");
            sharesText.color = Color.gray;
            addressInput.interactable = true;
        }
    }
    
    void GoBack()
    {
        SceneManager.LoadScene("MainWallet");
    }

    // --- FACTORY HELPERS ---
    
    GameObject MakePanel(Transform p, string n, float x, float y, float w, float h, Color c) {
        GameObject o = new GameObject(n); o.transform.SetParent(p,false);
        RectTransform r = o.AddComponent<RectTransform>(); r.anchoredPosition = new Vector2(x,y); r.sizeDelta = new Vector2(w,h);
        o.AddComponent<Image>().color = c; return o;
    }
    
    GameObject MakeCard(Transform p, float x, float y, float w, float h) {
        return MakePanel(p, "Card", x, y, w, h, ThemeManager.Instance.GetCardColor());
    }

    Text MakeText(Transform p, string t, float x, float y, int s, Color c, FontStyle st) {
        GameObject o = new GameObject("Txt"); o.transform.SetParent(p,false);
        RectTransform r = o.AddComponent<RectTransform>(); r.anchoredPosition = new Vector2(x,y); r.sizeDelta = new Vector2(850,60);
        Text tx = o.AddComponent<Text>(); tx.text = t; tx.fontSize = s; tx.color = c; tx.fontStyle = st;
        tx.alignment = TextAnchor.MiddleCenter; tx.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        tx.horizontalOverflow = HorizontalWrapMode.Overflow;
        tx.raycastTarget = false;
        return tx;
    }
    
    Button MakeButton(Transform p, string t, float x, float y, float w, float h, UnityEngine.Events.UnityAction a) {
        GameObject o = MakePanel(p, "Btn", x, y, w, h, ThemeManager.Instance.GetAccentColor());
        Button b = o.AddComponent<Button>(); b.onClick.AddListener(a);
        MakeText(o.transform, t, 0, 0, 32, Color.white, FontStyle.Bold);
        return b;
    }
    
    InputField MakeInput(Transform p, float x, float y, float w, float h, string def) {
        GameObject o = MakePanel(p, "Inp", x, y, w, h, ThemeManager.Instance.IsDarkMode ? new Color(0.1f,0.1f,0.1f) : new Color(0.9f,0.9f,0.9f));
        InputField i = o.AddComponent<InputField>();
        Text t = MakeText(o.transform, "", 0, 0, 28, ThemeManager.Instance.GetTextColor(), FontStyle.Normal);
        t.rectTransform.sizeDelta = new Vector2(w-40, h-10);
        i.textComponent = t; i.text = def;
        return i;
    }
    
    Slider MakeSlider(Transform p, float x, float y, float w, float h) {
        GameObject o = MakePanel(p, "Sld", x, y, w, h, Color.clear);
        GameObject bg = MakePanel(o.transform, "BG", 0, 0, w, 10, Color.gray);
        GameObject fillArea = new GameObject("Fill Area"); fillArea.transform.SetParent(o.transform, false);
        fillArea.AddComponent<RectTransform>().sizeDelta = new Vector2(w, 10);
        GameObject fill = MakePanel(fillArea.transform, "Fill", 0, 0, 0, 0, ThemeManager.Instance.GetAccentColor());
        
        Slider s = o.AddComponent<Slider>();
        s.targetGraphic = bg.GetComponent<Image>();
        s.fillRect = fill.GetComponent<RectTransform>();
        s.direction = Slider.Direction.LeftToRight;
        
        GameObject handleArea = new GameObject("Handle Slide Area"); handleArea.transform.SetParent(o.transform, false);
        handleArea.AddComponent<RectTransform>().sizeDelta = new Vector2(w, 20);
        GameObject handle = MakePanel(handleArea.transform, "Handle", 0, 0, 40, 40, Color.white);
        s.handleRect = handle.GetComponent<RectTransform>();
        
        return s;
    }
}
