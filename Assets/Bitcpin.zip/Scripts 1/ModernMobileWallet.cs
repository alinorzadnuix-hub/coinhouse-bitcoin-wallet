using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.Networking;
using System.Collections;
using System.Collections.Generic;
using ZXing;
using ZXing.QrCode;
using ZXing.Common;

public class ModernMobileWallet : MonoBehaviour
{
    private Text totalBalanceText;
    private Text cryptoBalanceText; // Small BTC underneath
    private Text addressDisplayText;
    private Image netIconImage; // Added Reference
    private bool isTestNet = true;
    private bool autoRefresh = false;
    private Button miningButton; // Reference for dynamic updates
    private GameObject keysOverlay; // First-time keys backup overlay

    // UI Config
    private const float REFERENCE_WIDTH = 1080f;
    private const float REFERENCE_HEIGHT = 1920f;

    // API
    private const string COINGECKO_API = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd";
    private const string COINPAPRIKA_API = "https://api.coinpaprika.com/v1/tickers/tbtc-bitcoin-testnet";

    private GameObject mainCanvas; // Track main canvas for rebuilding
    private bool isOptionsOpen = false;

    void Start()
    {
        // Subscribe to language change
        LocalizationManager.Instance.OnLanguageChanged += RefreshUI;

        // 1. Auth Check
        if(AuthManager.Instance == null || !AuthManager.Instance.IsAuthenticated)
        {
             SceneManager.LoadScene("AppLock");
             return;
        }
    
        // 2. Build UI
        if (FindObjectOfType<EventSystem>() == null)
        {
            var es = new GameObject("EventSystem");
            es.AddComponent<EventSystem>();
            es.AddComponent<StandaloneInputModule>();
        }
        
        // Auto-Redirect if no wallet
        if (!WalletManager2.Instance.HasWallet())
        {
            SceneManager.LoadScene(1); // Go to Create Wallet
            return;
        }
        
        BuildUI();
        
        // 3. Load Logic
        LoadSavedWallet();
        autoRefresh = true;
        InvokeRepeating("AutoRefreshBalance", 1f, 120f);
        
        // 4. Initialize Auto-Lock Manager
        var _ = AppAutoLockManager.Instance;
        
        // 5. Return to settings if coming back from sub-page
        if (PlayerPrefs.GetInt("ReturnToSettings", 0) == 1)
        {
            PlayerPrefs.SetInt("ReturnToSettings", 0);
            PlayerPrefs.Save();
            OnShowOptions();
        }
    }

    void OnDestroy()
    {
        if (LocalizationManager.Instance != null)
            LocalizationManager.Instance.OnLanguageChanged -= RefreshUI;
    }

    void OnApplicationPause(bool paused)
    {
        if (paused)
        {
            // App going to background — schedule price alert notifications
            if (PlayerPrefs.GetInt("PriceAlertEnabled", 0) == 1 && lastBtcPrice > 0 && NotificationManager.Instance != null)
            {
                string currency = PlayerPrefs.GetString("SelectedCurrency", "USD").ToUpper();
                string symbol = CurrencyHelper.GetSymbol(currency);
                NotificationManager.Instance.ScheduleBackgroundPriceAlerts(lastBtcPrice, symbol, currency);
                Debug.Log($"[ModernMobileWallet] App paused — scheduled background price alerts (BTC: {symbol}{lastBtcPrice:N0})");
            }
        }
        else
        {
            // App returning to foreground — cancel scheduled, check live instead
            if (NotificationManager.Instance != null)
            {
                NotificationManager.Instance.CancelScheduledPriceAlerts();
                Debug.Log("[ModernMobileWallet] App resumed — cancelled scheduled alerts, checking live");
            }
        }
    }

    void RefreshUI()
    {
        // Rebuild UI without scene reload
        if (mainCanvas != null) Destroy(mainCanvas);
        BuildUI();
        
        // Restore Options Menu if it was open
        if (isOptionsOpen)
        {
            OnShowOptions();
            // Restore page if needed, OnShowOptions defaults to 0
            if (currentOptionsPage > 0)
            {
                 // Small hack: if page 1, we reload it. 
                 // Since OnShowOptions builds page 0, we can just call ReloadOptionsMenu() which uses currentOptionsPage
                 ReloadOptionsMenu(); 
            }
        }
    }

    void LoadSavedWallet()
    {
        if (WalletManager2.Instance.HasWallet())
        {
            WalletData data = WalletManager2.Instance.GetCurrentWallet();
            isTestNet = data.isTestNet;
            string addr = !string.IsNullOrEmpty(data.address) ? data.address : "No Address Generated";
            if(addressDisplayText) 
            {
                 string type = LocalizationManager.Instance.Get("MAIN_WALLET");
                 string net = isTestNet ? LocalizationManager.Instance.Get("TESTNET") : LocalizationManager.Instance.Get("MAINNET");
                 
                 // Show parent address in orange above current address
                 // Use the permanent parentAddress field (set once during wallet creation)
                 string parentAddr = GetParentAddress(data);
                 
                 if (!string.IsNullOrEmpty(parentAddr) && parentAddr != addr)
                 {
                     string truncParent = parentAddr.Length > 20 ? parentAddr.Substring(0, 10) + "..." + parentAddr.Substring(parentAddr.Length - 8) : parentAddr;
                     addressDisplayText.text = $"<size=24><color=#FF8C00>Parent Address: {truncParent}</color></size>\n{addr}\n<size=24><color=#888888>{type} • {net}</color></size>";
                 }
                 else
                 {
                     addressDisplayText.text = $"{addr}\n<size=24><color=#888888>{type} • {net}</color></size>";
                 }
            }
            
            // Update Icon Dynamically
            if(netIconImage != null)
            {
                string iconName = isTestNet ? "x" : "y";
                Sprite s = Resources.Load<Sprite>(iconName);
                if(s != null) netIconImage.sprite = s;
                else netIconImage.color = isTestNet ? Color.red : new Color(1f, 0.6f, 0f);
            }

            OnRefreshBalance();
            UpdateMiningButtonState();
            
            // Show keys backup overlay on first open (seed-phrase wallets only)
            if (!data.hasShownKeys && !data.isPrivateKeyImport && !string.IsNullOrEmpty(data.seedPhrase))
            {
                BuildFirstTimeKeysOverlay(data);
            }
        }
    }

    string GetParentAddress(WalletData data)
    {
        if (!string.IsNullOrEmpty(data.parentAddress))
            return data.parentAddress;
            
        if (data.generatedAddresses != null && data.generatedAddresses.Count > 0)
        {
            string origAddr = data.generatedAddresses[0].address;
            int lowestIdx = data.generatedAddresses[0].index;
            foreach (var ga in data.generatedAddresses)
            {
                if (ga.index < lowestIdx) { lowestIdx = ga.index; origAddr = ga.address; }
            }
            return origAddr;
        }
        
        return data.address;
    }

    void UpdateMiningButtonState()
    {
        if(miningButton == null) return;
        
        miningButton.interactable = !isTestNet;
        
        // Visuals
        Color targetColor = !isTestNet ? Color.white : Color.gray;
        Color targetTextColor = !isTestNet ? ThemeManager.Instance.GetTextColor() : new Color(0.6f, 0.6f, 0.6f);
        
        foreach(var img in miningButton.GetComponentsInChildren<Image>()) 
        {
            // Keep Circle BG color distinct if needed, or just gray everything out
            if(img.gameObject.name == "Circle")
                 img.color = !isTestNet ? (ThemeManager.Instance.IsDarkMode ? new Color(0.2f, 0.2f, 0.25f) : new Color(0.95f, 0.95f, 0.97f)) : Color.gray;
            else if (img.gameObject != miningButton.gameObject) // Icon/etc
                 img.color = targetColor;
        }

        foreach(var txt in miningButton.GetComponentsInChildren<Text>()) 
            txt.color = targetTextColor;
    }

    void BuildUI()
    {
        // Canvas
        mainCanvas = new GameObject("Canvas");
        GameObject canvasObj = mainCanvas;
        canvasObj.layer = 5;
        Canvas canvas = canvasObj.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        CanvasScaler scaler = canvasObj.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(REFERENCE_WIDTH, REFERENCE_HEIGHT);
        scaler.matchWidthOrHeight = 0.5f;
        canvasObj.AddComponent<GraphicRaycaster>();

        // THEME: Background - FULL SCREEN
        GameObject bg = new GameObject("BG");
        bg.layer = 5;
        bg.transform.SetParent(canvas.transform, false);
        RectTransform bgRT = bg.AddComponent<RectTransform>();
        bgRT.anchorMin = Vector2.zero; bgRT.anchorMax = Vector2.one;
        bgRT.offsetMin = Vector2.zero; bgRT.offsetMax = Vector2.zero;
        Image bgImg = bg.AddComponent<Image>();
        bgImg.color = ThemeManager.Instance.GetBackgroundColor(); 
        // Force BG to be clean white/dark depending on theme, maybe slight gray for modern feel
        if(!ThemeManager.Instance.IsDarkMode) bgImg.color = new Color(0.98f, 0.98f, 0.98f); 

        BuildDashboard(canvas.transform);
    }

    void BuildDashboard(Transform dashboardPanel)
    {
        // --- TOP HEADER (Home) --- 
        GameObject titleObj = MakeText(dashboardPanel, LocalizationManager.Instance.Get("HOME_TITLE"), 0, -60, 48, ThemeManager.Instance.GetTextColor(), FontStyle.Bold).gameObject;
        RectTransform tRT = titleObj.GetComponent<RectTransform>();
        tRT.anchorMin = new Vector2(0.5f, 1); tRT.anchorMax = new Vector2(0.5f, 1); tRT.pivot = new Vector2(0.5f, 1);
        tRT.anchoredPosition = new Vector2(0, -80);
        
        // --- BALANCE CARD SECTION ---
        GameObject cardObj = MakePanel(dashboardPanel, "BalanceCard", 0, 500, 950, 550, ThemeManager.Instance.GetCardColor());
        
        // 1. Bitcoin Icon (Top Left inside Card)
        GameObject iconObj = new GameObject("BitIcon");
        iconObj.transform.SetParent(cardObj.transform, false);
        RectTransform iconRT = iconObj.AddComponent<RectTransform>();
        iconRT.anchoredPosition = new Vector2(-380, 180);
        iconRT.sizeDelta = new Vector2(100, 100);
        
        Image iconImg = iconObj.AddComponent<Image>();
        this.netIconImage = iconImg; // Capture reference for updates
        
        string iconName = isTestNet ? "x" : "y";
        Sprite s = Resources.Load<Sprite>(iconName);
        
        if(s) iconImg.sprite = s; 
        else iconImg.color = isTestNet ? Color.red : new Color(1f, 0.6f, 0f); // Red for Testnet, Orange for Mainnet
        
        // 2. Balance Texts
        // BTC - Show cached balance immediately
        string cachedBtc = "0.00000000 BTC";
        if (WalletManager2.Instance.HasWallet())
        {
            WalletData cachedData = WalletManager2.Instance.GetCurrentWallet();
            if (cachedData.cachedBalance > 0)
                cachedBtc = $"{cachedData.cachedBalance:F8} BTC";
        }
        cryptoBalanceText = MakeText(cardObj.transform, cachedBtc, 50, 200, 56, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);
        cryptoBalanceText.alignment = TextAnchor.MiddleLeft;
        cryptoBalanceText.rectTransform.sizeDelta = new Vector2(650, 80);
        // USD
        totalBalanceText = MakeText(cardObj.transform, "≈ $0.00 USD", 50, 130, 36, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Normal);
        totalBalanceText.alignment = TextAnchor.MiddleLeft;
        totalBalanceText.rectTransform.sizeDelta = new Vector2(650, 60);
        
        // 3. Address Section (Middle-Bottom of Card)
        MakeText(cardObj.transform, LocalizationManager.Instance.Get("BALANCE_MAIN"), -280, 20, 28, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Normal)
            .alignment = TextAnchor.MiddleLeft;

        // Address Value
        addressDisplayText = MakeText(cardObj.transform, LocalizationManager.Instance.Get("GEN_LOADING"), 0, -30, 32, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);
        addressDisplayText.alignment = TextAnchor.MiddleCenter;
        
        // 4. Address Actions (Row at bottom of card)
        float btnY = -180;
        
        // Generate New Address Button
        MakeButtonSmall(cardObj.transform, LocalizationManager.Instance.Get("BTN_NEW_ADDR"), -200, btnY, 350, 80, OnGenerateNewAddress)
            .GetComponent<Image>().color = ThemeManager.Instance.GetAccentColor();
            
        // Copy Address Button
        MakeButtonSmall(cardObj.transform, "📋 " + LocalizationManager.Instance.Get("BTN_COPY"), 200, btnY, 350, 80, () => {
             if(WalletManager2.Instance.HasWallet()) {
                GUIUtility.systemCopyBuffer = WalletManager2.Instance.GetCurrentWallet().address;
                ShowStatus(LocalizationManager.Instance.Get("GEN_COPIED"), ThemeManager.Instance.GetSuccessColor());
            }
        }).GetComponent<Image>().color = ThemeManager.Instance.GetButtonColor(); // Default Blue
        
        
        // --- ACTION GRID (Center) ---
        float gridCenterY = 0; // Center of screen roughly
        float spacingX = 250;
        float spacingY = 250;
        
        // Row 1
        MakeActionCircle(dashboardPanel, LocalizationManager.Instance.Get("BTN_SEND"), "↑", -spacingX/2 - 20, gridCenterY + 50, () => SceneManager.LoadScene(7));
        MakeActionCircle(dashboardPanel, LocalizationManager.Instance.Get("BTN_RECEIVE"), "↓", spacingX/2 + 20, gridCenterY + 50, OnShowReceive);
        
        // Row 2
        MakeActionCircle(dashboardPanel, LocalizationManager.Instance.Get("BTN_MINING"), "⛏️", -spacingX/2 - 20, gridCenterY - spacingY + 50, () => SceneManager.LoadScene(5));
        MakeActionCircle(dashboardPanel, LocalizationManager.Instance.Get("BTN_OPTIONS"), "⚙️", spacingX/2 + 20, gridCenterY - spacingY + 50, OnShowOptions);
        
        UpdateMiningButtonState(); // Init state

        // --- FOOTER BUTTONS ---
        float footerY = -500;
        
        GameObject histBtn = MakeButton(dashboardPanel, LocalizationManager.Instance.Get("BTN_HISTORY"), 0, footerY, 900, 120, () => SceneManager.LoadScene(3));
        histBtn.GetComponent<Image>().color = ThemeManager.Instance.GetCardColor();
        // Fix: In light mode, button text must be dark (MakeButton defaults to white)
        if (!ThemeManager.Instance.IsDarkMode)
        {
            Text histBtnText = histBtn.GetComponentInChildren<Text>();
            if (histBtnText != null) histBtnText.color = Color.black;
        }
        
        MakeButton(dashboardPanel, LocalizationManager.Instance.Get("BTN_SUPPORT"), 0, footerY - 150, 900, 120, OnDonate)
            .GetComponent<Image>().color = new Color(0.8f, 0.4f, 0.6f); 

        // --- MARKET TICKER ---
        BuildMarketTicker(dashboardPanel, -850);
    }
    
    // --- OPTIONS MENU ---
    private GameObject optionsOverlay;
    private GameObject changePasswordDialog;
    private int currentOptionsPage = 0; // 0 = Page 1, 1 = Page 2

    // Data for new settings
    private string[] availableCurrencies = new string[] { "USD", "EUR", "JPY", "RUB", "GBP", "CNY", "AUD", "CAD", "THB", "IDR", "TRY", "MXN", "BRL" };
    private string[] availableLanguages = new string[] { "English", "Chinese", "Japanese", "Spanish", "Russian", "Hindi", "Thai", "French", "Swahili" };

    // Completely Rewritten Options Menu with all features
    void OnShowOptions()
    {
        isOptionsOpen = true; // Track state
        // 1. Overlay
        GameObject canvasObj = GameObject.Find("Canvas");
        optionsOverlay = new GameObject("OptionsOverlay");
        optionsOverlay.layer = 5;
        optionsOverlay.transform.SetParent(canvasObj.transform, false);
        
        RectTransform rt = optionsOverlay.AddComponent<RectTransform>();
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one; rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;
        optionsOverlay.AddComponent<Image>().color = new Color(0,0,0, 0.9f);
        optionsOverlay.AddComponent<Button>().onClick.AddListener(()=> { optionsOverlay.SetActive(false); });

        // 2. Panel (Center, tall enough for all items)
        GameObject panel = new GameObject("MenuPanel");
        panel.layer = 5; panel.transform.SetParent(optionsOverlay.transform, false);
        RectTransform prt = panel.AddComponent<RectTransform>();
        prt.anchorMin = new Vector2(0.5f, 0.5f); prt.anchorMax = new Vector2(0.5f, 0.5f);
        prt.anchoredPosition = Vector2.zero;
        prt.sizeDelta = new Vector2(900, 1500);
        
        Image pImg = panel.AddComponent<Image>();
        pImg.color = ThemeManager.Instance.GetBackgroundColor();
        
        // 3. Render Page Content based on current page
        if (currentOptionsPage == 0)
        {
            BuildOptionsPage1(panel.transform);
        }
        else
        {
            BuildOptionsPage2(panel.transform);
        }
    }

    void BuildOptionsPage1(Transform panel)
    {
        float startY = 600;
        float gap = 130;
        int row = 0;
        
        // Define standard button color based on theme
        Color standardBtnColor = ThemeManager.Instance.IsDarkMode ? ThemeManager.Instance.GetCardColor() : new Color(0.8f, 0.8f, 0.8f);

        // Title
        MakeText(panel.transform, LocalizationManager.Instance.Get("MENU_TITLE") + " (1/2)", 0, startY + 80, 48, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);
        
        // --- Wallet Management ---
        MakeText(panel.transform, LocalizationManager.Instance.Get("MENU_WALLET"), -280, startY - (gap * row) + 30, 28, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Bold);
        
        MakeButton(panel.transform, LocalizationManager.Instance.Get("MENU_CREATE"), 0, startY - (gap * row), 800, 100, () => {
            optionsOverlay.SetActive(false);
            SceneManager.LoadScene("CreateWallet");
        }).GetComponent<Image>().color = new Color(1f, 0.5f, 0f); // Orange
        row++;
        
        MakeButton(panel.transform, LocalizationManager.Instance.Get("MENU_RECOVER"), 0, startY - (gap * row), 800, 100, () => {
            optionsOverlay.SetActive(false);
            SceneManager.LoadScene("RecoverWallet");
        }).GetComponent<Image>().color = new Color(0.3f, 0.5f, 0.8f);
        row++;

        // Backup Wallet and Import Wallet File removed

        // --- Address ---
        MakeText(panel.transform, LocalizationManager.Instance.Get("ADDR_SECTION"), -280, startY - (gap * row) + 30, 28, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Bold);

        // ✅ ADDRESS BOOK
        MakeButton(panel.transform, LocalizationManager.Instance.Get("ADDR_BOOK_BTN"), 0, startY - (gap * row), 800, 100, () => {
            optionsOverlay.SetActive(false);
            Destroy(optionsOverlay);
            ShowAddressBookOverlay();
        }).GetComponent<Image>().color = new Color(0.55f, 0.35f, 0.15f); // Brown
        row++;

        // ✅ ADDRESS LOG - PURPLE
        MakeButton(panel.transform, LocalizationManager.Instance.Get("MENU_ADDR_LOG"), 0, startY - (gap * row), 800, 100, () => {
            optionsOverlay.SetActive(false);
            PlayerPrefs.SetInt("ReturnToSettings", 1);
            PlayerPrefs.Save();
            SceneManager.LoadScene("AddressLogUI");
        }).GetComponent<Image>().color = new Color(0.5f, 0.2f, 0.7f); // Purple
        row++;

        // --- Security ---
        MakeText(panel.transform, LocalizationManager.Instance.Get("MENU_SECURITY"), -280, startY - (gap * row) + 30, 28, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Bold);
        
        MakeButton(panel.transform, LocalizationManager.Instance.Get("MENU_PIN"), 0, startY - (gap * row), 800, 100, () => {
            optionsOverlay.SetActive(false);
            BuildChangePasswordDialog();
        }).GetComponent<Image>().color = new Color(0.45f, 0.45f, 0.5f); // Gray
        row++;

        // --- App Settings ---
        MakeText(panel.transform, LocalizationManager.Instance.Get("MENU_APP"), -280, startY - (gap * row) + 30, 28, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Bold);

        string themeText = ThemeManager.Instance.IsDarkMode ? LocalizationManager.Instance.Get("MENU_THEME_LIGHT") : LocalizationManager.Instance.Get("MENU_THEME_DARK");
        MakeButton(panel.transform, themeText, 0, startY - (gap * row), 800, 100, () => {
            ThemeManager.Instance.ToggleTheme();
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }).GetComponent<Image>().color = standardBtnColor;
        row++;
        
        // --- NEXT PAGE BUTTON ---
        MakeButton(panel.transform, LocalizationManager.Instance.Get("MENU_NEXT"), 0, startY - (gap * row) - 20, 800, 100, () => {
            currentOptionsPage = 1;
            ReloadOptionsMenu();
        }).GetComponent<Image>().color = ThemeManager.Instance.GetAccentColor();
        row++;

        // ✅ CLOSE BUTTON
        MakeButtonOutline(panel.transform, LocalizationManager.Instance.Get("MENU_CLOSE"), 0, -650, 400, 100, () => {
             isOptionsOpen = false;
             optionsOverlay.SetActive(false);
             Destroy(optionsOverlay);
        });
    }

    void BuildOptionsPage2(Transform panel)
    {
        float startY = 600;
        float gap = 130;
        int row = 0;
        
        Color standardBtnColor = ThemeManager.Instance.IsDarkMode ? ThemeManager.Instance.GetCardColor() : new Color(0.8f, 0.8f, 0.8f);

        // Title
        MakeText(panel.transform, LocalizationManager.Instance.Get("MENU_TITLE") + " (2/2)", 0, startY + 80, 48, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);

        // --- General ---
        MakeText(panel.transform, LocalizationManager.Instance.Get("MENU_GENERAL"), -280, startY - (gap * row) + 30, 28, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Bold);

        // 1. Sound Toggle
        bool isSoundOn = PlayerPrefs.GetInt("SoundEnabled", 1) == 1;
        string soundText = isSoundOn ? LocalizationManager.Instance.Get("MENU_SOUND_ON") : LocalizationManager.Instance.Get("MENU_SOUND_OFF");
        Color soundColor = isSoundOn ? new Color(0.2f, 0.8f, 0.2f) : standardBtnColor;
        
        MakeButton(panel.transform, soundText, 0, startY - (gap * row), 800, 100, () => {
            int newState = isSoundOn ? 0 : 1;
            PlayerPrefs.SetInt("SoundEnabled", newState);
            PlayerPrefs.Save();
            ReloadOptionsMenu();
        }).GetComponent<Image>().color = soundColor;
        row++;

        // 2. Currency Selector (Dropdown)
        string currentCurrency = PlayerPrefs.GetString("SelectedCurrency", "USD");
        MakeButton(panel.transform, LocalizationManager.Instance.Get("MENU_CURRENCY") + $": {currentCurrency} 💰", 0, startY - (gap * row), 800, 100, () => {
            ShowCurrencySelector();
        }).GetComponent<Image>().color = standardBtnColor;
        row++;

        // 3. Language Selector
        string currentLanguage = PlayerPrefs.GetString("SelectedLanguage", "English");
        MakeButton(panel.transform, LocalizationManager.Instance.Get("MENU_LANGUAGE") + $": {currentLanguage} 🌐", 0, startY - (gap * row), 800, 100, () => {
            ShowLanguageSelector();
        }).GetComponent<Image>().color = standardBtnColor;
        row++;

        // --- Community ---
        MakeText(panel.transform, LocalizationManager.Instance.Get("MENU_COMMUNITY"), -280, startY - (gap * row) + 30, 28, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Bold);
        
        MakeButton(panel.transform, LocalizationManager.Instance.Get("MENU_JOIN"), 0, startY - (gap * row), 800, 100, () => {
            Application.OpenURL("https://bitgatewallet.com");
        }).GetComponent<Image>().color = new Color(0.3f, 0.6f, 1f);
        row++;

        // --- Notifications (Moved from Page 1 if needed, or kept there. Let's keep basics here) ---
        // Just for balance, maybe add something else or leave gap. 
        // Let's put Danger Zone here as it's better hidden on Page 2
        
        MakeText(panel.transform, LocalizationManager.Instance.Get("MENU_DANGER"), -280, startY - (gap * row) + 30, 28, ThemeManager.Instance.GetErrorColor(), FontStyle.Bold);

        MakeButton(panel.transform, LocalizationManager.Instance.Get("MENU_DELETE"), 0, startY - (gap * row), 800, 100, OnDeleteWallet)
             .GetComponent<Image>().color = ThemeManager.Instance.GetErrorColor();
        row++;

        // --- Price Alerts ---
        MakeText(panel.transform, LocalizationManager.Instance.Get("ALERTS_SECTION"), -280, startY - (gap * row) + 30, 28, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Bold);

        MakeButton(panel.transform, LocalizationManager.Instance.Get("MENU_PRICE_ALERT"), 0, startY - (gap * row), 800, 100, () => {
            ShowPriceAlertOverlay();
        }).GetComponent<Image>().color = new Color(0.9f, 0.6f, 0.1f);
        row++;

        // --- PREV PAGE BUTTON ---
        MakeButton(panel.transform, LocalizationManager.Instance.Get("MENU_PREV"), 0, startY - (gap * row) - 20, 800, 100, () => {
            currentOptionsPage = 0;
            ReloadOptionsMenu();
        }).GetComponent<Image>().color = ThemeManager.Instance.GetAccentColor();
        row++;

        // ✅ CLOSE BUTTON
        MakeButtonOutline(panel.transform, LocalizationManager.Instance.Get("MENU_CLOSE"), 0, -650, 400, 100, () => {
             isOptionsOpen = false;
             optionsOverlay.SetActive(false);
             Destroy(optionsOverlay);
        });
    }

    void ReloadOptionsMenu()
    {
        if(optionsOverlay != null) 
        {
            optionsOverlay.SetActive(false);
            Destroy(optionsOverlay);
        }
        OnShowOptions();
        if(optionsOverlay != null)
        {
             optionsOverlay.SetActive(true);
             optionsOverlay.transform.SetAsLastSibling();
        }
    }
    // --- FILE PERMISSION POPUP ---
    void CheckFilePermissionAndRun(System.Action onPermissionGranted)
    {
        // If already has permission, run immediately
        if (WalletFileService.HasStoragePermission())
        {
            onPermissionGranted?.Invoke();
            return;
        }

        // Show permission dialog
        GameObject canvas = GameObject.Find("Canvas");
        GameObject permDialog = MakePanel(canvas.transform, "PermDialog", 0, 0, REFERENCE_WIDTH, REFERENCE_HEIGHT, new Color(0,0,0,0.85f));

        GameObject card = MakePanel(permDialog.transform, "Card", 0, 50, 850, 550, new Color(0.12f, 0.12f, 0.18f));

        MakeText(card.transform, "🔐 " + LocalizationManager.Instance.Get("PERM_TITLE"), 0, 200, 40, Color.white, FontStyle.Bold);
        
        Text msgText = MakeText(card.transform, LocalizationManager.Instance.Get("PERM_MSG"), 0, 60, 28, new Color(0.8f, 0.8f, 0.8f), FontStyle.Normal);
        msgText.rectTransform.sizeDelta = new Vector2(750, 180);
        msgText.alignment = TextAnchor.MiddleCenter;

        // Grant button
        MakeButton(card.transform, "✅ " + LocalizationManager.Instance.Get("PERM_GRANT"), 0, -100, 600, 100, () => {
            WalletFileService.RequestStoragePermission();
            Destroy(permDialog);
            // Small delay to let permission dialog finish
            StartCoroutine(DelayedAction(0.5f, () => {
                if (WalletFileService.HasStoragePermission())
                {
                    onPermissionGranted?.Invoke();
                }
                else
                {
                    ShowStatus("❌ " + LocalizationManager.Instance.Get("PERM_DENIED"), Color.red);
                }
            }));
        }).GetComponent<Image>().color = new Color(0.2f, 0.6f, 0.3f);

        // Cancel button
        MakeButton(card.transform, "❌ " + LocalizationManager.Instance.Get("BTN_CANCEL"), 0, -210, 400, 80, () => {
            Destroy(permDialog);
        }).GetComponent<Image>().color = new Color(0.3f, 0.3f, 0.35f);

        permDialog.transform.SetAsLastSibling();
    }

    System.Collections.IEnumerator DelayedAction(float delay, System.Action action)
    {
        yield return new WaitForSeconds(delay);
        action?.Invoke();
    }

    void CycleCurrency(string current)
    {
        int index = System.Array.IndexOf(availableCurrencies, current);
        if(index == -1) index = 0;
        index = (index + 1) % availableCurrencies.Length;
        PlayerPrefs.SetString("SelectedCurrency", availableCurrencies[index]);
        PlayerPrefs.Save();
        
        ShowStatus(LocalizationManager.Instance.Get("CURRENCY_SET") + $" {availableCurrencies[index]}", ThemeManager.Instance.GetSuccessColor());
        
        // Force refresh to update price immediately
        if(WalletManager2.Instance.HasWallet())
        {
             // We can just call UpdateUSDValue directly with current cached balance if we don't want full scan
             // But OnRefreshBalance is safer as it handles everything
             OnRefreshBalance();
        }
    }

    void CycleLanguage(string current)
    {
        int index = System.Array.IndexOf(availableLanguages, current);
        if(index == -1) index = 0;
        index = (index + 1) % availableLanguages.Length;
        LocalizationManager.Instance.SetLanguage(availableLanguages[index]);
        
        ShowStatus(LocalizationManager.Instance.Get("LANGUAGE_SET") + $": {availableLanguages[index]}", ThemeManager.Instance.GetSuccessColor());
    }

    // --- CURRENCY SELECTOR DROPDOWN ---
    private GameObject currencySelectorOverlay;

    void ShowCurrencySelector()
    {
        // Close options menu first
        if (optionsOverlay != null)
        {
            optionsOverlay.SetActive(false);
            Destroy(optionsOverlay);
        }

        GameObject canvasObj = GameObject.Find("Canvas");
        currencySelectorOverlay = new GameObject("CurrencySelectorOverlay");
        currencySelectorOverlay.layer = 5;
        currencySelectorOverlay.transform.SetParent(canvasObj.transform, false);

        RectTransform rt = currencySelectorOverlay.AddComponent<RectTransform>();
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
        rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;
        currencySelectorOverlay.AddComponent<Image>().color = new Color(0, 0, 0, 0.9f);

        GameObject panel = new GameObject("CurrencyPanel");
        panel.layer = 5; panel.transform.SetParent(currencySelectorOverlay.transform, false);
        RectTransform prt = panel.AddComponent<RectTransform>();
        prt.anchorMin = new Vector2(0.5f, 0.5f); prt.anchorMax = new Vector2(0.5f, 0.5f);
        prt.anchoredPosition = Vector2.zero;
        prt.sizeDelta = new Vector2(800, 1600);
        panel.AddComponent<Image>().color = ThemeManager.Instance.GetBackgroundColor();

        string currentCurrency = PlayerPrefs.GetString("SelectedCurrency", "USD");

        MakeText(panel.transform, LocalizationManager.Instance.Get("MENU_CURRENCY"), 0, 720, 42, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);

        float y = 600;
        float gap = 100;

        for (int i = 0; i < availableCurrencies.Length; i++)
        {
            string currency = availableCurrencies[i];
            string symbol = CurrencyHelper.GetSymbol(currency);
            bool isActive = (currency == currentCurrency);
            Color btnColor = isActive ? ThemeManager.Instance.GetAccentColor() :
                (ThemeManager.Instance.IsDarkMode ? new Color(0.2f, 0.2f, 0.3f) : new Color(0.7f, 0.7f, 0.75f));
            string label = isActive ? $"✓ {symbol} {currency}" : $"{symbol} {currency}";

            MakeButton(panel.transform, label, 0, y - (gap * i), 700, 80, () => {
                PlayerPrefs.SetString("SelectedCurrency", currency);
                PlayerPrefs.Save();
                Destroy(currencySelectorOverlay);
                ShowStatus(LocalizationManager.Instance.Get("CURRENCY_SET") + $" {currency}", ThemeManager.Instance.GetSuccessColor());
                // Force refresh to update price
                if(WalletManager2.Instance.HasWallet()) OnRefreshBalance();
            }).GetComponent<Image>().color = btnColor;
        }

        // Close button
        MakeButtonOutline(panel.transform, LocalizationManager.Instance.Get("MENU_CLOSE"), 0, -720, 400, 90, () => {
            Destroy(currencySelectorOverlay);
            // Reopen options menu
            OnShowOptions();
        });

        currencySelectorOverlay.transform.SetAsLastSibling();
    }

    // --- LANGUAGE SELECTOR DROPDOWN ---
    private GameObject languageSelectorOverlay;

    void ShowLanguageSelector()
    {
        // Close options menu first
        if (optionsOverlay != null)
        {
            optionsOverlay.SetActive(false);
            Destroy(optionsOverlay);
        }

        GameObject canvasObj = GameObject.Find("Canvas");
        languageSelectorOverlay = new GameObject("LanguageSelectorOverlay");
        languageSelectorOverlay.layer = 5;
        languageSelectorOverlay.transform.SetParent(canvasObj.transform, false);

        RectTransform rt = languageSelectorOverlay.AddComponent<RectTransform>();
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
        rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;
        languageSelectorOverlay.AddComponent<Image>().color = new Color(0, 0, 0, 0.9f);

        GameObject panel = new GameObject("LangPanel");
        panel.layer = 5; panel.transform.SetParent(languageSelectorOverlay.transform, false);
        RectTransform prt = panel.AddComponent<RectTransform>();
        prt.anchorMin = new Vector2(0.5f, 0.5f); prt.anchorMax = new Vector2(0.5f, 0.5f);
        prt.anchoredPosition = Vector2.zero;
        prt.sizeDelta = new Vector2(800, 1500);
        panel.AddComponent<Image>().color = ThemeManager.Instance.GetBackgroundColor();

        string currentLang = PlayerPrefs.GetString("SelectedLanguage", "English");

        MakeText(panel.transform, LocalizationManager.Instance.Get("LANG_SELECT_TITLE"), 0, 650, 42, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);

        float y = 520;
        float gap = 110;

        for (int i = 0; i < availableLanguages.Length; i++)
        {
            string lang = availableLanguages[i];
            bool isActive = (lang == currentLang);
            Color btnColor = isActive ? ThemeManager.Instance.GetAccentColor() : 
                (ThemeManager.Instance.IsDarkMode ? new Color(0.2f, 0.2f, 0.3f) : new Color(0.7f, 0.7f, 0.75f));
            string label = isActive ? $"✓ {lang}" : lang;

            MakeButton(panel.transform, label, 0, y - (gap * i), 700, 90, () => {
                LocalizationManager.Instance.SetLanguage(lang);
                Destroy(languageSelectorOverlay);
                ShowStatus(LocalizationManager.Instance.Get("LANGUAGE_SET") + $": {lang}", ThemeManager.Instance.GetSuccessColor());
            }).GetComponent<Image>().color = btnColor;
        }

        // Close button
        MakeButtonOutline(panel.transform, LocalizationManager.Instance.Get("MENU_CLOSE"), 0, -650, 400, 90, () => {
            Destroy(languageSelectorOverlay);
            // Reopen options menu
            OnShowOptions();
        });

        languageSelectorOverlay.transform.SetAsLastSibling();
    }

    // --- PRICE ALERTS ---
    private GameObject priceAlertOverlay;
    private double lastBtcPrice = 0;

    void ShowPriceAlertOverlay()
    {
        if (optionsOverlay != null)
        {
            optionsOverlay.SetActive(false);
            Destroy(optionsOverlay);
        }

        GameObject canvasObj = GameObject.Find("Canvas");
        priceAlertOverlay = new GameObject("PriceAlertOverlay");
        priceAlertOverlay.layer = 5;
        priceAlertOverlay.transform.SetParent(canvasObj.transform, false);

        RectTransform rt = priceAlertOverlay.AddComponent<RectTransform>();
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
        rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;
        priceAlertOverlay.AddComponent<Image>().color = new Color(0, 0, 0, 0.9f);

        // Card panel
        GameObject card = MakePanel(priceAlertOverlay.transform, "Card", 0, 50, 900, 700, ThemeManager.Instance.GetCardColor());

        // Title - PRICE ALERTS
        MakeText(card.transform, LocalizationManager.Instance.Get("ALERT_TITLE"), 0, 280, 48, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);

        // Enable/Disable Toggle - Clear ON/OFF button
        bool alertsEnabled = PlayerPrefs.GetInt("PriceAlertEnabled", 0) == 1;
        string toggleText = alertsEnabled ? LocalizationManager.Instance.Get("ALERT_ON") : LocalizationManager.Instance.Get("ALERT_OFF");
        Color toggleColor = alertsEnabled ? new Color(0.15f, 0.7f, 0.3f) : new Color(0.55f, 0.2f, 0.2f);

        MakeButton(card.transform, toggleText, 0, 170, 700, 90, () => {
            int newState = alertsEnabled ? 0 : 1;
            PlayerPrefs.SetInt("PriceAlertEnabled", newState);
            PlayerPrefs.Save();
            Destroy(priceAlertOverlay);
            ShowPriceAlertOverlay();
        }).GetComponent<Image>().color = toggleColor;

        // Status indicator text
        string statusLabel = alertsEnabled ? LocalizationManager.Instance.Get("ALERT_STATUS_ON") : LocalizationManager.Instance.Get("ALERT_STATUS_OFF");
        Color statusColor = alertsEnabled ? ThemeManager.Instance.GetSuccessColor() : new Color(0.6f, 0.4f, 0.4f);
        MakeText(card.transform, statusLabel, 0, 110, 26, statusColor, FontStyle.Italic);

        // Alert Cycle Label
        MakeText(card.transform, LocalizationManager.Instance.Get("ALERT_CYCLE"), 0, 60, 36, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);

        // Current alert cycle value
        string currentCycle = PlayerPrefs.GetString("PriceAlertCycle", "1hr");

        // Cycle buttons: 15m, 30m, 1hr, 24hr, 7 days
        string[] cycles = { "15m", "30m", "1hr", "24hr", "7 days" };
        float btnW = 140;
        float totalW = (btnW * cycles.Length) + (12 * (cycles.Length - 1));
        float startX = -totalW / 2 + btnW / 2;

        for (int i = 0; i < cycles.Length; i++)
        {
            string cycle = cycles[i];
            bool isActive = (currentCycle == cycle);
            Color bc = isActive ? ThemeManager.Instance.GetAccentColor() : (ThemeManager.Instance.IsDarkMode ? new Color(0.2f, 0.2f, 0.3f) : new Color(0.85f, 0.85f, 0.9f));

            MakeButton(card.transform, cycle, startX + (btnW + 12) * i, -40, btnW, 70, () => {
                PlayerPrefs.SetString("PriceAlertCycle", cycle);
                PlayerPrefs.Save();
                Destroy(priceAlertOverlay);
                ShowPriceAlertOverlay();
            }).GetComponent<Image>().color = bc;
        }



        // Close Menu Button
        MakeButton(card.transform, "Close Menu", 0, -250, 400, 100, () => {
            ShowStatus(LocalizationManager.Instance.Get("ALERT_SAVED"), ThemeManager.Instance.GetSuccessColor());
            Destroy(priceAlertOverlay);
        }).GetComponent<Image>().color = ThemeManager.Instance.GetAccentColor();

        priceAlertOverlay.transform.SetAsLastSibling();
    }

    void CheckPriceAlert(double currentPrice)
    {
        if (PlayerPrefs.GetInt("PriceAlertEnabled", 0) != 1) return;
        if (currentPrice <= 0) return;

        // Get cycle interval in seconds
        string cycle = PlayerPrefs.GetString("PriceAlertCycle", "1hr");
        float intervalSeconds = GetCycleSeconds(cycle);

        // Use long timestamps for precision (float loses ~256s at 2026 Unix timestamps)
        long now = System.DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        long lastAlertTime = 0;
        string lastAlertStr = PlayerPrefs.GetString("PriceAlertTimestampStr", "");
        if (!string.IsNullOrEmpty(lastAlertStr))
            long.TryParse(lastAlertStr, out lastAlertTime);
        
        // Migrate from old float storage if needed
        if (lastAlertTime == 0)
        {
            float oldTimestamp = PlayerPrefs.GetFloat("LastAlertTimestamp", 0f);
            if (oldTimestamp > 0) lastAlertTime = (long)oldTimestamp;
        }
        
        float lastPrice = PlayerPrefs.GetFloat("LastAlertPrice", 0f);

        if (lastPrice <= 0)
        {
            // First time — save baseline, no notification yet
            PlayerPrefs.SetFloat("LastAlertPrice", (float)currentPrice);
            PlayerPrefs.SetString("PriceAlertTimestampStr", now.ToString());
            PlayerPrefs.Save();
            Debug.Log($"[PriceAlert] Baseline set: ${currentPrice:N0}");
            return;
        }

        long elapsed = now - lastAlertTime;
        
        if (elapsed < (long)intervalSeconds)
        {
            // Not enough time has passed for this cycle
            return;
        }

        // Time to send notification! Calculate change
        double changePercent = ((currentPrice - lastPrice) / lastPrice) * 100.0;
        
        string direction = changePercent >= 0 ? "📈" : "📉";
        string changeStr = changePercent >= 0 ? $"+{changePercent:F1}%" : $"{changePercent:F1}%";
        
        string title = changePercent >= 0 ? 
            LocalizationManager.Instance.Get("ALERT_PRICE_UP") : 
            LocalizationManager.Instance.Get("ALERT_PRICE_DOWN");
        
        string currencyCode = PlayerPrefs.GetString("SelectedCurrency", "USD").ToUpper();
        string symbol = CurrencyHelper.GetSymbol(currencyCode);
        string msg = $"{direction} BTC: {symbol}{currentPrice:N0} ({changeStr})";

        if (NotificationManager.Instance != null)
        {
            NotificationManager.Instance.SendNotification(title, msg);
            Debug.Log($"[PriceAlert] ✅ Notification sent: {title} - {msg}");
        }
        else
        {
            Debug.LogWarning("[PriceAlert] NotificationManager.Instance is null!");
        }

        // Update baseline for next cycle
        PlayerPrefs.SetFloat("LastAlertPrice", (float)currentPrice);
        PlayerPrefs.SetString("PriceAlertTimestampStr", now.ToString());
        PlayerPrefs.Save();
    }

    float GetCycleSeconds(string cycle)
    {
        switch (cycle)
        {
            case "15m":    return 15f * 60f;      // 900 seconds
            case "30m":    return 30f * 60f;       // 1800 seconds
            case "1hr":    return 60f * 60f;       // 3600 seconds
            case "24hr":   return 24f * 60f * 60f; // 86400 seconds
            case "7 days": return 7f * 24f * 60f * 60f; // 604800 seconds
            default:       return 60f * 60f;       // Default 1 hour
        }
    }

    // --- ADDRESS BOOK OVERLAY ---
    private GameObject addressBookOverlayPanel;
    private GameObject deleteConfirmDialog;

    void ShowAddressBookOverlay()
    {
        if (addressBookOverlayPanel != null) Destroy(addressBookOverlayPanel);

        GameObject canvasObj = GameObject.Find("Canvas");
        addressBookOverlayPanel = new GameObject("AddressBookOverlay");
        addressBookOverlayPanel.layer = 5;
        addressBookOverlayPanel.transform.SetParent(canvasObj.transform, false);

        RectTransform rt = addressBookOverlayPanel.AddComponent<RectTransform>();
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
        rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;
        addressBookOverlayPanel.AddComponent<Image>().color = new Color(0, 0, 0, 0.92f);

        // Card
        GameObject card = MakePanel(addressBookOverlayPanel.transform, "Card", 0, 50, 950, 1600, ThemeManager.Instance.GetCardColor());

        // Title
        MakeText(card.transform, "📒 " + LocalizationManager.Instance.Get("ADDR_BOOK_TITLE"), 0, 720, 48, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);

        // Get entries
        var entries = AddressBookManager.Instance.GetEntries();

        float bottomY = 600; // Track bottom of entries for add form

        if (entries.Count == 0)
        {
            MakeText(card.transform, LocalizationManager.Instance.Get("ADDR_BOOK_EMPTY"), 0, 300, 32, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Normal);
            bottomY = 100;
        }
        else
        {
            float itemY = 580;
            float itemH = 160;
            int maxVisible = 4;
            int count = Mathf.Min(entries.Count, maxVisible);

            for (int i = 0; i < count; i++)
            {
                var entry = entries[i];
                float currentY = itemY - (itemH * i);

                // Entry background
                Color entryBg = ThemeManager.Instance.IsDarkMode ? new Color(0.15f, 0.15f, 0.2f) : new Color(0.92f, 0.92f, 0.95f);
                GameObject entryPanel = MakePanel(card.transform, "Entry_" + i, 0, currentY, 880, 140, entryBg);

                // Name
                Text nameText = MakeText(entryPanel.transform, entry.name, -120, 30, 30, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);
                nameText.alignment = TextAnchor.MiddleLeft;
                nameText.rectTransform.sizeDelta = new Vector2(480, 45);

                // Address (truncated)
                string truncAddr = entry.address.Length > 20 
                    ? entry.address.Substring(0, 10) + "..." + entry.address.Substring(entry.address.Length - 8) 
                    : entry.address;
                Text addrText = MakeText(entryPanel.transform, truncAddr, -120, -20, 22, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Normal);
                addrText.alignment = TextAnchor.MiddleLeft;
                addrText.rectTransform.sizeDelta = new Vector2(480, 35);

                // ✅ Copy button with 📋 icon
                string fullAddr = entry.address;
                MakeButtonSmall(entryPanel.transform, "📋 " + LocalizationManager.Instance.Get("GEN_COPY"), 290, 20, 160, 55, () => {
                    GUIUtility.systemCopyBuffer = fullAddr;
                    ShowStatus(LocalizationManager.Instance.Get("GEN_COPIED"), ThemeManager.Instance.GetSuccessColor());
                }).GetComponent<Image>().color = ThemeManager.Instance.GetAccentColor();

                // ✅ Delete button with ✕ icon - shows confirmation dialog
                string delAddr = entry.address;
                string delName = entry.name;
                MakeButtonSmall(entryPanel.transform, "✕ " + LocalizationManager.Instance.Get("BTN_DELETE"), 290, -40, 160, 55, () => {
                    ShowDeleteConfirmation(delAddr, delName);
                }).GetComponent<Image>().color = ThemeManager.Instance.GetErrorColor();
            }

            if (entries.Count > maxVisible)
            {
                MakeText(card.transform, $"+ {entries.Count - maxVisible} more...", 0, itemY - (itemH * maxVisible) + 50, 26, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Normal);
            }

            bottomY = itemY - (itemH * count) - 30;
        }

        // --- ADD NEW ADDRESS SECTION ---
        float addY = Mathf.Min(bottomY, -50);
        
        // Separator line
        GameObject sep = MakePanel(card.transform, "Sep", 0, addY + 40, 850, 3, ThemeManager.Instance.GetSecondaryTextColor());
        sep.GetComponent<Image>().color = new Color(0.4f, 0.4f, 0.5f, 0.5f);

        MakeText(card.transform, "➕ " + LocalizationManager.Instance.Get("ADDR_BOOK_ADD"), 0, addY - 10, 34, ThemeManager.Instance.GetAccentColor(), FontStyle.Bold);

        // Name input
        MakeText(card.transform, LocalizationManager.Instance.Get("ADDR_BOOK_NAME_LABEL"), -300, addY - 60, 24, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Normal);
        InputField nameInput = MakeInputField(card.transform, 50, addY - 60, 600, 70, LocalizationManager.Instance.Get("ADDR_BOOK_NAME"));

        // Address input
        MakeText(card.transform, LocalizationManager.Instance.Get("ADDR_BOOK_ADDR_LABEL"), -280, addY - 150, 24, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Normal);
        InputField addrInput = MakeInputField(card.transform, 50, addY - 150, 600, 70, LocalizationManager.Instance.Get("ADDR_BOOK_ADDR"));

        // Paste button next to address input
        MakeButtonSmall(card.transform, "📋", 390, addY - 150, 70, 70, () => {
            addrInput.text = GUIUtility.systemCopyBuffer;
        }).GetComponent<Image>().color = ThemeManager.Instance.GetAccentColor();

        // Add button
        MakeButton(card.transform, "➕ " + LocalizationManager.Instance.Get("ADDR_BOOK_ADD_BTN"), 0, addY - 250, 500, 90, () => {
            string newName = nameInput.text.Trim();
            string newAddr = addrInput.text.Trim();
            
            if (string.IsNullOrEmpty(newAddr))
            {
                ShowStatus(LocalizationManager.Instance.Get("ADDR_BOOK_NO_ADDR"), ThemeManager.Instance.GetErrorColor());
                return;
            }
            if (string.IsNullOrEmpty(newName)) newName = "Unnamed";
            
            AddressBookManager.Instance.AddEntry(newName, newAddr);
            ShowStatus(LocalizationManager.Instance.Get("ADDR_BOOK_SAVED"), ThemeManager.Instance.GetSuccessColor());
            Destroy(addressBookOverlayPanel);
            ShowAddressBookOverlay(); // Refresh
        }).GetComponent<Image>().color = ThemeManager.Instance.GetSuccessColor();

        // Close button
        MakeButton(card.transform, LocalizationManager.Instance.Get("GEN_CLOSE"), 0, addY - 370, 400, 90, () => {
            Destroy(addressBookOverlayPanel);
        }).GetComponent<Image>().color = new Color(0.35f, 0.35f, 0.4f);

        addressBookOverlayPanel.transform.SetAsLastSibling();
    }

    // ✅ Delete Confirmation Dialog
    void ShowDeleteConfirmation(string address, string name)
    {
        if (deleteConfirmDialog != null) Destroy(deleteConfirmDialog);

        GameObject canvasObj = GameObject.Find("Canvas");
        deleteConfirmDialog = new GameObject("DeleteConfirmDialog");
        deleteConfirmDialog.layer = 5;
        deleteConfirmDialog.transform.SetParent(canvasObj.transform, false);

        RectTransform rt = deleteConfirmDialog.AddComponent<RectTransform>();
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
        rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;
        deleteConfirmDialog.AddComponent<Image>().color = new Color(0, 0, 0, 0.85f);

        // Dialog card
        GameObject dialogCard = MakePanel(deleteConfirmDialog.transform, "DialogCard", 0, 50, 800, 450, ThemeManager.Instance.GetBackgroundColor());

        // Warning icon
        MakeText(dialogCard.transform, "⚠️", 0, 150, 60, Color.yellow, FontStyle.Normal);

        // Message
        string displayName = string.IsNullOrEmpty(name) ? "this address" : $"\"{name}\"";
        Text msgText = MakeText(dialogCard.transform, LocalizationManager.Instance.Get("ADDR_DELETE_CONFIRM") + $"\n{displayName}?", 0, 50, 30, ThemeManager.Instance.GetTextColor(), FontStyle.Normal);
        msgText.rectTransform.sizeDelta = new Vector2(700, 100);

        // Yes button
        MakeButton(dialogCard.transform, "✅ " + LocalizationManager.Instance.Get("DELETE_YES"), -180, -80, 300, 90, () => {
            AddressBookManager.Instance.DeleteEntry(address);
            Destroy(deleteConfirmDialog);
            deleteConfirmDialog = null;
            Destroy(addressBookOverlayPanel);
            ShowAddressBookOverlay(); // Refresh
            ShowStatus(LocalizationManager.Instance.Get("ADDR_BOOK_DELETED"), ThemeManager.Instance.GetSuccessColor());
        }).GetComponent<Image>().color = ThemeManager.Instance.GetErrorColor();

        // No button
        MakeButton(dialogCard.transform, "❌ " + LocalizationManager.Instance.Get("DELETE_NO"), 180, -80, 300, 90, () => {
            Destroy(deleteConfirmDialog);
            deleteConfirmDialog = null;
        }).GetComponent<Image>().color = new Color(0.35f, 0.35f, 0.4f);

        deleteConfirmDialog.transform.SetAsLastSibling();
    }

    // ✅ Helper: Create InputField for Address Book
    InputField MakeInputField(Transform parent, float x, float y, float w, float h, string placeholder)
    {
        GameObject obj = new GameObject("Input");
        obj.layer = 5;
        obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchoredPosition3D = new Vector3(x, y, 0);
        rt.sizeDelta = new Vector2(w, h);
        obj.AddComponent<Image>().color = ThemeManager.Instance.IsDarkMode ? new Color(0.1f, 0.1f, 0.15f) : new Color(0.9f, 0.9f, 0.9f);
        InputField input = obj.AddComponent<InputField>();
        
        GameObject textObj = new GameObject("Text");
        textObj.layer = 5; textObj.transform.SetParent(obj.transform, false);
        RectTransform textRT = textObj.AddComponent<RectTransform>();
        textRT.anchorMin = Vector2.zero; textRT.anchorMax = Vector2.one;
        textRT.offsetMin = new Vector2(15, 0); textRT.offsetMax = new Vector2(-15, 0);
        Text text = textObj.AddComponent<Text>();
        text.font = GetFont(); text.fontSize = 28; text.color = ThemeManager.Instance.GetTextColor();
        text.alignment = TextAnchor.MiddleLeft;
        text.raycastTarget = false;
        input.textComponent = text;
        
        GameObject phObj = new GameObject("Placeholder");
        phObj.layer = 5; phObj.transform.SetParent(obj.transform, false);
        RectTransform phRT = phObj.AddComponent<RectTransform>();
        phRT.anchorMin = Vector2.zero; phRT.anchorMax = Vector2.one;
        phRT.offsetMin = new Vector2(15, 0); phRT.offsetMax = new Vector2(-15, 0);
        Text ph = phObj.AddComponent<Text>();
        ph.text = placeholder; ph.font = GetFont(); ph.fontSize = 28;
        ph.color = new Color(0.5f, 0.5f, 0.5f); ph.fontStyle = FontStyle.Italic;
        ph.alignment = TextAnchor.MiddleLeft;
        ph.raycastTarget = false;
        input.placeholder = ph;
        
        return input;
    }

    // --- MARKET TICKER ---
    private Text tickerMainnetText;
    
    void BuildMarketTicker(Transform parent, float y)
    {
        GameObject panel = MakePanel(parent, "MarketTicker", 0, y, 950, 150, ThemeManager.Instance.GetCardColor());
        panel.GetComponent<Image>().color = ThemeManager.Instance.IsDarkMode ? new Color(0.1f, 0.1f, 0.12f, 0.95f) : new Color(0.95f, 0.95f, 0.98f, 0.95f);
        
        tickerMainnetText = MakeText(panel.transform, "BTC: $ ...", 0, 0, 42, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);
        tickerMainnetText.alignment = TextAnchor.MiddleCenter;
    }

    // --- RECEIVE OVERLAY ---
    private GameObject receiveOverlay;

    void OnShowReceive()
    {
        if(receiveOverlay == null) BuildReceiveOverlay();
        receiveOverlay.SetActive(true);
        receiveOverlay.transform.SetAsLastSibling();
        
        if(WalletManager2.Instance.HasWallet())
        {
            GenerateQRCode(WalletManager2.Instance.GetCurrentWallet().address);
        }
    }

    void BuildReceiveOverlay()
    {
        GameObject canvasObj = GameObject.Find("Canvas");
        receiveOverlay = new GameObject("ReceiveOverlay");
        receiveOverlay.layer = 5;
        receiveOverlay.transform.SetParent(canvasObj.transform, false);
        
        RectTransform rt = receiveOverlay.AddComponent<RectTransform>();
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one; rt.offsetMin=Vector2.zero; rt.offsetMax=Vector2.zero;
        
        Image img = receiveOverlay.AddComponent<Image>();
        img.color = new Color(0,0,0, 0.9f);
        
        // Panel sized dynamically: 900x1000 or scaled
        GameObject card = MakePanel(receiveOverlay.transform, "Card", 0, 0, 900, 1100, ThemeManager.Instance.GetCardColor());
        
        MakeText(card.transform, LocalizationManager.Instance.Get("RECEIVE_TITLE"), 0, 400, 48, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);
        
        GameObject qrObj = new GameObject("QR");
        qrObj.layer = 5;
        qrObj.transform.SetParent(card.transform, false);
        RectTransform qrRT = qrObj.AddComponent<RectTransform>();
        qrRT.anchoredPosition = new Vector2(0, 50);
        qrRT.sizeDelta = new Vector2(500, 500);
        qrObj.AddComponent<Image>().color = Color.white; 
        
        string addr = WalletManager2.Instance.HasWallet() ? WalletManager2.Instance.GetCurrentWallet().address : "No Address";
        Text addrText = MakeText(card.transform, addr, 0, -250, 32, ThemeManager.Instance.GetAccentColor(), FontStyle.Normal);
        
        MakeButton(card.transform, LocalizationManager.Instance.Get("BTN_COPY_ADDRESS"), 0, -350, 400, 100, () => {
             GUIUtility.systemCopyBuffer = addr;
             ShowStatus(LocalizationManager.Instance.Get("GEN_COPIED"), ThemeManager.Instance.GetSuccessColor());
        });

        // ✅ CLOSE BUTTON - Moved down to allow space
        MakeButtonOutline(card.transform, LocalizationManager.Instance.Get("MENU_CLOSE"), 0, -500, 400, 100, () => receiveOverlay.SetActive(false));
    }
    
    void GenerateQRCode(string text)
    {
        try {
            if(receiveOverlay == null) return;
            Transform card = receiveOverlay.transform.Find("Card");
            if(card == null) return;
            Transform qr = card.Find("QR");
            if(qr == null) return;
            
            var writer = new QRCodeWriter();
            var bitMatrix = writer.encode(text, BarcodeFormat.QR_CODE, 256, 256);
            int w = bitMatrix.Width;
            int h = bitMatrix.Height;
            Texture2D tex = new Texture2D(w, h);
            Color32[] pixels = new Color32[w * h];
            for (int x = 0; x < w; x++)
            {
                for (int y = 0; y < h; y++)
                {
                    pixels[y * w + x] = bitMatrix[x, y] ? Color.black : Color.white;
                }
            }
            tex.SetPixels32(pixels);
            tex.Apply();
            qr.GetComponent<Image>().sprite = Sprite.Create(tex, new Rect(0, 0, w, h), new Vector2(0.5f, 0.5f));
        } catch { }
    }

    void OnGenerateNewWallet() { SceneManager.LoadScene(1); }
    
    // --- DONATE OVERLAY ---
    private GameObject donateOverlay;
    
    void OnDonate()
    {
        if(donateOverlay == null) BuildDonateOverlay();
        donateOverlay.SetActive(true);
        donateOverlay.transform.SetAsLastSibling();
    }
    
    void BuildDonateOverlay()
    {
        GameObject canvasObj = GameObject.Find("Canvas");
        donateOverlay = new GameObject("DonateOverlay");
        donateOverlay.layer = 5;
        donateOverlay.transform.SetParent(canvasObj.transform, false);
        
        RectTransform rt = donateOverlay.AddComponent<RectTransform>();
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one; rt.offsetMin=Vector2.zero; rt.offsetMax=Vector2.zero;
        
        Image img = donateOverlay.AddComponent<Image>();
        img.color = new Color(0,0,0, 0.9f);
        
        // Panel sized better
        GameObject card = MakePanel(donateOverlay.transform, "Card", 0, 0, 900, 900, ThemeManager.Instance.GetCardColor());
        
        MakeText(card.transform, LocalizationManager.Instance.Get("DONATE_TITLE"), 0, 300, 48, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);
        MakeText(card.transform, LocalizationManager.Instance.Get("DONATE_MESSAGE"), 0, 200, 32, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Normal);
        
        string devAddr = "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh";
        Text addrText = MakeText(card.transform, devAddr, 0, 50, 28, ThemeManager.Instance.GetAccentColor(), FontStyle.Bold);
        
        MakeButton(card.transform, LocalizationManager.Instance.Get("BTN_COPY_ADDRESS"), 0, -100, 500, 120, () => {
             GUIUtility.systemCopyBuffer = devAddr;
             ShowStatus(LocalizationManager.Instance.Get("DONATE_COPIED"), ThemeManager.Instance.GetSuccessColor());
        });

        // ✅ CLOSE BUTTON - Moved down
        MakeButtonOutline(card.transform, LocalizationManager.Instance.Get("MENU_CLOSE"), 0, -350, 400, 100, () => donateOverlay.SetActive(false));
    }

    // --- ADDRESS TYPE SELECTION ---
    private GameObject addressTypeOverlay;

    void OnGenerateNewAddress()
    {
        if(addressTypeOverlay == null) BuildAddressTypeOverlay();
        addressTypeOverlay.SetActive(true);
        addressTypeOverlay.transform.SetAsLastSibling();
    }

    void BuildAddressTypeOverlay()
    {
        GameObject canvasObj = GameObject.Find("Canvas");
        addressTypeOverlay = new GameObject("AddressTypeOverlay");
        addressTypeOverlay.layer = 5;
        addressTypeOverlay.transform.SetParent(canvasObj.transform, false);
        
        RectTransform rt = addressTypeOverlay.AddComponent<RectTransform>();
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one; rt.offsetMin=Vector2.zero; rt.offsetMax=Vector2.zero;
        
        Image img = addressTypeOverlay.AddComponent<Image>();
        img.color = new Color(0,0,0, 0.9f);
        
        GameObject card = MakePanel(addressTypeOverlay.transform, "Card", 0, 0, 900, 850, ThemeManager.Instance.GetCardColor());
        
        MakeText(card.transform, LocalizationManager.Instance.Get("ADDR_TYPE_TITLE"), 0, 300, 48, ThemeManager.Instance.GetAccentColor(), FontStyle.Bold);
        MakeText(card.transform, LocalizationManager.Instance.Get("ADDR_TYPE_MESSAGE"), 0, 230, 28, new Color(0.8f, 0.8f, 0.8f), FontStyle.Normal);

        float y = 100;
        
        // SegWit Button - with proper text sizing for multi-line
        GameObject segBtn = MakeButton(card.transform, LocalizationManager.Instance.Get("ADDR_TYPE_SEGWIT"), 0, y, 800, 160, () => {
            GenerateAddress(NBitcoin.ScriptPubKeyType.Segwit);
            addressTypeOverlay.SetActive(false);
        });
        segBtn.GetComponent<Image>().color = new Color(0.2f, 0.6f, 1f);
        // Fix text to fill button properly
        Text segText = segBtn.GetComponentInChildren<Text>();
        if (segText != null)
        {
            segText.rectTransform.anchorMin = Vector2.zero;
            segText.rectTransform.anchorMax = Vector2.one;
            segText.rectTransform.offsetMin = new Vector2(10, 10);
            segText.rectTransform.offsetMax = new Vector2(-10, -10);
        }
        
        y -= 200;

        // Legacy Button - with proper text sizing for multi-line
        GameObject legBtn = MakeButton(card.transform, LocalizationManager.Instance.Get("ADDR_TYPE_LEGACY"), 0, y, 800, 160, () => {
            GenerateAddress(NBitcoin.ScriptPubKeyType.Legacy);
            addressTypeOverlay.SetActive(false);
        });
        legBtn.GetComponent<Image>().color = new Color(1f, 0.5f, 0.2f);
        Text legText = legBtn.GetComponentInChildren<Text>();
        if (legText != null)
        {
            legText.rectTransform.anchorMin = Vector2.zero;
            legText.rectTransform.anchorMax = Vector2.one;
            legText.rectTransform.offsetMin = new Vector2(10, 10);
            legText.rectTransform.offsetMax = new Vector2(-10, -10);
        }

        MakeButton(card.transform, LocalizationManager.Instance.Get("BTN_CANCEL"), 0, -350, 400, 100, () => addressTypeOverlay.SetActive(false))
            .GetComponent<Image>().color = new Color(0.3f, 0.4f, 0.6f); 
    }

    void GenerateAddress(NBitcoin.ScriptPubKeyType type)
    {
        try
        {
            WalletData wallet = WalletManager2.Instance.GetCurrentWallet();
            if (wallet == null)
            {
                ShowStatus("No wallet loaded", Color.red);
                return;
            }
            
            if (string.IsNullOrEmpty(wallet.seedPhrase))
            {
                ShowStatus("Cannot generate addresses for imported key wallets", Color.red);
                return;
            }
            
            int nextIndex = WalletManager2.Instance.GetNextAddressIndex();
            NBitcoin.Network net = NBitcoin.Network.Main; 
            BitcoinWalletCore core = new BitcoinWalletCore(wallet.seedPhrase, net);
            string newAddr = core.GetAddress(nextIndex, type); 
            
            if (string.IsNullOrEmpty(newAddr))
            {
                ShowStatus("Failed to generate address", Color.red);
                return;
            }
            
            WalletManager2.Instance.AddGeneratedAddress(newAddr, nextIndex);
            WalletManager2.Instance.UpdateMainAddress(newAddr);
            
            // Refresh UI Consistently - Show parent address in orange above new address
            string typeName = type == NBitcoin.ScriptPubKeyType.Segwit ? "SegWit" : "Legacy";
            
            // Get the permanent parent address (set once during wallet creation)
            string parentAddr = GetParentAddress(wallet);
            string truncParent = parentAddr.Length > 20 ? parentAddr.Substring(0, 10) + "..." + parentAddr.Substring(parentAddr.Length - 8) : parentAddr;
            string newText = $"<size=24><color=#FF8C00>Parent Address: {truncParent}</color></size>\n{newAddr}\n<size=24><color=#888888>{typeName} • MainNet</color></size>";
            if(addressDisplayText) addressDisplayText.text = newText;
            
            ShowStatus(LocalizationManager.Instance.Get("ADDR_GENERATED") + $" ({typeName})", ThemeManager.Instance.GetSuccessColor());
            Debug.Log($"[ModernMobileWallet] Generated {typeName} address: {newAddr} (index {nextIndex})");
        }
        catch (System.Exception ex)
        {
            Debug.LogError($"[ModernMobileWallet] GenerateAddress Error: {ex.Message}");
            ShowStatus($"Error: {ex.Message}", Color.red);
        }
    }

    void OnDeleteWallet()
    {
        // Show warning confirmation dialog before deleting
        BuildDeleteWalletWarning();
    }

    private GameObject deleteWalletWarningDialog;

    void BuildDeleteWalletWarning()
    {
        GameObject canvasObj = GameObject.Find("Canvas");
        if (deleteWalletWarningDialog != null) Destroy(deleteWalletWarningDialog);

        deleteWalletWarningDialog = new GameObject("DeleteWalletWarning");
        deleteWalletWarningDialog.layer = 5;
        deleteWalletWarningDialog.transform.SetParent(canvasObj.transform, false);

        RectTransform rt = deleteWalletWarningDialog.AddComponent<RectTransform>();
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
        rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;
        deleteWalletWarningDialog.AddComponent<Image>().color = new Color(0, 0, 0, 0.9f);

        // Panel
        GameObject panel = new GameObject("WarningPanel");
        panel.layer = 5;
        panel.transform.SetParent(deleteWalletWarningDialog.transform, false);
        RectTransform prt = panel.AddComponent<RectTransform>();
        prt.anchorMin = new Vector2(0.5f, 0.5f); prt.anchorMax = new Vector2(0.5f, 0.5f);
        prt.anchoredPosition = Vector2.zero;
        prt.sizeDelta = new Vector2(850, 700);
        panel.AddComponent<Image>().color = ThemeManager.Instance.GetBackgroundColor();

        // Warning Icon
        MakeText(panel.transform, "⚠️", 0, 260, 70, Color.yellow, FontStyle.Normal);

        // Warning Title
        MakeText(panel.transform, LocalizationManager.Instance.Get("DELETE_CONFIRM_TITLE"), 0, 180, 44, ThemeManager.Instance.GetErrorColor(), FontStyle.Bold);

        // Warning Message
        Text msgText = MakeText(panel.transform, LocalizationManager.Instance.Get("DELETE_CONFIRM_MSG"), 0, 30, 28, ThemeManager.Instance.GetTextColor(), FontStyle.Normal);
        msgText.rectTransform.sizeDelta = new Vector2(750, 250);

        // Yes Button (Red - Danger)
        MakeButton(panel.transform, LocalizationManager.Instance.Get("DELETE_YES"), -180, -150, 320, 110, () => {
            Destroy(deleteWalletWarningDialog);
            deleteWalletWarningDialog = null;
            WalletManager2.Instance.DeleteWallet();
            SceneManager.LoadScene(1);
        }).GetComponent<Image>().color = ThemeManager.Instance.GetErrorColor();

        // No Button (Gray - Cancel)
        MakeButton(panel.transform, LocalizationManager.Instance.Get("DELETE_NO"), 180, -150, 320, 110, () => {
            Destroy(deleteWalletWarningDialog);
            deleteWalletWarningDialog = null;
        }).GetComponent<Image>().color = new Color(0.35f, 0.35f, 0.4f);

        deleteWalletWarningDialog.transform.SetAsLastSibling();
    }

    void ReloadScene()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    void OnSwitchNetwork()
    {
        WalletManager2.Instance.ToggleNetwork();
        LoadSavedWallet(); 
    }

    void ShowStatus(string message, Color color)
    {
         GameObject canvasObj = GameObject.Find("Canvas");
         if(!canvasObj) return;

         GameObject toast = MakePanel(canvasObj.transform, "Toast", 0, -650, 800, 100, color);
         MakeText(toast.transform, message, 0, 0, 32, Color.white, FontStyle.Bold);
         Destroy(toast, 2.5f);
    }
    


    // --- CHANGE PASSWORD CONFIRMATION DIALOG ---
    void BuildChangePasswordDialog()
    {
        GameObject canvasObj = GameObject.Find("Canvas");
        if(changePasswordDialog != null) Destroy(changePasswordDialog);

        changePasswordDialog = new GameObject("ChangePasswordDialog");
        changePasswordDialog.layer = 5;
        changePasswordDialog.transform.SetParent(canvasObj.transform, false);

        RectTransform rt = changePasswordDialog.AddComponent<RectTransform>();
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
        rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;
        changePasswordDialog.AddComponent<Image>().color = new Color(0, 0, 0, 0.9f);

        // Panel
        GameObject panel = new GameObject("DialogPanel");
        panel.layer = 5;
        panel.transform.SetParent(changePasswordDialog.transform, false);
        RectTransform prt = panel.AddComponent<RectTransform>();
        prt.anchorMin = new Vector2(0.5f, 0.5f); prt.anchorMax = new Vector2(0.5f, 0.5f);
        prt.anchoredPosition = Vector2.zero;
        prt.sizeDelta = new Vector2(850, 650);
        panel.AddComponent<Image>().color = ThemeManager.Instance.GetBackgroundColor();

        // Warning Icon + Title
        MakeText(panel.transform, LocalizationManager.Instance.Get("CHANGE_PIN_TITLE"), 0, 220, 44, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);

        // Message
        Text msgText = MakeText(panel.transform, LocalizationManager.Instance.Get("CHANGE_PIN_MESSAGE"), 0, 60, 30, ThemeManager.Instance.GetSecondaryTextColor(), FontStyle.Normal);
        msgText.rectTransform.sizeDelta = new Vector2(750, 200);

        // Confirm Button
        MakeButton(panel.transform, LocalizationManager.Instance.Get("BTN_CONFIRM"), 0, -120, 700, 110, () => {
            Destroy(changePasswordDialog);
            changePasswordDialog = null;
            AuthManager.Instance.ResetAuth();
            SceneManager.LoadScene(0); // AppLock is Scene 0
        }).GetComponent<Image>().color = ThemeManager.Instance.GetAccentColor();

        // Cancel Button
        Color cancelColor = ThemeManager.Instance.IsDarkMode ? ThemeManager.Instance.GetCardColor() : new Color(0.75f, 0.75f, 0.75f);
        MakeButton(panel.transform, LocalizationManager.Instance.Get("BTN_CANCEL"), 0, -250, 700, 110, () => {
            Destroy(changePasswordDialog);
            changePasswordDialog = null;
        }).GetComponent<Image>().color = cancelColor;

        changePasswordDialog.transform.SetAsLastSibling();
    }

    // --- FIRST-TIME KEYS BACKUP OVERLAY ---
    void BuildFirstTimeKeysOverlay(WalletData data)
    {
        try
        {
            // Re-derive keys from the stored seed phrase
            NBitcoin.Network net = NBitcoin.Network.Main;
            BitcoinWalletCore core = new BitcoinWalletCore(data.seedPhrase, net);
            
            string seedPhrase = core.GetSeedPhrase();
            string wifKey = core.GetSegWitPrivateKey(0);
            string hexKey = core.GetSegWitPrivateKeyHex(0);
            
            // Split seed phrase into words
            string[] words = seedPhrase.Split(' ');

            // Build overlay
            GameObject canvasObj = GameObject.Find("Canvas");
            keysOverlay = new GameObject("KeysOverlay");
            keysOverlay.layer = 5;
            keysOverlay.transform.SetParent(canvasObj.transform, false);
            
            RectTransform rt = keysOverlay.AddComponent<RectTransform>();
            rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;
            keysOverlay.AddComponent<Image>().color = new Color(0, 0, 0, 0.95f);

            // Scrollable content panel - Theme-aware
            GameObject panel = new GameObject("KeysPanel");
            panel.layer = 5;
            panel.transform.SetParent(keysOverlay.transform, false);
            RectTransform prt = panel.AddComponent<RectTransform>();
            prt.anchorMin = new Vector2(0.5f, 0.5f); prt.anchorMax = new Vector2(0.5f, 0.5f);
            prt.anchoredPosition = Vector2.zero;
            prt.sizeDelta = new Vector2(950, 1700);
            panel.AddComponent<Image>().color = ThemeManager.Instance.GetBackgroundColor();

            float y = 750;

            // Colors from theme
            Color titleColor = ThemeManager.Instance.GetTextColor();
            Color subtitleColor = ThemeManager.Instance.GetSecondaryTextColor();
            Color labelColor = ThemeManager.Instance.GetTextColor();
            Color keyTextColor = ThemeManager.Instance.GetTextColor();
            Color boxColor = ThemeManager.Instance.IsDarkMode ? new Color(0.2f, 0.2f, 0.25f) : new Color(0.85f, 0.85f, 0.85f);
            Color copyBtnColor = ThemeManager.Instance.GetAccentColor();
            Color cellColor = ThemeManager.Instance.IsDarkMode ? new Color(0.12f, 0.12f, 0.16f) : new Color(0.93f, 0.93f, 0.96f);

            // Warning Title
            MakeText(panel.transform, LocalizationManager.Instance.Get("BACKUP_KEYS_TITLE"), 0, y, 48, titleColor, FontStyle.Bold);
            y -= 80;
            MakeText(panel.transform, LocalizationManager.Instance.Get("BACKUP_KEYS_MESSAGE"), 0, y, 26, subtitleColor, FontStyle.Normal);
            y -= 120;

            // --- 12 Seed Words ---
            MakeText(panel.transform, LocalizationManager.Instance.Get("BACKUP_SEED_WORDS"), -250, y, 34, labelColor, FontStyle.Bold);
            string capturedSeed = seedPhrase;
            MakeButtonSmall(panel.transform, LocalizationManager.Instance.Get("BTN_COPY"), 350, y, 150, 60, () => {
                GUIUtility.systemCopyBuffer = capturedSeed;
                ShowStatus(LocalizationManager.Instance.Get("SEED_COPIED"), ThemeManager.Instance.GetSuccessColor());
            }).GetComponent<Image>().color = copyBtnColor;
            y -= 50;

            // Seed words 2-column grid
            {
                float gridW = 870f;
                float cellW = 410f;
                float cellH = 50f;
                float gapX = 20f;
                float gapY = 8f;
                int half = (words.Length + 1) / 2; // 6 rows
                float gridH = half * cellH + (half - 1) * gapY + 20;
                
                GameObject seedBox = MakePanel(panel.transform, "SeedBox", 0, y - gridH / 2, gridW, gridH, boxColor);
                
                float col0X = -(cellW / 2 + gapX / 2);
                float col1X = (cellW / 2 + gapX / 2);
                float startCellY = gridH / 2 - 10;
                
                Color numColor = new Color(0.5f, 0.5f, 0.6f);
                Color wordColor = new Color(1f, 0.75f, 0.2f);
                
                for (int i = 0; i < words.Length; i++)
                {
                    int col = i < half ? 0 : 1;
                    int row = i < half ? i : i - half;
                    
                    float cx = col == 0 ? col0X : col1X;
                    float cy = startCellY - row * (cellH + gapY) - cellH / 2;
                    
                    // Cell background
                    GameObject cell = MakePanel(seedBox.transform, $"W{i}", cx, cy, cellW, cellH, cellColor);
                    
                    // Number (left side)
                    Text numT = MakeText(cell.transform, $"{i + 1}.", 0, 0, 22, numColor, FontStyle.Normal);
                    numT.alignment = TextAnchor.MiddleLeft;
                    numT.rectTransform.anchorMin = new Vector2(0, 0);
                    numT.rectTransform.anchorMax = new Vector2(0, 1);
                    numT.rectTransform.pivot = new Vector2(0, 0.5f);
                    numT.rectTransform.anchoredPosition = new Vector2(12, 0);
                    numT.rectTransform.sizeDelta = new Vector2(50, 0);
                    
                    // Word (next to number)
                    Text wordT = MakeText(cell.transform, words[i], 0, 0, 26, wordColor, FontStyle.Bold);
                    wordT.alignment = TextAnchor.MiddleLeft;
                    wordT.rectTransform.anchorMin = new Vector2(0, 0);
                    wordT.rectTransform.anchorMax = new Vector2(1, 1);
                    wordT.rectTransform.pivot = new Vector2(0.5f, 0.5f);
                    wordT.rectTransform.offsetMin = new Vector2(55, 2);
                    wordT.rectTransform.offsetMax = new Vector2(-8, -2);
                }
                
                y -= (gridH + 30);
            }

            // --- Private Key (WIF) ---
            MakeText(panel.transform, LocalizationManager.Instance.Get("BACKUP_WIF_KEY"), -220, y, 34, labelColor, FontStyle.Bold);
            string capturedWif = wifKey;
            MakeButtonSmall(panel.transform, LocalizationManager.Instance.Get("BTN_COPY"), 350, y, 150, 60, () => {
                GUIUtility.systemCopyBuffer = capturedWif;
                ShowStatus(LocalizationManager.Instance.Get("WIF_COPIED"), ThemeManager.Instance.GetSuccessColor());
            }).GetComponent<Image>().color = copyBtnColor;
            y -= 60;

            GameObject wifBox = MakePanel(panel.transform, "WifBox", 0, y - 30, 850, 120, boxColor);
            Text wifText = MakeText(wifBox.transform, wifKey, 0, 0, 24, keyTextColor, FontStyle.Bold);
            wifText.alignment = TextAnchor.MiddleLeft;
            wifText.rectTransform.anchorMin = Vector2.zero;
            wifText.rectTransform.anchorMax = Vector2.one;
            wifText.rectTransform.offsetMin = new Vector2(20, 5);
            wifText.rectTransform.offsetMax = new Vector2(-20, -5);
            y -= 150;

            // --- Private Key (Hex) ---
            MakeText(panel.transform, LocalizationManager.Instance.Get("BACKUP_HEX_KEY"), -220, y, 34, labelColor, FontStyle.Bold);
            string capturedHex = hexKey;
            MakeButtonSmall(panel.transform, LocalizationManager.Instance.Get("BTN_COPY"), 350, y, 150, 60, () => {
                GUIUtility.systemCopyBuffer = capturedHex;
                ShowStatus(LocalizationManager.Instance.Get("HEX_COPIED"), ThemeManager.Instance.GetSuccessColor());
            }).GetComponent<Image>().color = copyBtnColor;
            y -= 60;

            GameObject hexBox = MakePanel(panel.transform, "HexBox", 0, y - 30, 850, 120, boxColor);
            Text hexText = MakeText(hexBox.transform, hexKey, 0, 0, 24, keyTextColor, FontStyle.Bold);
            hexText.alignment = TextAnchor.MiddleLeft;
            hexText.rectTransform.anchorMin = Vector2.zero;
            hexText.rectTransform.anchorMax = Vector2.one;
            hexText.rectTransform.offsetMin = new Vector2(20, 5);
            hexText.rectTransform.offsetMax = new Vector2(-20, -5);
            y -= 180;

            // --- Dismiss Button ---
            MakeButton(panel.transform, LocalizationManager.Instance.Get("BACKUP_CONFIRM"), 0, y, 800, 120, () => {
                data.hasShownKeys = true;
                // Save the flag to file
                try {
                    string savePath = Application.persistentDataPath + "/wallet_mainnet.json";
                    string json = JsonUtility.ToJson(data, true);
                    System.IO.File.WriteAllText(savePath, json);
                } catch (System.Exception ex) { Debug.LogError("Save hasShownKeys error: " + ex.Message); }
                
                Destroy(keysOverlay);
                keysOverlay = null;
            }).GetComponent<Image>().color = ThemeManager.Instance.GetAccentColor();

            keysOverlay.transform.SetAsLastSibling();
            Debug.Log("First-time keys backup overlay displayed.");
        }
        catch (System.Exception ex)
        {
            Debug.LogError($"Failed to build keys overlay: {ex.Message}");
        }
    }

    void AutoRefreshBalance()
    {
        if(autoRefresh && WalletManager2.Instance.HasWallet()) OnRefreshBalance();
    }

    async void OnRefreshBalance()
    {
        if(!WalletManager2.Instance.HasWallet()) return;
        
        try
        {
            WalletData data = WalletManager2.Instance.GetCurrentWallet();
            double oldBalance = data.cachedBalance; // Capture OLD balance
            bool wasInitialScan = data.hasCompletedInitialScan;

            decimal total = 0;
            
            if (data.isPrivateKeyImport || string.IsNullOrEmpty(data.seedPhrase))
            {
                // Private key import: scan both Legacy and SegWit addresses for this key
                BitcoinTransactionService txService = new BitcoinTransactionService();
                var result = await txService.ScanAllAddresses(null, null, data.generatedAddresses, data.privateKey);
                total = result.confirmedBalance + result.unconfirmedBalance;
                
                // Fallback: also scan the stored address directly in case ScanAllAddresses missed it
                if (total == 0 && !string.IsNullOrEmpty(data.address))
                {
                    BlockCypherApiCore api = new BlockCypherApiCore();
                    decimal directBalance = await api.GetBalance(data.address, false);
                    total += directBalance;
                }
            }
            else
            {
                // Seed phrase wallet: scan all derived addresses (Legacy + SegWit)
                BitcoinTransactionService txService = new BitcoinTransactionService();
                var result = await txService.ScanAllAddresses(data.seedPhrase, null, data.generatedAddresses);
                total = result.confirmedBalance + result.unconfirmedBalance;
                WalletManager2.Instance.SyncTransactionHistory();
            }
            
            WalletManager2.Instance.UpdateBalance((double)total);
            
            // Update BTC Text
            string cur = "BTC";
            if(cryptoBalanceText) cryptoBalanceText.text = $"{total:F8} {cur}";
            
            // Check for received payment (Balance Increased)
            if (oldBalance < (double)total)
            {
                double diff = (double)total - oldBalance;
                // Only notify if diff is significant (avoid dust) and NOT the very first scan
                if (diff > 0.00000001 && wasInitialScan)
                {
                     NotificationManager.Instance.SendNotification(
                        LocalizationManager.Instance.Get("NOTIFICATION_PAYMENT_RECEIVED"), 
                        LocalizationManager.Instance.Get("NOTIFICATION_PAYMENT_AMOUNT") + $" {diff:F8} BTC"
                    );
                }
            }
            
            StartCoroutine(UpdateUSDValue((float)total));
        }
        catch { }
    }

    // --- UPDATED PRICE FETCHING ---

    IEnumerator UpdateUSDValue(float currentWalletBtc)
    {
        string currencyCode = PlayerPrefs.GetString("SelectedCurrency", "USD").ToLower();
        string symbol = CurrencyHelper.GetSymbol(currencyCode.ToUpper());
        string url = $"https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies={currencyCode}";

        using (UnityWebRequest req = UnityWebRequest.Get(url))
        {
            yield return req.SendWebRequest();
            if(req.result == UnityWebRequest.Result.Success) {
                try {
                    string json = req.downloadHandler.text;
                    double price = ParsePriceSimple(json, currencyCode);
                    
                    if(price > 0) {
                         lastBtcPrice = price;
                         if(tickerMainnetText) tickerMainnetText.text = $"BTC: {symbol}{price:N0}";
                         if(!isTestNet && totalBalanceText) totalBalanceText.text = $"≈ {symbol}{(currentWalletBtc * price):N2} {currencyCode.ToUpper()}";
                         
                         // Check price alerts
                         CheckPriceAlert(price);
                    }
                } catch {}
            }
            else
            {
                // Fallback to Coinpaprika
                yield return StartCoroutine(FetchPriceFallback(currentWalletBtc, currencyCode, symbol));
            }
        }
    }

    IEnumerator FetchPriceFallback(float currentWalletBtc, string currencyCode, string symbol)
    {
        string fallbackUrl = "https://api.coinpaprika.com/v1/tickers/btc-bitcoin";
        using (UnityWebRequest req = UnityWebRequest.Get(fallbackUrl))
        {
            yield return req.SendWebRequest();
            if (req.result == UnityWebRequest.Result.Success)
            {
                try {
                    string json = req.downloadHandler.text;
                    string search = "\"price\":";
                    int idx = json.IndexOf(search);
                    if (idx != -1)
                    {
                        int start = idx + search.Length;
                        int end = json.IndexOf(",", start);
                        if (end == -1) end = json.IndexOf("}", start);
                        if (end != -1)
                        {
                            string numStr = json.Substring(start, end - start);
                            if (double.TryParse(numStr, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out double price))
                            {
                                lastBtcPrice = price;
                                if (tickerMainnetText) tickerMainnetText.text = $"BTC: {symbol}{price:N0}";
                                if (!isTestNet && totalBalanceText) totalBalanceText.text = $"≈ {symbol}{(currentWalletBtc * price):N2} {currencyCode.ToUpper()}";
                                CheckPriceAlert(price);
                            }
                        }
                    }
                } catch {}
            }
        }
    }

    double ParsePriceSimple(string json, string currency)
    {
        try {
            string search = $"\"{currency}\":";
            int idx = json.IndexOf(search);
            if(idx != -1)
            {
                int start = idx + search.Length;
                int end = json.IndexOf("}", start);
                if(end == -1) end = json.IndexOf(",", start);
                
                if(end != -1)
                {
                    string numStr = json.Substring(start, end - start);
                    if(double.TryParse(numStr, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out double res))
                        return res;
                }
            }
        } catch {}
        return 0;
    }

    // --- HELPER FACTORY (Updated for New Design) ---
    
    Button MakeActionCircle(Transform parent, string label, string icon, float x, float y, System.Action onClick)
    {
        GameObject obj = new GameObject("Btn_" + label);
        obj.layer = 5;
        obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchoredPosition3D = new Vector3(x, y, 0);
        rt.sizeDelta = new Vector2(180, 220); 
        
        GameObject circle = new GameObject("Circle");
        circle.layer = 5; circle.transform.SetParent(obj.transform, false);
        RectTransform crt = circle.AddComponent<RectTransform>();
        crt.anchoredPosition = new Vector2(0, 20); 
        crt.sizeDelta = new Vector2(160, 160);
        Image cImg = circle.AddComponent<Image>();
        cImg.color = ThemeManager.Instance.IsDarkMode ? new Color(0.2f, 0.2f, 0.25f) : new Color(0.95f, 0.95f, 0.97f);
        
        Button btn = circle.AddComponent<Button>();
        btn.onClick.AddListener(() => AudioManager.Instance.PlayClick()); // Sound
        btn.onClick.AddListener(() => onClick());
        
        GameObject iObj = new GameObject("Icon");
        iObj.transform.SetParent(circle.transform, false);
        Text iTxt = iObj.AddComponent<Text>();
        iTxt.text = icon;
        iTxt.font = GetFont();
        iTxt.fontSize = 70;
        iTxt.alignment = TextAnchor.MiddleCenter;
        iTxt.color = ThemeManager.Instance.GetTextColor();
        iObj.GetComponent<RectTransform>().sizeDelta = new Vector2(160,160);
        
        GameObject lObj = new GameObject("Label");
        lObj.transform.SetParent(obj.transform, false);
        RectTransform lrt = lObj.AddComponent<RectTransform>();
        lrt.anchoredPosition = new Vector2(0, -90);
        lrt.sizeDelta = new Vector2(180, 50);
        Text lTxt = lObj.AddComponent<Text>();
        lTxt.text = label;
        lTxt.font = GetFont();
        lTxt.fontSize = 28;
        lTxt.alignment = TextAnchor.MiddleCenter;
        lTxt.color = ThemeManager.Instance.GetTextColor();
        
        return btn;
    }
    
    Font GetFont()
    {
        Font f = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        if (f == null) f = Font.CreateDynamicFontFromOSFont("Arial", 24);
        if (f == null) f = Font.CreateDynamicFontFromOSFont("Roboto", 24);
        return f;
    }

    GameObject MakePanel(Transform parent, string name, float x, float y, float w, float h, Color color) {
        GameObject obj = new GameObject(name);
        obj.layer = 5;
        obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchoredPosition3D = new Vector3(x, y, 0);
        rt.sizeDelta = new Vector2(w, h);
        obj.AddComponent<Image>().color = color;
        return obj;
    }
    
    Text MakeText(Transform parent, string txt, float x, float y, int size, Color col, FontStyle style) {
        GameObject obj = new GameObject("Text");
        obj.layer = 5; obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchoredPosition3D = new Vector3(x, y, 0);
        rt.sizeDelta = new Vector2(1000, 80);
        Text text = obj.AddComponent<Text>();
        text.text = txt; text.fontSize = size; text.color = col; text.fontStyle = style; 
        text.font = GetFont();
        text.alignment = TextAnchor.MiddleCenter;
        text.raycastTarget = false; 
        return text;
    }
    
    GameObject MakeButton(Transform parent, string txt, float x, float y, float w, float h, System.Action onClick) {
        GameObject obj = new GameObject("Button");
        obj.layer = 5; obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchoredPosition3D = new Vector3(x, y, 0);
        rt.sizeDelta = new Vector2(w, h);
        Image img = obj.AddComponent<Image>();
        img.color = ThemeManager.Instance.GetAccentColor();
        Button btn = obj.AddComponent<Button>();
        btn.onClick.AddListener(() => AudioManager.Instance.PlayClick()); // Sound
        btn.onClick.AddListener(()=>onClick());
        GameObject tObj = new GameObject("Text");
        tObj.layer = 5; tObj.transform.SetParent(obj.transform, false);
        RectTransform tRT = tObj.AddComponent<RectTransform>();
        tRT.anchorMin = Vector2.zero; tRT.anchorMax = Vector2.one;
        tRT.offsetMin = new Vector2(5, 5); tRT.offsetMax = new Vector2(-5, -5);
        Text t = tObj.AddComponent<Text>();
        t.text = txt; t.fontSize = 32; t.color = Color.white;
        t.font = GetFont();
        t.alignment = TextAnchor.MiddleCenter; t.fontStyle = FontStyle.Bold;
        return obj;
    }
    
    void MakeButtonOutline(Transform parent, string txt, float x, float y, float w, float h, System.Action onClick) {
        GameObject obj = new GameObject("Button");
        obj.layer = 5; obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchoredPosition3D = new Vector3(x, y, 0);
        rt.sizeDelta = new Vector2(w, h);
        Image img = obj.AddComponent<Image>();
        img.color = Color.clear; // Transparent
        Button btn = obj.AddComponent<Button>();
        btn.onClick.AddListener(() => AudioManager.Instance.PlayClick()); // Sound
        btn.onClick.AddListener(()=>onClick());
        
        GameObject tObj = new GameObject("Text");
        tObj.layer = 5; tObj.transform.SetParent(obj.transform, false);
        RectTransform tRT = tObj.AddComponent<RectTransform>();
        tRT.anchorMin = Vector2.zero; tRT.anchorMax = Vector2.one;
        Text t = tObj.AddComponent<Text>();
        t.text = txt; t.fontSize = 32; 
        t.color = ThemeManager.Instance.GetAccentColor();
        t.font = GetFont();
        t.alignment = TextAnchor.MiddleCenter; t.fontStyle = FontStyle.Bold;
    }

    GameObject MakeButtonSmall(Transform parent, string txt, float x, float y, float w, float h, System.Action onClick) {
         GameObject obj = new GameObject("BtnSmall");
        obj.layer = 5; obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchoredPosition3D = new Vector3(x, y, 0);
        rt.sizeDelta = new Vector2(w, h);
        Image img = obj.AddComponent<Image>();
        img.color = new Color(0.9f, 0.9f, 0.95f);
        if(ThemeManager.Instance.IsDarkMode) img.color = new Color(0.3f,0.3f,0.3f);
        
        Button btn = obj.AddComponent<Button>();
        btn.onClick.AddListener(() => AudioManager.Instance.PlayClick()); // Sound
        btn.onClick.AddListener(()=>onClick());
        
        Text t = MakeText(obj.transform, txt, 0, 0, 24, ThemeManager.Instance.GetTextColor(), FontStyle.Bold);
        // Ensure text fills button area and is perfectly centered
        t.rectTransform.anchorMin = Vector2.zero;
        t.rectTransform.anchorMax = Vector2.one;
        t.rectTransform.pivot = new Vector2(0.5f, 0.5f);
        t.rectTransform.sizeDelta = Vector2.zero;
        t.rectTransform.offsetMin = new Vector2(4, 2);
        t.rectTransform.offsetMax = new Vector2(-4, -2);
        t.rectTransform.anchoredPosition = Vector2.zero;
        t.alignment = TextAnchor.MiddleCenter;
        t.horizontalOverflow = HorizontalWrapMode.Wrap;
        return obj;
    }
    
    [System.Serializable]
    public class CoinGeckoResponse { public BitcoinPrice bitcoin; }
    [System.Serializable]
    public class BitcoinPrice { public float usd; }
    [System.Serializable]
    public class PaprikaTicker { public PaprikaQuotes quotes; }
    [System.Serializable]
    public class PaprikaQuotes { public PaprikaUSD USD; }
    [System.Serializable]
    public class PaprikaUSD { public float price; }
}
