using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;
using System.Collections.Generic;
using NBitcoin; // For Mnemonic, ExtKey, etc.

public class TransactionHistoryUI : MonoBehaviour
{
    private GameObject contentContainer;
    private Text statusText;

    private struct AddressConfig
    {
        public string Name;
        public string Path;
        public ScriptPubKeyType ScriptType;
    }

    void Start()
    {
        if (FindObjectOfType<EventSystem>() == null)
        {
            GameObject es = new GameObject("EventSystem");
            es.AddComponent<EventSystem>();
            es.AddComponent<StandaloneInputModule>();
        }
        
        BuildUI();
        LoadTransactionsFromAPI();
    }

    async void LoadTransactionsFromAPI()
    {
        WalletData wallet = WalletManager2.Instance.GetCurrentWallet();
        if (wallet == null)
        {
            if (statusText != null)
                statusText.text = LocalizationManager.Instance.Get("GEN_NO_WALLET");
            return;
        }

        if (statusText != null)
            statusText.text = LocalizationManager.Instance.Get("HIST_SCAN");
        
        try
        {
            // Get all transactions from all addresses
            // Force MainNet
            List<BlockCypherApiCore.TransactionDisplayData> allTxs = await GetAllAddressesTransactions(wallet.seedPhrase);
            List<BlockCypherApiCore.TransactionDisplayData> txs = allTxs;
            
            if (statusText != null)
                statusText.text = "";
            
            if (txs == null || txs.Count == 0)
            {
                if (statusText != null)
                    statusText.text = LocalizationManager.Instance.Get("HIST_NO_TX");
            }
            else
            {
                // Clear existing
                foreach(Transform child in contentContainer.transform) Destroy(child.gameObject);
                
                foreach (var tx in txs)
                {
                    if (tx == null) continue;
                    
                    GameObject card = MakeCard(contentContainer.transform, 950, 200);
                    
                    // Add button component for click
                    Button cardBtn = card.AddComponent<Button>();
                    cardBtn.onClick.AddListener(() => ShowTransactionDetails(tx));
                    
                    Color txColor = tx.type == "Receive" ? new Color(1f, 0.5f, 0f) : new Color(1f, 0.3f, 0.3f);
                    string symbol = tx.type == "Receive" ? "+" : "-";
                    
                    // Type and Amount (larger, more prominent)
                    MakeText(card.transform, $"{tx.type}", 0, 75, 38, txColor);
                    MakeText(card.transform, $"{symbol}{tx.amount} BTC", 0, 35, 36, ThemeManager.Instance.GetTextColor());
                    
                    // Other Address
                    string displayAddr = tx.otherAddress ?? LocalizationManager.Instance.Get("GEN_UNKNOWN");
                    if (!string.IsNullOrEmpty(displayAddr) && displayAddr != LocalizationManager.Instance.Get("GEN_UNKNOWN"))
                    {
                        if (displayAddr.Length > 32)
                            displayAddr = displayAddr.Substring(0, 16) + "..." + displayAddr.Substring(displayAddr.Length - 16);
                    }
                    string addrLabel = tx.type == "Receive" ? LocalizationManager.Instance.Get("HIST_FROM") + " " : LocalizationManager.Instance.Get("HIST_TO") + " ";
                    MakeText(card.transform, addrLabel + displayAddr, 0, -5, 24, ThemeManager.Instance.GetSecondaryTextColor());
                    
                    // Date (formatted better)
                    string dateDisplay = tx.date ?? LocalizationManager.Instance.Get("GEN_UNKNOWN_DATE");
                    if (dateDisplay == "Unconfirmed")
                    {
                        MakeText(card.transform, "⏳ " + dateDisplay, 0, -40, 26, new Color(1f, 0.8f, 0.2f));
                    }
                    else
                    {
                        MakeText(card.transform, "📅 " + dateDisplay, 0, -40, 26, ThemeManager.Instance.GetSecondaryTextColor());
                    }
                    
                    // TX Hash (truncated)
                    if (!string.IsNullOrEmpty(tx.txHash))
                    {
                        string txHashShort = tx.txHash.Length > 16 ? tx.txHash.Substring(0, 16) + "..." : tx.txHash;
                        MakeText(card.transform, "TX: " + txHashShort, 0, -75, 22, new Color(0.6f, 0.6f, 0.7f));
                    }
                }
            }
        }
        catch (System.Exception ex)
        {
            Debug.LogError($"Failed to load transactions: {ex.Message}");
            if (statusText != null)
            {
                statusText.text = LocalizationManager.Instance.Get("HIST_ERR_LOAD");
                statusText.color = Color.red;
            }
        }
    }
    
    async System.Threading.Tasks.Task<List<BlockCypherApiCore.TransactionDisplayData>> GetAllAddressesTransactions(string seedPhrase)
    {
        List<string> addressesToScan = new List<string>();
        WalletData wallet = WalletManager2.Instance.GetCurrentWallet();
        
        // 0. Collect Main Address
        if (wallet != null && !string.IsNullOrEmpty(wallet.address))
        {
            addressesToScan.Add(wallet.address);
        }

        // 1. Collect Derived Addresses
        if (!string.IsNullOrEmpty(seedPhrase))
        {
            try
            {
                Mnemonic mnemonic = new Mnemonic(seedPhrase, Wordlist.English);
                ExtKey masterKey = mnemonic.DeriveExtKey();
                NBitcoin.Network network = NBitcoin.Network.Main;
                
                string[] paths = { "m/44'/0'/0'/0", "m/84'/0'/0'/0", "m/49'/0'/0'/0" };
                ScriptPubKeyType[] types = { ScriptPubKeyType.Legacy, ScriptPubKeyType.Segwit, ScriptPubKeyType.SegwitP2SH };

                for (int p = 0; p < paths.Length; p++)
                {
                    for (int i = 0; i < 5; i++)
                    {
                        KeyPath keyPath = new KeyPath($"{paths[p]}/{i}");
                        BitcoinAddress address = masterKey.Derive(keyPath).PrivateKey.PubKey.GetAddress(types[p], network);
                        if (!addressesToScan.Contains(address.ToString()))
                            addressesToScan.Add(address.ToString());
                    }
                }
            }
            catch (System.Exception ex) { Debug.LogError($"Derivation Error: {ex.Message}"); }
        }
        
        // 2. Collect Generated Addresses
        if (wallet != null && wallet.generatedAddresses != null)
        {
            foreach (var genAddr in wallet.generatedAddresses)
            {
                if (!addressesToScan.Contains(genAddr.address))
                    addressesToScan.Add(genAddr.address);
            }
        }

        if (addressesToScan.Count == 0) return new List<BlockCypherApiCore.TransactionDisplayData>();

        // 3. Batch Fetch All Transactions
        BlockCypherApiCore api = new BlockCypherApiCore();
        var allTxs = await api.GetBatchTransactions(addressesToScan, false);
        
        Debug.Log($"Batch Scan complete: {allTxs.Count} transactions from {addressesToScan.Count} addresses");
        return allTxs;
    }
    
    async System.Threading.Tasks.Task<List<BlockCypherApiCore.TransactionDisplayData>> GetAddressTransactions(string address)
    {
        var txs = new List<BlockCypherApiCore.TransactionDisplayData>();
        
        try 
        {
             // Force MainNet via BlockCypher
             BlockCypherApiCore api = new BlockCypherApiCore();
             // GetAllTransactions(address, isTestNet) -> false for MainNet
             var coreTxs = await api.GetAllTransactions(address, false);
             if(coreTxs != null) txs.AddRange(coreTxs);
        }
        catch (System.Exception ex)
        {
             Debug.LogError($"MainNet API Error: {ex.Message}");
        }
        
        return txs;
    }

    void BuildUI()
    {
        GameObject canvasObj = new GameObject("Canvas");
        canvasObj.layer = 5;
        Canvas canvas = canvasObj.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        
        CanvasScaler scaler = canvasObj.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1080, 1920);
        scaler.matchWidthOrHeight = 0.5f;
        
        canvasObj.AddComponent<GraphicRaycaster>();

        // BG - Themed
        GameObject bg = new GameObject("BG");
        bg.layer = 5;
        bg.transform.SetParent(canvas.transform, false);
        RectTransform bgRT = bg.AddComponent<RectTransform>();
        bgRT.anchorMin = Vector2.zero; bgRT.anchorMax = Vector2.one; bgRT.sizeDelta = Vector2.zero;
        bg.AddComponent<Image>().color = ThemeManager.Instance.GetBackgroundColor();

        float y = 700;

        MakeText(canvas.transform, LocalizationManager.Instance.Get("HIST_TITLE"), 0, y, 65, ThemeManager.Instance.GetTextColor());
        y -= 160;

        WalletData wallet = WalletManager2.Instance.GetCurrentWallet();
        if (wallet != null)
        {
            MakeText(canvas.transform, $"Wallet: {wallet.address.Substring(0, 20)}...", 0, y, 28, ThemeManager.Instance.GetAccentColor());
            y -= 100;
        }

        GameObject scrollView = new GameObject("ScrollView");
        scrollView.layer = 5;
        scrollView.transform.SetParent(canvas.transform, false);
        RectTransform scrollRT = scrollView.AddComponent<RectTransform>();
        scrollRT.anchoredPosition = new Vector2(0, -100);
        scrollRT.sizeDelta = new Vector2(1000, 1100);
        
        // Themed Scroll BG
        Image scrollBg = scrollView.AddComponent<Image>();
        scrollBg.color = ThemeManager.Instance.IsDarkMode ? new Color(0.05f, 0.05f, 0.08f) : new Color(0.9f, 0.9f, 0.95f);
        
        ScrollRect scrollRect = scrollView.AddComponent<ScrollRect>();
        scrollRect.horizontal = false; scrollRect.vertical = true;
        scrollRect.scrollSensitivity = 30f;
        
        GameObject viewport = new GameObject("Viewport");
        viewport.layer = 5; viewport.transform.SetParent(scrollView.transform, false);
        RectTransform viewportRT = viewport.AddComponent<RectTransform>();
        viewportRT.anchorMin = Vector2.zero; viewportRT.anchorMax = Vector2.one; viewportRT.sizeDelta = Vector2.zero;
        viewport.AddComponent<RectMask2D>();
        viewport.AddComponent<Image>().color = new Color(0,0,0,0);

        GameObject content = new GameObject("Content");
        content.layer = 5; content.transform.SetParent(viewport.transform, false);
        RectTransform contentRT = content.AddComponent<RectTransform>();
        contentRT.anchorMin = new Vector2(0, 1); contentRT.anchorMax = new Vector2(1, 1);
        contentRT.pivot = new Vector2(0.5f, 1); contentRT.anchoredPosition = Vector2.zero;

        VerticalLayoutGroup vlg = content.AddComponent<VerticalLayoutGroup>();
        vlg.childAlignment = TextAnchor.UpperCenter;
        vlg.padding = new RectOffset(0, 0, 20, 20);
        vlg.spacing = 20; 
        vlg.childControlWidth = false; vlg.childControlHeight = false;
        
        ContentSizeFitter csf = content.AddComponent<ContentSizeFitter>();
        csf.verticalFit = ContentSizeFitter.FitMode.PreferredSize; 

        scrollRect.content = contentRT;
        scrollRect.viewport = viewportRT;
        
        contentContainer = content;
        
        statusText = MakeText(canvas.transform, LocalizationManager.Instance.Get("GEN_LOADING"), 0, 0, 40, ThemeManager.Instance.GetSecondaryTextColor());
        
        // Back Button
        MakeButton(canvas.transform, LocalizationManager.Instance.Get("GEN_BACK"), -400, 850, 280, 100, () => SceneManager.LoadScene("MainWallet"))
            .GetComponent<Image>().color = ThemeManager.Instance.GetAccentColor();
    }

    GameObject MakeCard(Transform parent, float w, float h)
    {
        GameObject card = new GameObject("Card");
        card.layer = 5;
        card.transform.SetParent(parent, false);
        RectTransform rt = card.AddComponent<RectTransform>();
        rt.sizeDelta = new Vector2(w, h);
        Image img = card.AddComponent<Image>();
        img.color = ThemeManager.Instance.GetCardColor();
        LayoutElement le = card.AddComponent<LayoutElement>();
        le.preferredWidth = w; le.preferredHeight = h; le.minHeight = h;
        return card;
    }

    Text MakeText(Transform parent, string txt, float x, float y, int size, Color col)
    {
        GameObject obj = new GameObject("Text");
        obj.layer = 5; obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchoredPosition = new Vector2(x, y);
        rt.sizeDelta = new Vector2(950, 50);
        Text text = obj.AddComponent<Text>();
        text.text = txt; text.fontSize = size; text.color = col;
        text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        text.alignment = TextAnchor.MiddleCenter;
        text.horizontalOverflow = HorizontalWrapMode.Wrap;
        return text;
    }

    GameObject MakeButton(Transform parent, string txt, float x, float y, float w, float h, UnityEngine.Events.UnityAction action)
    {
        GameObject obj = new GameObject("Btn");
        obj.layer = 5; obj.transform.SetParent(parent, false);
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchoredPosition = new Vector2(x, y);
        rt.sizeDelta = new Vector2(w, h);
        Image img = obj.AddComponent<Image>();
        img.color = new Color(0.2f, 0.5f, 1f);
        Button btn = obj.AddComponent<Button>();
        btn.onClick.AddListener(action);
        
        GameObject txtObj = new GameObject("Text");
        txtObj.layer = 5; txtObj.transform.SetParent(obj.transform, false);
        RectTransform txtRT = txtObj.AddComponent<RectTransform>();
        txtRT.anchorMin = Vector2.zero; txtRT.anchorMax = Vector2.one;
        Text text = txtObj.AddComponent<Text>();
        text.text = txt; text.fontSize = 40; text.color = Color.white;
        text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        text.alignment = TextAnchor.MiddleCenter; text.fontStyle = FontStyle.Bold;
        return obj;
    }
    
    void ShowTransactionDetails(BlockCypherApiCore.TransactionDisplayData tx)
    {
        GameObject overlay = new GameObject("TxDetailsOverlay");
        overlay.layer = 5;
        overlay.transform.SetParent(GameObject.Find("Canvas").transform, false);
        RectTransform overlayRT = overlay.AddComponent<RectTransform>();
        overlayRT.anchorMin = Vector2.zero; overlayRT.anchorMax = Vector2.one; overlayRT.sizeDelta = Vector2.zero;
        Image overlayImg = overlay.AddComponent<Image>();
        overlayImg.color = new Color(0, 0, 0, 0.85f);
        
        GameObject panel = new GameObject("DetailsPanel");
        panel.layer = 5; panel.transform.SetParent(overlay.transform, false);
        RectTransform panelRT = panel.AddComponent<RectTransform>();
        panelRT.anchorMin = new Vector2(0, 0); panelRT.anchorMax = new Vector2(1, 0.5f); panelRT.sizeDelta = Vector2.zero;
        Image panelImg = panel.AddComponent<Image>();
        panelImg.color = ThemeManager.Instance.GetCardColor();
        
        float y = 450;
        
        // Content
        Color titleColor = tx.type == "Receive" ? new Color(1f, 0.5f, 0f) : new Color(1f, 0.3f, 0.3f);
        MakeText(panel.transform, $"{tx.type} {LocalizationManager.Instance.Get("HIST_DETAILS")}", 0, y, 48, titleColor); // "Receive Transaction Details" might be odd but reusing "Transaction" key or similar
        // Better: just "Transaction Details" or localized "{Type} Transaction"
        // Let's use simple key lookup for type if possible or just English for "Transaction" suffix?
        // Actually I have "HIST_DETAILS" = "Transaction Details"
        // Let's just use HIST_DETAILS
        MakeText(panel.transform, LocalizationManager.Instance.Get("HIST_DETAILS"), 0, y, 48, titleColor);
        y -= 100;
        
        // Amount
        string symbol = tx.type == "Receive" ? "+" : "-";
        MakeText(panel.transform, LocalizationManager.Instance.Get("HIST_AMOUNT_LABEL"), 0, y, 32, ThemeManager.Instance.GetTextColor());
        y -= 50;
        MakeText(panel.transform, $"{symbol}{tx.amount} BTC", 0, y, 42, new Color(1f, 0.8f, 0f));
        y -= 80;
        
        // Date
        MakeText(panel.transform, LocalizationManager.Instance.Get("HIST_DATE"), 0, y, 32, ThemeManager.Instance.GetTextColor());
        y -= 50;
        string dateDisplay = tx.date ?? LocalizationManager.Instance.Get("GEN_UNKNOWN_DATE");
        Color dateColor = dateDisplay == "Unconfirmed" ? new Color(1f, 0.8f, 0.2f) : new Color(0.7f, 0.9f, 1f);
        MakeText(panel.transform, dateDisplay, 0, y, 36, dateColor);
        y -= 80;
        
        // Address
        MakeText(panel.transform, tx.type == "Receive" ? LocalizationManager.Instance.Get("HIST_FROM") : LocalizationManager.Instance.Get("HIST_TO"), 0, y, 32, ThemeManager.Instance.GetTextColor());
        y -= 50;
        CreateCopyableBox(panel.transform, 0, y, 950, 80, tx.otherAddress ?? LocalizationManager.Instance.Get("GEN_UNKNOWN"));
        y -= 110;
        
        // Hash
        MakeText(panel.transform, LocalizationManager.Instance.Get("HIST_TXID"), 0, y, 32, ThemeManager.Instance.GetTextColor());
        y -= 50;
        CreateCopyableBox(panel.transform, 0, y, 950, 80, tx.txHash ?? LocalizationManager.Instance.Get("GEN_UNKNOWN"));
        y -= 110;

        // Close
        MakeButton(panel.transform, LocalizationManager.Instance.Get("GEN_CLOSE"), 0, -450, 500, 90, () => Destroy(overlay))
            .GetComponent<Image>().color = new Color(0.8f, 0.2f, 0.2f);
    }
    
    GameObject CreateCopyableBox(Transform parent, float x, float y, float w, float h, string content)
    {
        GameObject box = new GameObject("CopyableBox");
        box.layer = 5; box.transform.SetParent(parent, false);
        RectTransform boxRT = box.AddComponent<RectTransform>();
        boxRT.anchoredPosition = new Vector2(x, y); boxRT.sizeDelta = new Vector2(w, h);
        Image boxImg = box.AddComponent<Image>();
        boxImg.color = ThemeManager.Instance.IsDarkMode ? new Color(0.1f, 0.1f, 0.15f) : new Color(0.95f, 0.95f, 0.98f);
        
        GameObject textObj = new GameObject("Text");
        textObj.layer = 5; textObj.transform.SetParent(box.transform, false);
        RectTransform textRT = textObj.AddComponent<RectTransform>();
        textRT.anchorMin = Vector2.zero; textRT.anchorMax = new Vector2(0.85f, 1f);
        textRT.offsetMin = new Vector2(20, 0); textRT.offsetMax = new Vector2(-10, 0);
        
        Text text = textObj.AddComponent<Text>();
        text.text = content.Length > 40 ? content.Substring(0, 40) + "..." : content;
        text.fontSize = 28;
        text.color = ThemeManager.Instance.GetAccentColor();
        text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        text.alignment = TextAnchor.MiddleLeft;
        
        // Button
        GameObject btnObj = new GameObject("CopyBtn");
        btnObj.layer = 5; btnObj.transform.SetParent(box.transform, false);
        RectTransform btnRT = btnObj.AddComponent<RectTransform>();
        btnRT.anchorMin = new Vector2(0.85f, 0); btnRT.anchorMax = Vector2.one;
        btnObj.AddComponent<Image>().color = ThemeManager.Instance.GetAccentColor();
        btnObj.AddComponent<Button>().onClick.AddListener(()=> GUIUtility.systemCopyBuffer=content);
        
        // Icon
        GameObject i = new GameObject("I"); i.layer=5; i.transform.SetParent(btnObj.transform, false);
        i.AddComponent<RectTransform>().anchorMin=Vector2.zero; i.GetComponent<RectTransform>().anchorMax=Vector2.one;
        Text it = i.AddComponent<Text>(); it.text="❐"; it.font=Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        it.alignment=TextAnchor.MiddleCenter; it.fontSize=32; it.color=Color.white;

        return box;
    }
}


