using UnityEngine;

public class AudioManager : MonoBehaviour
{
    private static AudioManager _instance;
    public static AudioManager Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = FindObjectOfType<AudioManager>();
                if (_instance == null)
                {
                    GameObject obj = new GameObject("AudioManager");
                    _instance = obj.AddComponent<AudioManager>();
                }
            }
            return _instance;
        }
    }

    private AudioSource audioSource;

    // Audio clips loaded from Resources folder
    private AudioClip clipButtonPress;
    private AudioClip clipBackButton;
    private AudioClip clipCopyAddress;
    private AudioClip clipCloseMenu;
    private AudioClip clipNextPage;
    private AudioClip clipMiningButton;
    private AudioClip clipPinButton;
    private AudioClip clipCreatePinComplete;
    private AudioClip clipUnlockWallet;
    private AudioClip clipWelcomeBack;

    void Awake()
    {
        if (_instance == null)
        {
            _instance = this;
            DontDestroyOnLoad(gameObject);
            InitializeAudio();
        }
        else if (_instance != this)
        {
            Destroy(gameObject);
        }
    }

    void InitializeAudio()
    {
        audioSource = gameObject.AddComponent<AudioSource>();
        audioSource.playOnAwake = false;

        // Load all audio clips from Resources folder
        clipButtonPress = Resources.Load<AudioClip>("buttonpress");
        clipBackButton = Resources.Load<AudioClip>("backbutton");
        clipCopyAddress = Resources.Load<AudioClip>("copyaddressbutton");
        clipCloseMenu = Resources.Load<AudioClip>("closemenu");
        clipNextPage = Resources.Load<AudioClip>("nextpage");
        clipMiningButton = Resources.Load<AudioClip>("miningbutton");
        clipPinButton = Resources.Load<AudioClip>("PIN button");
        clipCreatePinComplete = Resources.Load<AudioClip>("create new PIN complete");
        clipUnlockWallet = Resources.Load<AudioClip>("unlockwallet");
        clipWelcomeBack = Resources.Load<AudioClip>("welcomeback");

        Debug.Log("[AudioManager] Audio clips loaded from Resources folder.");
    }

    private void PlayClip(AudioClip clip)
    {
        if (PlayerPrefs.GetInt("SoundEnabled", 1) != 1) return;
        if (audioSource == null || clip == null) return;
        audioSource.PlayOneShot(clip);
    }

    /// <summary>General button click sound</summary>
    public void PlayClick()
    {
        PlayClip(clipButtonPress);
    }

    /// <summary>Back button sound</summary>
    public void PlayBack()
    {
        PlayClip(clipBackButton);
    }

    /// <summary>Copy address button sound</summary>
    public void PlayCopy()
    {
        PlayClip(clipCopyAddress);
    }

    /// <summary>Close menu sound</summary>
    public void PlayCloseMenu()
    {
        PlayClip(clipCloseMenu);
    }

    /// <summary>Next page navigation sound</summary>
    public void PlayNextPage()
    {
        PlayClip(clipNextPage);
    }

    /// <summary>Mining button sound</summary>
    public void PlayMining()
    {
        PlayClip(clipMiningButton);
    }

    /// <summary>PIN button press sound</summary>
    public void PlayPinButton()
    {
        PlayClip(clipPinButton);
    }

    /// <summary>PIN creation complete sound</summary>
    public void PlayCreatePIN()
    {
        PlayClip(clipCreatePinComplete);
    }

    /// <summary>Wallet unlock sound</summary>
    public void PlayUnlock()
    {
        PlayClip(clipUnlockWallet);
    }

    /// <summary>Welcome back sound</summary>
    public void PlayWelcomeBack()
    {
        PlayClip(clipWelcomeBack);
    }
}
