using UnityEngine;
using System.IO;
using System.Collections.Generic;
using System.Threading.Tasks;

public class WalletManager2 : MonoBehaviour
{
    private static WalletManager2 instance;
    public static WalletManager2 Instance
    {
        get
        {
            if (instance == null)
            {
                GameObject obj = new GameObject("WalletManager");
                instance = obj.AddComponent<WalletManager2>();
                DontDestroyOnLoad(obj);
            }
            return instance;
        }
    }

    private WalletData currentWallet;
    private string savePath;

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
            // ✅ PHASE 4: Separate save files for each network
            // savePath will be set when wallet is loaded/created
            LoadWallet();
        }
        else if (instance != this)
        {
            Destroy(gameObject);
        }
    }
    
    // ✅ PHASE 4: Get network-specific save path (FORCED MAINNET)
    private string GetSavePath(bool isTestNet)
    {
        return Application.persistentDataPath + "/wallet_mainnet.json";
    }

    public void SaveWallet(string seedPhrase, bool isTestNet, string address, string privateKey)
    {
        // Allow empty seedPhrase for private key imports, but address is required
        if (string.IsNullOrEmpty(address))
        {
            Debug.LogError("Cannot save wallet: No address provided");
            return;
        }
        
        bool isPKImport = string.IsNullOrEmpty(seedPhrase);
        
        // ✅ PHASE 4: Use network-specific save path
        savePath = GetSavePath(false); // Force MainNet
        
        currentWallet = new WalletData
        {
            seedPhrase = seedPhrase ?? "",
            isTestNet = false, // Force MainNet
            address = address,
            privateKey = privateKey,
            isPrivateKeyImport = isPKImport,
            parentAddress = address, // Store the very first address as parent (never changes)
            currentAddressIndex = 1, // MainNet default index
            generatedAddresses = new System.Collections.Generic.List<GeneratedAddress>()
        };

        if (currentWallet.transactions == null)
        {
            currentWallet.transactions = new System.Collections.Generic.List<TransactionHistory>();
        }

        try
        {
            string json = JsonUtility.ToJson(currentWallet, true);
            File.WriteAllText(savePath, json);
            Debug.Log($"✅ Wallet saved to: {savePath} (PK Import: {isPKImport})");
        }
        catch (System.Exception ex)
        {
            Debug.LogError($"Failed to save wallet: {ex.Message}");
        }
    }

    public void LoadWallet()
    {
        // ✅ PHASE 4: Only Load MainNet
        string path = GetSavePath(false);
        
        try
        {
            if (File.Exists(path))
            {
                string json = File.ReadAllText(path);
                if (!string.IsNullOrEmpty(json))
                {
                    WalletData wallet = JsonUtility.FromJson<WalletData>(json);
                    // Accept wallet if it has a seed phrase OR a private key (PK import)
                    if (wallet != null && (!string.IsNullOrEmpty(wallet.seedPhrase) || !string.IsNullOrEmpty(wallet.privateKey)))
                    {
                        wallet.isTestNet = false; // Ensure it's treated as MainNet
                        currentWallet = wallet;
                        savePath = path;
                        Debug.Log($"✅ Wallet loaded from: {path} (MainNet, PK Import: {wallet.isPrivateKeyImport})");
                        return;
                    }
                }
            }
        }
        catch (System.Exception ex)
        {
            Debug.LogError($"Failed to load wallet from {path}: {ex.Message}");
        }
        
        Debug.Log("No saved wallet found");
        currentWallet = null;
    }

    public WalletData GetCurrentWallet()
    {
        return currentWallet;
    }

    public bool HasWallet()
    {
        // Return true if wallet has seed phrase OR private key (for PK imports)
        return currentWallet != null && 
               (!string.IsNullOrEmpty(currentWallet.seedPhrase) || !string.IsNullOrEmpty(currentWallet.privateKey));
    }

    public void ToggleNetwork()
    {
        Debug.Log("Network Toggle Removed (MainNet Only)");
    }
    public void UpdateBalance(double newBalance)
    {
        if (currentWallet == null) return;
        currentWallet.balance = newBalance;
        
        // ✅ NEW: Update cached balance and timestamp for instant display
        currentWallet.cachedBalance = newBalance;
        currentWallet.lastBalanceUpdate = System.DateTime.Now.ToString("HH:mm:ss");
        
        // ✅ NEW: Mark initial scan as completed
        currentWallet.hasCompletedInitialScan = true;
        
        // ✅ PHASE 4: Ensure we're using the correct network-specific path
        savePath = GetSavePath(currentWallet.isTestNet);
        
        // Save without recreating
        try {
            string json = JsonUtility.ToJson(currentWallet, true);
            File.WriteAllText(savePath, json);
            Debug.Log($"Balance updated: {newBalance:F8} (cached for instant display)");
        } catch (System.Exception ex) { Debug.LogError("Save Error: " + ex.Message); }
    }

    /// <summary>
    /// Get the next available address index for generation
    /// </summary>
    public int GetNextAddressIndex()
    {
        if (currentWallet == null) return 0;
        currentWallet.currentAddressIndex++;
        return currentWallet.currentAddressIndex;
    }

    /// <summary>
    /// Add a newly generated address to the wallet and save to file
    /// </summary>
    public void AddGeneratedAddress(string address, int index)
    {
        if (currentWallet == null) return;
        
        if (currentWallet.generatedAddresses == null)
            currentWallet.generatedAddresses = new List<GeneratedAddress>();
        
        GeneratedAddress genAddr = new GeneratedAddress
        {
            address = address,
            index = index,
            dateGenerated = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm")
        };
        
        currentWallet.generatedAddresses.Add(genAddr);
        
        // Save to file
        try {
            savePath = GetSavePath(false);
            string json = JsonUtility.ToJson(currentWallet, true);
            File.WriteAllText(savePath, json);
            Debug.Log($"Address saved: {address} (index {index}), total: {currentWallet.generatedAddresses.Count}");
        } catch (System.Exception ex) { Debug.LogError("Save Address Error: " + ex.Message); }
    }

    /// <summary>
    /// Update the main wallet address
    /// </summary>
    public void UpdateMainAddress(string newAddress)
    {
        if (currentWallet == null) return;
        currentWallet.address = newAddress;
        
        // Save to file
        try {
            savePath = GetSavePath(false);
            string json = JsonUtility.ToJson(currentWallet, true);
            File.WriteAllText(savePath, json);
            Debug.Log($"Main address updated to: {newAddress}");
        } catch (System.Exception ex) { Debug.LogError("Save Error: " + ex.Message); }
    }

    public async void SyncTransactionHistory()
    {
        if (currentWallet == null) return;
        
        Debug.Log("Syncing Transaction History for all addresses...");
        BitcoinTransactionService service = new BitcoinTransactionService();
        try
        {
            var allHistory = new List<TransactionHistory>();
            var scannedAddresses = new HashSet<string>();
            
            // 1. Scan main address
            await ScanAddressHistory(service, currentWallet.address, allHistory, scannedAddresses);
            
            // 2. Scan derived addresses (Legacy BIP44 + SegWit BIP84, first 5 each)
            if (!string.IsNullOrEmpty(currentWallet.seedPhrase))
            {
                try
                {
                    var mnemonic = new NBitcoin.Mnemonic(currentWallet.seedPhrase, NBitcoin.Wordlist.English);
                    var masterKey = mnemonic.DeriveExtKey();
                    var network = NBitcoin.Network.Main;
                    
                    // Legacy addresses (BIP44)
                    for (int i = 0; i < 5; i++)
                    {
                        var keyPath = new NBitcoin.KeyPath($"m/44'/0'/0'/0/{i}");
                        var key = masterKey.Derive(keyPath).PrivateKey;
                        string addr = key.PubKey.GetAddress(NBitcoin.ScriptPubKeyType.Legacy, network).ToString();
                        int count = await ScanAddressHistory(service, addr, allHistory, scannedAddresses);
                        if (count == 0) break; // Gap limit: stop if unused address found
                    }
                    
                    // SegWit addresses (BIP84)
                    for (int i = 0; i < 5; i++)
                    {
                        var keyPath = new NBitcoin.KeyPath($"m/84'/0'/0'/0/{i}");
                        var key = masterKey.Derive(keyPath).PrivateKey;
                        string addr = key.PubKey.GetAddress(NBitcoin.ScriptPubKeyType.Segwit, network).ToString();
                        int count = await ScanAddressHistory(service, addr, allHistory, scannedAddresses);
                        if (count == 0) break; // Gap limit: stop if unused address found
                    }
                }
                catch (System.Exception ex) { Debug.LogWarning($"Derived address scan error: {ex.Message}"); }
            }
            
            // 3. Scan user-generated addresses
            if (currentWallet.generatedAddresses != null)
            {
                foreach (var genAddr in currentWallet.generatedAddresses)
                {
                    await ScanAddressHistory(service, genAddr.address, allHistory, scannedAddresses);
                }
            }
            
            if (allHistory.Count > 0)
            {
                currentWallet.transactions = allHistory;
                try {
                    string json = JsonUtility.ToJson(currentWallet, true);
                    File.WriteAllText(savePath, json);
                    Debug.Log($"Synced {allHistory.Count} transactions from {scannedAddresses.Count} addresses.");
                } catch {}
            }
        }
        catch (System.Exception ex)
        {
            Debug.LogError("Sync History Failed: " + ex.Message);
        }
    }
    
    private async System.Threading.Tasks.Task<int> ScanAddressHistory(
        BitcoinTransactionService service, string address, 
        List<TransactionHistory> allHistory, HashSet<string> scanned)
    {
        if (string.IsNullOrEmpty(address) || scanned.Contains(address)) return 0;
        scanned.Add(address);
        
        try
        {
            var history = await service.GetTransactionHistory(address);
            if (history != null && history.Count > 0)
            {
                // Avoid duplicate transactions by checking txHash
                foreach (var tx in history)
                {
                    bool isDuplicate = false;
                    foreach (var existing in allHistory)
                    {
                        if (existing.txHash == tx.txHash) { isDuplicate = true; break; }
                    }
                    if (!isDuplicate) allHistory.Add(tx);
                }
                await System.Threading.Tasks.Task.Delay(500); // Wait between addresses
                return history.Count;
            }
        }
        catch (System.Exception ex) { Debug.LogWarning($"History scan error for {address}: {ex.Message}"); }
        return 0; // Return 0 if no history or error
    }

    public void AddTransaction(string type, string address, string amount, string txHash = "")
    {
        if (currentWallet == null)
        {
            Debug.LogWarning("Cannot add transaction: No wallet loaded");
            return;
        }
        
        if (currentWallet.transactions == null)
        {
            currentWallet.transactions = new System.Collections.Generic.List<TransactionHistory>();
        }
        
        try
        {
            TransactionHistory tx = new TransactionHistory
            {
                type = type,
                address = address,
                amount = amount,
                date = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                txHash = txHash
            };

            currentWallet.transactions.Add(tx);
            string json = JsonUtility.ToJson(currentWallet, true);
            File.WriteAllText(savePath, json);
            Debug.Log($"Transaction added: {type} {amount} BTC");
        }
        catch (System.Exception ex)
        {
            Debug.LogError($"Failed to add transaction: {ex.Message}");
        }
    }

    

    public void DeleteWallet()
    {
        try
        {
            if (File.Exists(savePath))
            {
                File.Delete(savePath);
                Debug.Log("Wallet deleted");
            }
        }
        catch (System.Exception ex)
        {
            Debug.LogError($"Failed to delete wallet: {ex.Message}");
        }
        finally
        {
            currentWallet = null;
        }
    }
    
    public void SwitchNetwork(bool toTestNet)
    {
        if (currentWallet == null)
        {
            Debug.LogWarning("No wallet to switch");
            return;
        }
        
        try
        {
            // ✅ PHASE 4: Save current wallet before switching
            string currentJson = JsonUtility.ToJson(currentWallet, true);
            File.WriteAllText(savePath, currentJson);
            
            // ✅ PHASE 4: Try to load wallet from target network
            string targetPath = GetSavePath(toTestNet);
            
            if (File.Exists(targetPath))
            {
                // Load existing wallet from target network
                string json = File.ReadAllText(targetPath);
                WalletData targetWallet = JsonUtility.FromJson<WalletData>(json);
                
                if (targetWallet != null && !string.IsNullOrEmpty(targetWallet.seedPhrase))
                {
                    currentWallet = targetWallet;
                    savePath = targetPath;
                    Debug.Log($"✅ Switched to existing {(toTestNet ? "TestNet" : "MainNet")} wallet");
                    return;
                }
            }
            
            // ✅ PHASE 4: No wallet exists on target network, create new one from seed
            string seedPhrase = currentWallet.seedPhrase;
            NBitcoin.Network network = toTestNet ? NBitcoin.Network.TestNet : NBitcoin.Network.Main;
            var walletCore = new BitcoinWalletCore(seedPhrase, network);
            int index = toTestNet ? 0 : 1;
            
            // Create new wallet data for target network
            currentWallet = new WalletData
            {
                seedPhrase = seedPhrase,
                isTestNet = toTestNet,
                address = walletCore.GetAddress(index),
                privateKey = walletCore.GetPrivateKey(index),
                currentAddressIndex = index,
                generatedAddresses = new System.Collections.Generic.List<GeneratedAddress>(),
                transactions = new System.Collections.Generic.List<TransactionHistory>()
            };
            
            savePath = targetPath;
            string newJson = JsonUtility.ToJson(currentWallet, true);
            File.WriteAllText(savePath, newJson);
            
            Debug.Log($"✅ Created new {(toTestNet ? "TestNet" : "MainNet")} wallet from seed");
        }
        catch (System.Exception ex)
        {
            Debug.LogError($"Failed to switch network: {ex.Message}");
        }
    }
}
