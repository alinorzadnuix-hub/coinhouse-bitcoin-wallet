using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;

public class AndroidBuilder
{
    [MenuItem("Bitcoin Wallet/Build Android APK")]
    public static void BuildAndroidAPK()
    {
        // 1. Scene List
        List<string> scenes = new List<string>();
        foreach (EditorBuildSettingsScene scene in EditorBuildSettings.scenes)
        {
            if (scene.enabled)
                scenes.Add(scene.path);
        }

        if (scenes.Count == 0)
        {
            Debug.LogError("Error: No scenes are enabled in Build Settings!");
            EditorUtility.DisplayDialog("Build Error", "No scenes are enabled in Build Settings. Please add your scenes first.", "OK");
            return;
        }

        // 2. Output Path
        string buildPath = "Builds/Android";
        if (!Directory.Exists(buildPath)) Directory.CreateDirectory(buildPath);
        
        string apkName = "BitcoinWallet_" + System.DateTime.Now.ToString("yyyyMMdd_HHmm") + ".apk";
        string location = Path.Combine(buildPath, apkName);

        // 3. Build Options
        BuildPlayerOptions buildPlayerOptions = new BuildPlayerOptions();
        buildPlayerOptions.scenes = scenes.ToArray();
        buildPlayerOptions.locationPathName = location;
        buildPlayerOptions.target = BuildTarget.Android;
        buildPlayerOptions.options = BuildOptions.None;

        // 4. Execute
        Debug.Log("Building Android APK to: " + location);
        UnityEditor.Build.Reporting.BuildReport report = BuildPipeline.BuildPlayer(buildPlayerOptions);
        
        UnityEditor.Build.Reporting.BuildSummary summary = report.summary;

        if (summary.result == UnityEditor.Build.Reporting.BuildResult.Succeeded)
        {
            Debug.Log("Build succeeded: " + summary.totalSize + " bytes");
            EditorUtility.RevealInFinder(location);
            EditorUtility.DisplayDialog("Build Success", $"APK created successfully!\n\nLocation: {location}", "OK");
        }
        else if (summary.result == UnityEditor.Build.Reporting.BuildResult.Failed)
        {
            Debug.LogError("Build failed");
            EditorUtility.DisplayDialog("Build Failed", "The build failed. Check the Console for error details.", "OK");
        }
    }
}
