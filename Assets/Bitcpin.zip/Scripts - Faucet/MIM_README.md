# MIM Price Display Script

## نام فایل
`MIMPriceDisplay.cs`

## توضیحات
این اسکریپت قیمت Magic Internet Money (MIM) را از API سایت CoinPaprika دریافت کرده و در یک Text نمایش می‌دهد.

## ویژگی‌ها
✅ دریافت خودکار قیمت هر 60 ثانیه  
✅ نمایش قیمت فعلی MIM به دلار  
✅ نمایش درصد تغییرات 24 ساعته  
✅ رنگ‌بندی تغییرات (سبز برای مثبت، قرمز برای منفی)  
✅ مدیریت خطاها و نمایش پیام‌های مناسب  

## API استفاده شده
```
https://api.coinpaprika.com/v1/tickers/mim-magic-internet-money
```

## نحوه استفاده

### روش 1: اضافه کردن به GameObject موجود
1. یک GameObject خالی در صحنه بسازید
2. اسکریپت `MIMPriceDisplay` را به آن اضافه کنید
3. بازی را اجرا کنید

### روش 2: استفاده در کد
```csharp
// دریافت قیمت فعلی
MIMPriceDisplay mimDisplay = FindObjectOfType<MIMPriceDisplay>();
float currentPrice = mimDisplay.GetCurrentPrice();

// به‌روزرسانی دستی
mimDisplay.RefreshPrice();
```

## خروجی نمونه
```
MIM: $0.9994 (+0.12%)
```

## ساختار داده‌های JSON
اسکریپت از کلاس‌های زیر برای پارس کردن JSON استفاده می‌کند:
- `MIMPriceData` - داده‌های اصلی
- `QuotesData` - داده‌های قیمت
- `USDData` - قیمت به دلار و تغییرات

## تنظیمات قابل تغییر
در کد می‌توانید این موارد را تغییر دهید:

```csharp
// فاصله زمانی به‌روزرسانی (ثانیه)
private float updateInterval = 60f;

// موقعیت نمایش متن
rectTransform.anchoredPosition = new Vector2(0, 400);

// اندازه متن
priceText.fontSize = 40;

// رنگ متن
priceText.color = new Color(1f, 0.84f, 0f); // طلایی
```

## نکات مهم
⚠️ اتصال اینترنت برای دریافت قیمت لازم است  
⚠️ API رایگان است و محدودیت درخواست دارد  
⚠️ در صورت خطا، پیام خطا در Console نمایش داده می‌شود  

## لاگ‌ها
اسکریپت لاگ‌های زیر را در Console نمایش می‌دهد:
- ✅ موفقیت: `MIM Price Updated: $0.9994 | 24h Change: +0.12%`
- ⚠️ هشدار: `Failed to parse MIM price data`
- ❌ خطا: `Failed to fetch MIM price: [error message]`

## سازنده
تاریخ ساخت: 2025-12-28
