using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
 
public class MIMPriceDisplay : MonoBehaviour
{
    private const string API_URL = "https://api.coinpaprika.com/v1/tickers/mim-magic-internet-money";
    private float updateInterval = 30f; // Update every 30 seconds
    private bool isUpdating = false;
    private float currentPrice = 0f;
    public UnityEngine.UI.Text priceText; 
    void Start()
    {
        StartCoroutine(UpdatePriceRoutine());
    }

    IEnumerator UpdatePriceRoutine()
    {
        while (true)
        {
            yield return StartCoroutine(FetchPrice());
            yield return new WaitForSeconds(updateInterval);
        }
    }

    IEnumerator FetchPrice()
    {
        if (isUpdating)
            yield break;

        isUpdating = true;

        using (UnityWebRequest request = UnityWebRequest.Get(API_URL))
        {
            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                try
                {
                    string jsonResponse = request.downloadHandler.text;
                    MIMPriceData priceData = JsonUtility.FromJson<MIMPriceData>(jsonResponse);
                    
                    if (priceData != null && priceData.quotes != null && priceData.quotes.USD != null)
                    {
                        currentPrice = priceData.quotes.USD.price;
                        
                        // Truncate to 2 decimal places without rounding
                        float truncatedPrice = Mathf.Floor(currentPrice * 100f) / 100f;
                        priceText.text = $"PFC:${truncatedPrice:F2}";
                        Debug.Log($"PCH: {truncatedPrice:F2}");
                    }
                    else
                    {
                        Debug.LogWarning("⚠️ Failed to parse MIM price data");
                    }
                }
                catch (System.Exception ex)
                {
                    Debug.LogError($"❌ Error parsing MIM price: {ex.Message}");
                }
            }
            else
            {
                Debug.LogError($"❌ Failed to fetch MIM price: {request.error}");
            }
        }

        isUpdating = false;
    }

    // Manual refresh method (can be called from other scripts)
    public void RefreshPrice()
    {
        StartCoroutine(FetchPrice());
    }

    // Get current price (for use by other scripts)
    public float GetCurrentPrice()
    {
        return currentPrice;
    }
}

// Data structures for JSON parsing
[System.Serializable]
public class MIMPriceData
{
    public string id;
    public string name;
    public string symbol;
    public int rank;
    public QuotesData quotes;
}

[System.Serializable]
public class QuotesData
{
    public USDData USD;
}

[System.Serializable]
public class USDData
{
    public float price;
    public float volume_24h;
    public float market_cap;
    public float percent_change_24h;
    public float percent_change_7d;
    public float percent_change_30d;
}
