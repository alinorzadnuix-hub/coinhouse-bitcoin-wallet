using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
using System.Collections;

public class EnhancedFaucetUI : MonoBehaviour
{
    [Header("UI References")]
    public InputField amountInputField;
    public Button requestButton;
    
    [Header("Error Panel")]
    public GameObject errorPanel;
    public Text errorText;

    [Header("Faucet Settings")]
    public string faucetURL = "http://89.106.206.25:3000/api/send";
    
    [Header("Exchange Rate")]
    public decimal poofcashToUSD = 1.0m;  // 1 Poofcash = 1 USD
    
    [Header("Test Mode")]
    public bool testMode = false;
    public float testPoofcashAmount = 10f;

    private string currentWalletAddress = "";
    private const long SATOSHI_PER_BTC = 100000000;
    private decimal currentPoofcashBalance = 0;
    private decimal lastPoofcashBalance = -1;
    private float updateInterval = 1f;
    private float nextUpdateTime = 0f;

    private void Start()
    {
        // Disable input field
        if (amountInputField != null)
        {
            amountInputField.interactable = false;
            amountInputField.readOnly = true;
        }
        
        if (requestButton != null)
        {
            requestButton.onClick.AddListener(OnRequestButtonClicked);
        }

        LoadWalletAddress();
        LoadPoofcashBalance();
        HideError();
    }
    
    private void Update()
    {
        if (Time.time >= nextUpdateTime)
        {
            nextUpdateTime = Time.time + updateInterval;
            
            if (testMode)
            {
                decimal newBalance = (decimal)testPoofcashAmount;
                if (newBalance != lastPoofcashBalance)
                {
                    lastPoofcashBalance = newBalance;
                    LoadPoofcashBalance();
                }
            }
            else if (GameManager.Instance != null && GameManager.Instance.Goldenbit != null)
            {
                decimal newBalance = GameManager.Instance.Goldenbit.value;
                if (newBalance != lastPoofcashBalance)
                {
                    lastPoofcashBalance = newBalance;
                    LoadPoofcashBalance();
                }
            }
        }
    }
    
    private void ShowError(string message)
    {
        if (errorPanel != null) errorPanel.SetActive(true);
        if (errorText != null)
        {
            errorText.text = message;
            errorText.color = Color.red;
        }
        Debug.LogError(message);
    }
    
    private void ShowSuccess(string message)
    {
        if (errorPanel != null) errorPanel.SetActive(true);
        if (errorText != null)
        {
            errorText.text = message;
            errorText.color = Color.green;
        }
        Debug.Log(message);
    }
    
    private void HideError()
    {
        if (errorPanel != null) errorPanel.SetActive(false);
    }

    private void LoadWalletAddress()
    {
        if (WalletManager2.Instance != null && WalletManager2.Instance.HasWallet())
        {
            WalletData wallet = WalletManager2.Instance.GetCurrentWallet();
            if (wallet != null)
            {
                if (wallet.isTestNet)
                {
                    currentWalletAddress = wallet.address;
                    HideError();
                    Debug.Log($"✓ Loaded TestNet Wallet Address: {currentWalletAddress}");
                }
                else
                {
                    ShowError("✗ ERROR: Please switch to TestNet!");
                    if (requestButton != null) requestButton.interactable = false;
                }
            }
        }
        else
        {
            ShowError("✗ ERROR: No wallet found!");
            if (requestButton != null) requestButton.interactable = false;
        }
    }
    
    private void LoadPoofcashBalance()
    {
        try
        {
            // Get Poofcash balance
            if (testMode)
            {
                currentPoofcashBalance = (decimal)testPoofcashAmount;
            }
            else if (GameManager.Instance != null && GameManager.Instance.Goldenbit != null)
            {
                currentPoofcashBalance = GameManager.Instance.Goldenbit.value;
            }
            else
            {
                ShowError("✗ ERROR: GameManager not found!");
                if (amountInputField != null) amountInputField.text = "0.00 Poofcash";
                return;
            }
            
            // Get tBTC price from API
            decimal btcPrice = 0.09m; // Default fallback
            if (TBTCPriceDisplay.Instance != null && TBTCPriceDisplay.Instance.IsPriceLoaded)
            {
                btcPrice = (decimal)TBTCPriceDisplay.Instance.CurrentPriceUSD;
            }
            
            // Simple calculation: Poofcash USD ÷ tBTC Price
            decimal usdValue = currentPoofcashBalance * poofcashToUSD;
            decimal btcEquivalent = usdValue / btcPrice;
            
            // Display
            if (amountInputField != null)
            {
                string mode = testMode ? " (TEST)" : "";
                amountInputField.text = $"{currentPoofcashBalance:F2} Poofcash ≈ {btcEquivalent:F8} tBTC{mode}";
            }
            
            Debug.Log($"💰 Poofcash: {currentPoofcashBalance} | USD: ${usdValue} | tBTC Price: ${btcPrice} | tBTC: {btcEquivalent:F8}");
        }
        catch (System.Exception ex)
        {
            ShowError($"✗ ERROR: {ex.Message}");
        }
    }

    private void OnRequestButtonClicked()
    {
        if (string.IsNullOrEmpty(currentWalletAddress))
        {
            ShowError("✗ ERROR: No wallet address!");
            return;
        }

        if (currentPoofcashBalance < 1m)
        {
            ShowError("⚠ Minimum: 1 Poofcash");
            return;
        }

        // Get tBTC price from API
        decimal btcPrice = 0.09m; // Default
        if (TBTCPriceDisplay.Instance != null && TBTCPriceDisplay.Instance.IsPriceLoaded)
        {
            btcPrice = (decimal)TBTCPriceDisplay.Instance.CurrentPriceUSD;
        }
        
        // Simple calculation
        decimal usdValue = currentPoofcashBalance * poofcashToUSD;
        decimal btcAmount = usdValue / btcPrice;
        long satoshiAmount = (long)(btcAmount * SATOSHI_PER_BTC);

        Debug.Log($"💰 === EXCHANGE ===");
        Debug.Log($"💰 Poofcash: {currentPoofcashBalance}");
        Debug.Log($"💰 USD Value: ${usdValue}");
        Debug.Log($"💰 tBTC Price: ${btcPrice}");
        Debug.Log($"💰 tBTC Amount: {btcAmount:F8}");
        Debug.Log($"💰 Satoshi: {satoshiAmount:N0}");

        HideError();
        StartCoroutine(SendFaucetRequest(currentWalletAddress, satoshiAmount, currentPoofcashBalance));
    }

    private IEnumerator SendFaucetRequest(string address, long satoshiAmount, decimal poofcashAmount)
    {
        Debug.Log("→ Sending request to faucet...");

        if (requestButton != null) requestButton.interactable = false;

        FaucetRequest request = new FaucetRequest
        {
            address = address,
            amount = satoshiAmount
        };

        string jsonData = JsonUtility.ToJson(request);
        Debug.Log($"→ Payload: {jsonData}");

        using (UnityWebRequest www = new UnityWebRequest(faucetURL, "POST"))
        {
            byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(jsonData);
            www.uploadHandler = new UploadHandlerRaw(bodyRaw);
            www.downloadHandler = new DownloadHandlerBuffer();
            www.SetRequestHeader("Content-Type", "application/json");

            yield return www.SendWebRequest();

            if (requestButton != null) requestButton.interactable = true;

            if (www.result == UnityWebRequest.Result.Success)
            {
                Debug.Log($"→ Response: {www.downloadHandler.text}");
                
                try
                {
                    FaucetResponse response = JsonUtility.FromJson<FaucetResponse>(www.downloadHandler.text);
                    
                    if (response.success)
                    {
                        decimal btcReceived = satoshiAmount / (decimal)SATOSHI_PER_BTC;
                        decimal usdValue = poofcashAmount * poofcashToUSD;
                        
                        Debug.Log($"✓✓✓ SUCCESS! ✓✓✓");
                        Debug.Log($"✓ Poofcash: {poofcashAmount}");
                        Debug.Log($"✓ USD: ${usdValue}");
                        Debug.Log($"✓ tBTC: {btcReceived:F8}");
                        Debug.Log($"✓ TX: {response.txHash}");
                        
                        ShowSuccess($"✓ SUCCESS!\\n{poofcashAmount:F2} Poofcash → {btcReceived:F8} tBTC");
                        
                        // Clear Poofcash
                        if (GameManager.Instance != null && GameManager.Instance.Goldenbit != null)
                        {
                            GameManager.Instance.Goldenbit.SetNumber(0);
                        }
                        
                        LoadPoofcashBalance();
                        
                        // Add to wallet history
                        if (WalletManager2.Instance != null)
                        {
                            WalletManager2.Instance.AddTransaction(
                                "Received", 
                                "Poofcash Exchange", 
                                btcReceived.ToString("0.00000000"), 
                                response.txHash
                            );
                        }
                    }
                    else
                    {
                        ShowError($"✗ FAUCET ERROR: {response.error}");
                    }
                }
                catch (System.Exception e)
                {
                    ShowError($"⚠ Parse error: {e.Message}");
                    Debug.LogWarning($"⚠ Raw Response: {www.downloadHandler.text}");
                }
            }
            else
            {
                ShowError($"✗ REQUEST FAILED: {www.error}");
                Debug.LogError($"✗ Error: {www.error}");
                Debug.LogError($"✗ Response Code: {www.responseCode}");
                
                if (www.downloadHandler != null && !string.IsNullOrEmpty(www.downloadHandler.text))
                {
                    Debug.LogError($"✗ Server Response: {www.downloadHandler.text}");
                }
            }
        }
    }

    public void RefreshWalletAddress()
    {
        LoadWalletAddress();
    }

    [System.Serializable]
    private class FaucetRequest
    {
        public string address;
        public long amount;
    }

    [System.Serializable]
    private class FaucetResponse
    {
        public bool success;
        public string message;
        public string txHash;
        public long amount;
        public long fee;
        public string explorerUrl;
        public string error;
    }
}
