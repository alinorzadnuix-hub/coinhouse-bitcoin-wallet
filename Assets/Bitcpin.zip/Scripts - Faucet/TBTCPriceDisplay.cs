using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
using System.Collections;

/// <summary>
/// Fetches TBTC (Bitcoin Testnet) price from CoinPaprika API
/// </summary>
public class TBTCPriceDisplay : MonoBehaviour
{
    public static TBTCPriceDisplay Instance { get; private set; }
    
    public Text priceText;
    
    private const string TBTC_API = "https://api.coinpaprika.com/v1/tickers/tbtc-bitcoin-testnet";
    
    // Public property to access current price
    public float CurrentPriceUSD { get; private set; } = 50f; // Default value for tBTC
    public bool IsPriceLoaded { get; private set; } = false;
    
    void Awake()
    {
        // Singleton pattern (scene-specific)
        if (Instance == null)
        {
            Instance = this;
            // Removed DontDestroyOnLoad - GameObject will be destroyed on scene change
        }
        else
        {
            Destroy(gameObject);
        }
    }
    
    void Start()
    {
        StartCoroutine(FetchTBTCPrice());
    }
    
    IEnumerator FetchTBTCPrice()
    {
        if (priceText != null)
        {
            priceText.text = "Loading price...";
        }
        
        using (UnityWebRequest request = UnityWebRequest.Get(TBTC_API))
        {
            yield return request.SendWebRequest();
            
            if (request.result != UnityWebRequest.Result.Success)
            {
                if (priceText != null)
                {
                    priceText.text = "Price unavailable";
                }
                Debug.LogError($"TBTC Price Error: {request.error}");
                IsPriceLoaded = false;
            }
            else
            {
                try
                {
                    string json = request.downloadHandler.text;
                    TBTCResponse response = JsonUtility.FromJson<TBTCResponse>(json);
                    
                    if (response != null && response.quotes != null && response.quotes.USD != null)
                    {
                        CurrentPriceUSD = response.quotes.USD.price;
                        IsPriceLoaded = true;
                        
                        if (priceText != null)
                        {
                            priceText.text = $"${CurrentPriceUSD:F2}";
                        }
                        
                        Debug.Log($"✓ TBTC Price Loaded: ${CurrentPriceUSD}");
                    }
                    else
                    {
                        if (priceText != null)
                        {
                            priceText.text = "Price unavailable";
                        }
                        IsPriceLoaded = false;
                    }
                }
                catch (System.Exception ex)
                {
                    if (priceText != null)
                    {
                        priceText.text = "Parse error";
                    }
                    Debug.LogError($"JSON Parse Error: {ex.Message}");
                    IsPriceLoaded = false;
                }
            }
        }
    }
    
    // Call this to manually refresh price
    public void RefreshPrice()
    {
        StartCoroutine(FetchTBTCPrice());
    }
}

[System.Serializable]
public class TBTCResponse
{
    public string id;
    public string name;
    public string symbol;
    public TBTCQuotes quotes;
}

[System.Serializable]
public class TBTCQuotes
{
    public TBTCPrice USD;
}

[System.Serializable]
public class TBTCPrice
{
    public float price;
}
