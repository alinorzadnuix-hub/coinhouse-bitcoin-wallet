using UnityEngine;
using UnityEngine.UI;
using System.Threading.Tasks;

/// <summary>
/// Simple script to get wallet balance and display in a Text component
/// Scans all addresses like ModernMobileWallet does
/// </summary>
public class WalletBalanceDisplay : MonoBehaviour
{
    public Text balanceText;
    
    private bool isTestNet = true;
    
    async void Start()
    {
        await UpdateBalance();
    }
    
    public async Task UpdateBalance()
    {
        if (balanceText == null)
        {
            Debug.LogError("Balance Text is not assigned!");
            return;
        }
        
        if (!WalletManager2.Instance.HasWallet())
        {
            balanceText.text = "No wallet found!";
            return;
        }
        
        balanceText.text = "Loading...";
        
        try
        {
            WalletData data = WalletManager2.Instance.GetCurrentWallet();
            isTestNet = data.isTestNet;
            
            // استفاده از سرویس اسکنر - scan همه address ها
            BitcoinTransactionService txService = new BitcoinTransactionService();
            var result = await txService.ScanAllAddresses(data.seedPhrase);
            
            // جمع موجودی تایید شده و نشده
            decimal totalBalance = result.confirmedBalance + result.unconfirmedBalance;
            
            string currency = isTestNet ? "tBTC" : "BTC";
            balanceText.text = $"{totalBalance:F8} {currency}";
            
            Debug.Log($"✅ Total Balance: {totalBalance:F8} {currency}");
            Debug.Log($"   Confirmed: {result.confirmedBalance:F8}");
            Debug.Log($"   Unconfirmed: {result.unconfirmedBalance:F8}");
        }
        catch (System.Exception ex)
        {
            balanceText.text = "Error loading balance";
            Debug.LogError($"❌ Balance error: {ex.Message}");
        }
    }
    
    // Call this to manually refresh
    public void RefreshBalance()
    {
        _ = UpdateBalance();
    }
}
